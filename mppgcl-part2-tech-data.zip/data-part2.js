window.MPPGCL_SUBJECTS = window.MPPGCL_SUBJECTS || [];
window.MPPGCL_SUBJECTS.push(
{
  "id": "som",
  "name": "Strength of Materials — SOM (पदार्थों की सामर्थ्य)",
  "icon": "🏗️",
  "category": "tech",
  "weight": "High (10–13 Marks)",
  "topics": [
    {
      "id": "som_stress_strain",
      "title": "Stress, Strain, Hooke's Law & Elastic Constants (प्रतिबल व विकृति)",
      "subtitle": "Mild Steel Curve • E, G, K, μ Relations • Thermal Stress",
      "diagram": "stress_strain",
      "def": "<b>Stress (प्रतिबल σ = P/A)</b> बाहरी बल के विरुद्ध पदार्थ के अंदर उत्पन्न आंतरिक प्रतिरोधी बल प्रति इकाई क्षेत्रफल है। <b>Strain (विकृति ε = ΔL/L)</b> लंबाई में परिवर्तन और मूल लंबाई का अनुपात है (इकाईरहित)।",
      "points": [
        "<b>Hooke's Law:</b> Proportional Limit (अनुपातिक सीमा) तक Stress ∝ Strain (σ = E·ε)।",
        "<b>Mild Steel Curve के 6 बिंदु:</b> A (Proportional Limit) → B (Elastic Limit) → C (Upper Yield) → C' (Lower Yield) → E (Ultimate Tensile Strength σ_u) → F (Fracture/Breaking Point)।",
        "<b>Poisson's Ratio (μ):</b> −(Lateral Strain / Longitudinal Strain)। Engineering Materials के लिए <b>0 से 0.5</b> (Cork = 0, Rubber = 0.5, Steel = 0.28–0.30, Cast Iron = 0.25)।",
        "<b>Elastic Constants की संख्या:</b> Isotropic Material के लिए कुल <b>4</b> (E, G, K, μ), जिनमें से केवल <b>2 स्वतंत्र (Independent)</b> होते हैं।",
        "<b>Thermal Stress:</b> यदि छड़ को फैलने से रोका जाए तो σ_th = E·α·ΔT (यदि मुक्त रूप से फैलने दिया जाए तो Thermal Stress = <b>Zero</b>)।"
      ],
      "examples": [
        "रेल की पटरियों के बीच थोड़ा गैप (Expansion Joint) छोड़ा जाता है ताकि गर्मियों में Thermal Stress के कारण पटरी टेढ़ी न हो जाए।"
      ],
      "formulas": [
        "Elongation of Uniform Bar: ΔL = (P · L) / (A · E)",
        "Self-Weight Elongation: ΔL = (γ · L²) / (2E) = (W · L) / (2 A E)  [Uniform bar का आधा!]",
        "Elastic Constants (रट लो!): E = 2G(1 + μ)  |  E = 3K(1 − 2μ)  |  E = (9KG) / (3K + G)",
        "Strain Energy (Resilience): U = (σ² / 2E) × Volume  |  Proof Resilience = σ_y² / 2E"
      ],
      "trick": "<b>E, G, K, μ संबंध याद रखने की ट्रिक — '2G के साथ (+1), 3K के साथ (-2)':</b> E = <b>2G(1+μ)</b> और E = <b>3K(1−2μ)</b>, और दोनों को जोड़ो तो <b>E = 9KG / (3K+G)</b>!",
      "examFacts": [
        "<b>Mild Steel (Ductile)</b> Tension में <b>Cup & Cone</b> टूटता है और Torsion में 90° पर; जबकि <b>Cast Iron (Brittle)</b> Tension में 90° पर और Torsion में <b>45° Helix</b> पर टूटता है।",
        "<b>Toughness (चिमड़पन):</b> Fracture तक पूरे Stress-Strain Curve के नीचे का क्षेत्रफल; <b>Resilience:</b> Elastic Limit तक का क्षेत्रफल।",
        "<b>Factor of Safety (FOS):</b> Ductile के लिए Yield Stress / Working Stress, और Brittle के लिए Ultimate Stress / Working Stress।"
      ],
      "numericals": [
        {
          "q": "एक धातु के लिए Young's Modulus E = 200 GPa और Poisson's Ratio μ = 0.25 है। Shear Modulus (G) और Bulk Modulus (K) ज्ञात करें।",
          "given": "E = 200 GPa, μ = 0.25",
          "formula": "E = 2G(1 + μ)  और  E = 3K(1 − 2μ)",
          "sol": "G = 200 / [2 × (1 + 0.25)] = 200 / 2.5 = 80 GPa.   K = 200 / [3 × (1 − 0.5)] = 200 / 1.5 = 133.33 GPa",
          "ans": "G = 80 GPa और K = 133.33 GPa"
        }
      ],
      "mcqs": [
        {
          "q": "Hooke's Law कहाँ तक मान्य (Valid) होता है?",
          "opts": [
            "Yield Point तक",
            "Proportional Limit तक",
            "Ultimate Point तक",
            "Fracture Point तक"
          ],
          "ans": 1,
          "exp": "Hooke's Law (σ ∝ ε) ठीक-ठीक Proportional Limit (बिंदु A) तक ही मान्य होता है।"
        },
        {
          "q": "एक स्वतंत्र रूप से रखी (Unconstrained) स्टील की छड़ को गरम करने पर उसमें Thermal Stress कितना होगा?",
          "opts": [
            "EαΔT",
            "अधिकतम",
            "शून्य (Zero)",
            "ऋणात्मक"
          ],
          "ans": 2,
          "exp": "जब छड़ को फैलने से रोका नहीं जाता, तो उसमें कोई आंतरिक प्रतिरोध (Thermal Stress) उत्पन्न नहीं होता — उत्तर शून्य!"
        },
        {
          "q": "Cork (कॉर्क) के लिए Poisson's Ratio (μ) का मान लगभग कितना होता है?",
          "opts": [
            "0.5",
            "0.3",
            "0 (शून्य)",
            "1.0"
          ],
          "ans": 2,
          "exp": "कॉर्क को दबाने पर उसकी चौड़ाई नहीं फैलती, इसलिए μ ≈ 0 होता है (इसीलिए बोतल के ढक्कन में कॉर्क लगता है)।"
        }
      ]
    },
    {
      "id": "som_sfd_bmd",
      "title": "Shear Force (SFD) & Bending Moment Diagrams (BMD)",
      "subtitle": "Point of Contraflexure • Standard Beams • Relations dM/dx = V",
      "diagram": "sfd_bmd",
      "def": "<b>Shear Force (SF)</b> किसी अनुप्रस्थ काट के एक ओर लगने वाले सभी ऊर्ध्वाधर बलों का योग है। <b>Bending Moment (BM)</b> उस काट पर लगने वाले सभी आघूर्णों का योग है।",
      "points": [
        "<b>अवकल संबंध (Differential Relations):</b> <b>dV/dx = −w</b> (लोड की तीव्रता) और <b>dM/dx = V</b> (Shear Force)।",
        "जहाँ <b>Shear Force शून्य (या चिह्न बदलता है)</b>, वहाँ <b>Bending Moment अधिकतम (Maximum)</b> होता है।",
        "<b>Point of Contraflexure (या Inflection):</b> वह बिंदु जहाँ <b>Bending Moment शून्य होकर अपना चिह्न (+ से −) बदलता है</b> (Overhanging Beam में पाया जाता है)।",
        "<b>आकार का नियम (Degree Rule):</b> Point Load → SFD Rectangle (0°), BMD Triangle (1°)। UDL → SFD Triangle (1°), BMD Parabola (2°)। UVL → SFD Parabola (2°), BMD Cubic (3°)।"
      ],
      "examples": [
        "छत की बालकनी (छज्जा) <b>Cantilever Beam</b> है, और दो खंभों पर रखा पुल <b>Simply Supported Beam</b> है।"
      ],
      "formulas": [
        "Cantilever + Point Load W at free end: Max SF = W,  Max BM = W·L",
        "Cantilever + UDL (w/m): Max SF = wL,  Max BM = wL² / 2",
        "Simply Supported (SSB) + Center Point Load W: Max SF = W/2,  Max BM = WL / 4",
        "Simply Supported (SSB) + Full UDL (w/m): Max SF = wL/2,  Max BM = wL² / 8"
      ],
      "trick": "<b>Max BM के हर (Denominator) की ट्रिक — '1-2-4-8':</b> Cantilever Point = WL/<b>1</b>, Cantilever UDL = wL²/<b>2</b>, SSB Center Point = WL/<b>4</b>, SSB UDL = wL²/<b>8</b>!",
      "examFacts": [
        "<b>Pure Bending (शुद्ध बंकन)</b> में Shear Force हर जगह <b>शून्य (SF = 0)</b> होता है और Bending Moment <b>नियत (Constant)</b> रहता है।",
        "BMD का ढलान (Slope of BMD) उस बिंदु पर <b>Shear Force (V)</b> दर्शाता है।",
        "जहाँ SFD में अचानक उछाल (Sudden Jump) आए, वहाँ <b>Point Load</b> लगा होता है; जहाँ BMD में अचानक उछाल आए, वहाँ <b>Concentrated Couple/Moment</b> लगा होता है।"
      ],
      "numericals": [
        {
          "q": "4 m लंबी Simply Supported Beam के ठीक बीच में 20 kN का Point Load लगा है। Maximum Shear Force और Maximum Bending Moment ज्ञात करें।",
          "given": "L = 4 m, W = 20 kN",
          "formula": "Max SF = W / 2 ;  Max BM = (W · L) / 4",
          "sol": "Max SF = 20 / 2 = 10 kN.   Max BM = (20 × 4) / 4 = 20 kN·m",
          "ans": "Max SF = 10 kN, Max BM = 20 kN·m"
        }
      ],
      "table": {
        "headers": [
          "Beam & Loading",
          "Max Shear Force",
          "Max Bending Moment",
          "BMD Shape"
        ],
        "rows": [
          [
            "Cantilever + Point Load W",
            "W",
            "W·L",
            "Linear (Triangle)"
          ],
          [
            "Cantilever + UDL w",
            "w·L",
            "wL² / 2",
            "Parabolic"
          ],
          [
            "SSB + Point Load W (Center)",
            "W / 2",
            "W·L / 4",
            "Triangle"
          ],
          [
            "SSB + Full UDL w",
            "w·L / 2",
            "wL² / 8",
            "Parabolic"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "Point of Contraflexure वह बिंदु है जहाँ —",
          "opts": [
            "Shear Force शून्य होता है",
            "Bending Moment अधिकतम होता है",
            "Bending Moment अपना चिह्न बदलता है (0 होता है)",
            "Deflection अधिकतम होता है"
          ],
          "ans": 2,
          "exp": "Point of Contraflexure पर Bending Moment शून्य होकर Hogging से Sagging (या उल्टा) में बदलता है।"
        },
        {
          "q": "UDL (Uniformly Distributed Load) के नीचे Bending Moment Diagram की आकृति कैसी होती है?",
          "opts": [
            "आयताकार",
            "त्रिभुजाकार (Linear)",
            "परवलयाकार (Parabolic)",
            "घन (Cubic)"
          ],
          "ans": 2,
          "exp": "UDL के लिए SFD रेखीय (1°) और BMD परवलयाकार (Parabolic, 2°) होता है।"
        }
      ]
    },
    {
      "id": "som_bending_torsion",
      "title": "Bending Equation, Torsion of Shafts & Deflection (बंकन व मरोड़)",
      "subtitle": "Flexure Formula • Section Modulus • Polar Modulus • Shaft Power",
      "diagram": "sfd_bmd",
      "def": "बीम के झुकने (Bending) का विश्लेषण <b>Bending Equation</b> से और घूमने वाले शाफ़्ट में मरोड़ (Twisting) का विश्लेषण <b>Torsion Equation</b> से किया जाता है।",
      "points": [
        "<b>Bending Equation:</b> <b>M / I = σ / y = E / R</b>। Neutral Axis (NA) पर Bending Stress = <b>0</b> और बाहरी सतह (y_max) पर अधिकतम होता है।",
        "<b>Section Modulus (Z = I / y_max):</b> बीम की बंकन सामर्थ्य (Strength) का माप। आयत के लिए Z = bd²/6, ठोस वृत्त के लिए Z = πd³/32।",
        "<b>Torsion Equation:</b> <b>T / J = τ / r = Gθ / L</b>। शाफ़्ट के केंद्र पर Shear Stress = 0 और बाहरी सतह पर अधिकतम (τ_max = 16T / πd³)।",
        "<b>Hollow vs Solid Shaft:</b> समान भार और लंबाई के लिए <b>Hollow Shaft</b>, Solid Shaft से अधिक मज़बूत (Stronger) व कड़ा (Stiffer) होता है।"
      ],
      "examples": [
        "गाड़ी की प्रोपेलर शाफ़्ट खोखली (Hollow) बनाई जाती है क्योंकि मरोड़ में सबसे ज़्यादा तनाव बाहरी परत झेलती है — बीच का लोहा हटाने से वज़न कम और मज़बूती ज़्यादा मिलती है।"
      ],
      "formulas": [
        "Bending Stress: σ = M / Z  |  Shear Stress (Rect Beam): τ_max = 1.5 · τ_avg ; (Circular): τ_max = (4/3) · τ_avg",
        "Solid Shaft Torque: T = (π/16) · τ · d³  |  Polar MOI: J = πd⁴ / 32",
        "Power Transmitted by Shaft: P = (2π N T) / 60 (Watts)",
        "Standard Deflection (δ_max): Cantilever Point = WL³/(3EI) | Cantilever UDL = wL⁴/(8EI) | SSB Center Point = WL³/(48EI) | SSB UDL = 5wL⁴/(384EI)"
      ],
      "trick": "<b>Deflection हर की ट्रिक — '3, 8, 48, 384':</b> Cantilever (Point = <b>3</b>, UDL = <b>8</b>) | SSB (Point = <b>48</b>, UDL = <b>5/384</b>)! <br/><b>Shear Stress Max/Avg:</b> आयत = <b>3/2 (1.5)</b>, वृत्त = <b>4/3 (1.33)</b>!",
      "examFacts": [
        "<b>I-Section Beam</b> में <b>Flanges</b> मुख्य रूप से Bending Moment झेलते हैं और बीच का <b>Web</b> Shear Force झेलता है।",
        "यदि शाफ़्ट का व्यास दोगुना (2d) कर दिया जाए, तो उसकी Torque क्षमता <b>8 गुना (2³)</b> बढ़ जाती है।",
        "<b>Torsional Rigidity = G·J</b> और <b>Flexural Rigidity = E·I</b> होता है।"
      ],
      "numericals": [
        {
          "q": "एक शाफ़्ट 600 RPM पर घूमते हुए 500 N·m का Torque ट्रांसमिट करता है। शाफ़्ट द्वारा ट्रांसमिट की गई Power (kW में) निकालें (π = 3.14)।",
          "given": "N = 600 RPM, T = 500 N·m",
          "formula": "P = (2 π N T) / 60",
          "sol": "P = (2 × 3.14 × 600 × 500) / 60 = 2 × 3.14 × 10 × 500 = 31,400 W = 31.4 kW",
          "ans": "31.4 kW"
        }
      ],
      "mcqs": [
        {
          "q": "एक आयताकार बीम (Rectangular Beam) में अधिकतम कर्तन प्रतिबल (τ_max) और औसत कर्तन प्रतिबल (τ_avg) का अनुपात कितना होता है?",
          "opts": [
            "4/3 (1.33)",
            "3/2 (1.5)",
            "2.0",
            "1.25"
          ],
          "ans": 1,
          "exp": "आयताकार काट के लिए τ_max = 1.5 τ_avg और वृत्ताकार काट के लिए τ_max = (4/3) τ_avg होता है।"
        },
        {
          "q": "Simply Supported Beam के मध्य में Point Load W लगने पर अधिकतम विक्षेपण (Max Deflection) कितना होता है?",
          "opts": [
            "WL³ / 3EI",
            "WL³ / 16EI",
            "WL³ / 48EI",
            "5wL⁴ / 384EI"
          ],
          "ans": 2,
          "exp": "ट्रिक 3, 8, 48, 384: SSB Center Point Load के लिए δ_max = WL³ / 48EI होता है।"
        }
      ]
    },
    {
      "id": "som_principal_mohr",
      "title": "Principal Stresses, Mohr's Circle & Thin Cylinders (मोहर वृत्त व सिलेंडर)",
      "subtitle": "Major/Minor Principal Stress • Hoop & Longitudinal Stress",
      "diagram": "mohr_circle",
      "def": "<b>Principal Planes (मुख्य तल)</b> वे तल हैं जिन पर Shear Stress <b>शून्य (τ = 0)</b> होता है, और उन पर लगने वाला अभिलंब प्रतिबल (Normal Stress) अधिकतम या न्यूनतम (Principal Stress σ₁, σ₂) होता है।",
      "points": [
        "<b>Mohr's Circle:</b> किसी बिंदु पर 2D प्रतिबलों का ग्राफ़िकल चित्रण। इसका केंद्र <b>C = ((σx+σy)/2, 0)</b> और त्रिज्या <b>R = τ_max = (σ₁ − σ₂)/2</b> होती है।",
        "<b>Pure Shear:</b> जब केवल τ_xy लगे (σx = σy = 0), तो Mohr's Circle का केंद्र मूल बिंदु (0, 0) पर होता है और σ₁ = +τ, σ₂ = −τ।",
        "<b>Hydrostatic State (σx = σy = σ, τ = 0):</b> Mohr's Circle एक <b>बिंदु (Point, R = 0)</b> बन जाता है।",
        "<b>Thin Cylinder (t < d/20):</b> इसमें दो मुख्य प्रतिबल होते हैं — <b>Hoop (Circumferential) Stress σ_h = pd/2t</b> और <b>Longitudinal Stress σ_l = pd/4t</b>।",
        "<b>Thin Spherical Shell:</b> सभी दिशाओं में समान प्रतिबल <b>σ = pd / 4t</b> (सिलेंडर के Hoop Stress का आधा!)।"
      ],
      "examples": [
        "बॉयलर ड्रम, LPG गैस सिलेंडर और पानी के पाइप <b>Thin Cylinders</b> के उदाहरण हैं — ये फटने पर हमेशा लंबाई के समानांतर (Hoop Stress के कारण) फटते हैं!"
      ],
      "formulas": [
        "Principal Stresses: σ₁,₂ = (σx + σy)/2 ± √[ ((σx − σy)/2)² + τ_xy² ]",
        "Maximum In-Plane Shear Stress: τ_max = (σ₁ − σ₂) / 2 = Radius of Mohr's Circle",
        "Thin Cylinder: σ_h = (p·d) / (2t)  |  σ_l = (p·d) / (4t)  ⇒  σ_h = 2 · σ_l",
        "Volumetric Strain of Thin Cylinder: ε_v = 2ε_h + ε_l = (pd / 4tE) · (5 − 4μ)"
      ],
      "trick": "<b>Thin Cylinder की ट्रिक — 'Hoop 2, Long 4, Sphere 4':</b> σ_h = pd/<b>2</b>t (ज़्यादा खतरनाक), σ_l = pd/<b>4</b>t, और Sphere = pd/<b>4</b>t!",
      "examFacts": [
        "अधिकतम Shear Stress वाला तल, Principal Plane से हमेशा <b>45°</b> (Mohr Circle में 90°) पर होता है।",
        "Thin Cylinder में <b>Hoop Stress, Longitudinal Stress का दोगुना</b> होता है, इसलिए डिज़ाइन हमेशा Hoop Stress के आधार पर होता है।"
      ],
      "numericals": [
        {
          "q": "एक पतले सिलेंडर का व्यास d = 1000 mm, मोटाई t = 10 mm और आंतरिक दाब p = 2 MPa है। Hoop Stress (σ_h) और Longitudinal Stress (σ_l) ज्ञात करें।",
          "given": "d = 1000 mm, t = 10 mm, p = 2 MPa (N/mm²)",
          "formula": "σ_h = (p·d) / (2t) ;  σ_l = (p·d) / (4t)",
          "sol": "σ_h = (2 × 1000) / (2 × 10) = 2000 / 20 = 100 MPa.   σ_l = σ_h / 2 = 50 MPa",
          "ans": "σ_h = 100 MPa और σ_l = 50 MPa"
        }
      ],
      "mcqs": [
        {
          "q": "Principal Plane पर कर्तन प्रतिबल (Shear Stress) का मान कितना होता है?",
          "opts": [
            "अधिकतम",
            "शून्य (Zero)",
            "σ₁/2",
            "अनंत"
          ],
          "ans": 1,
          "exp": "परिभाषा के अनुसार Principal Planes वे तल हैं जिन पर Shear Stress हमेशा शून्य होता है।"
        },
        {
          "q": "Thin Cylinder में Hoop Stress और Longitudinal Stress का अनुपात (σ_h / σ_l) कितना होता है?",
          "opts": [
            "0.5",
            "1",
            "2",
            "4"
          ],
          "ans": 2,
          "exp": "σ_h = pd/2t और σ_l = pd/4t, इसलिए अनुपात हमेशा 2 होता है।"
        }
      ]
    },
    {
      "id": "som_columns",
      "title": "Columns, Struts & Buckling Theory (स्तंभ एवं बकलिंग)",
      "subtitle": "Euler's Buckling Load • Effective Length • Slenderness Ratio • Rankine Formula",
      "diagram": "columns",
      "def": "<b>Column (स्तंभ)</b> एक ऊर्ध्वाधर संपीड़न अवयव (Vertical Compression Member) है। छोटे स्तंभ <b>Crushing</b> से और लंबे पतले स्तंभ (Long Columns) <b>Buckling (बकलिंग / झुकने)</b> से विफल होते हैं।",
      "points": [
        "<b>Slenderness Ratio (λ = L_e / k_min):</b> Effective Length और Minimum Radius of Gyration (k = √(I_min/A)) का अनुपात।",
        "<b>Euler's Formula:</b> केवल <b>Long Columns</b> (जहाँ λ > 80, शुद्ध Buckling) के लिए मान्य है।",
        "<b>Rankine's Formula:</b> Short और Long <b>दोनों प्रकार के स्तंभों</b> के लिए मान्य है (1/P_R = 1/P_c + 1/P_E)।",
        "<b>4 End Conditions:</b> Both Hinged (L_e = L), Fixed-Free (L_e = 2L), Fixed-Hinged (L_e = L/√2), Both Fixed (L_e = L/2)।"
      ],
      "examples": [
        "प्लास्टिक के लंबे स्केल को ऊपर से दबाने पर वह बीच से मुड़ जाता है — यही <b>Euler's Buckling</b> है!"
      ],
      "formulas": [
        "Euler's Crippling/Buckling Load: P_E = (π² · E · I_min) / L_e²",
        "Slenderness Ratio: λ = L_e / k_min  (जहाँ k_min = √(I_min / A))",
        "Rankine's Load: 1/P_R = 1/P_c + 1/P_E  ⇒  P_R = (σ_c · A) / (1 + a · λ²)"
      ],
      "trick": "<b>बकलिंग ताकत का अनुपात — '1/4 : 1 : 2 : 4':</b> Fixed-Free (सबसे कमजोर = 0.25×) → Both Hinged (1×) → Fixed-Hinged (2×) → Both Fixed (सबसे मज़बूत = <b>4×</b>)!",
      "examFacts": [
        "<b>Both Ends Fixed</b> स्तंभ की बकलिंग सामर्थ्य, <b>Both Hinged</b> स्तंभ से <b>4 गुना</b> और <b>Fixed-Free</b> स्तंभ से <b>16 गुना</b> अधिक होती है!",
        "बकलिंग हमेशा उस अक्ष के परितः होती है जहाँ <b>Moment of Inertia न्यूनतम (I_min)</b> होता है।"
      ],
      "numericals": [
        {
          "q": "एक Both-Hinged स्तंभ का Euler Buckling Load 100 kN है। यदि इसके दोनों सिरे Fixed कर दिए जाएँ, तो नया Buckling Load क्या होगा?",
          "given": "P_hinged = 100 kN (L_e = L).  Both Fixed के लिए L_e = L / 2",
          "formula": "P_E ∝ 1 / L_e²",
          "sol": "P_fixed / P_hinged = L² / (L/2)² = 4  ⇒  P_fixed = 4 × 100 = 400 kN",
          "ans": "400 kN"
        }
      ],
      "mcqs": [
        {
          "q": "एक सिरे से Fixed और दूसरे से Free (Cantilever) स्तंभ की Effective Length (L_e) कितनी होती है?",
          "opts": [
            "L / 2",
            "L / √2",
            "L",
            "2L"
          ],
          "ans": 3,
          "exp": "Fixed-Free स्तंभ के लिए L_e = 2L होती है और यह सबसे कमज़ोर व्यवस्था है।"
        },
        {
          "q": "Rankine's Formula किस प्रकार के स्तंभों के लिए उपयोगी है?",
          "opts": [
            "केवल Long Columns",
            "केवल Short Columns",
            "Short और Long दोनों के लिए",
            "केवल Beams के लिए"
          ],
          "ans": 2,
          "exp": "Rankine's Formula में Crushing (P_c) और Buckling (P_E) दोनों शामिल होते हैं, इसलिए यह सभी स्तंभों पर लागू होता है।"
        }
      ]
    }
  ]
},
{
  "id": "tom",
  "name": "Theory of Machines — TOM (मशीनों के सिद्धांत)",
  "icon": "⚙️",
  "category": "tech",
  "weight": "High (9–12 Marks)",
  "topics": [
    {
      "id": "tom_mechanisms",
      "title": "Kinematic Links, Pairs, DOF & Grashof's Law (कैनेमैटिक्स)",
      "subtitle": "Lower vs Higher Pair • Kutzbach Criterion • Inversions of 4-Bar & Slider Crank",
      "diagram": "grashof",
      "def": "<b>Kinematic Link (कड़ी)</b> मशीन का वह दृढ़ भाग है जो दूसरे भाग के सापेक्ष गति करता है। <b>Kinematic Pair</b> दो जुड़े हुए लिंक्स का जोड़ा है। <b>Mechanism</b> में कम से कम 4 लिंक्स होते हैं (1 फिक्स) जो गति को नियंत्रित रूप से आगे बढ़ाते हैं।",
      "points": [
        "<b>Lower Pair (Surface Contact):</b> Sliding, Turning, Screw, Cylindrical, Spherical, Planar। (घर्षण कम, घिसाव कम)।",
        "<b>Higher Pair (Point या Line Contact):</b> Cam & Follower, Toothed Gears, Belt & Pulley, Ball Bearing।",
        "<b>Grashof's Law (4-Bar Mechanism):</b> कम से कम एक लिंक के पूर्ण 360° घूमने के लिए <b>s + l ≤ p + q</b> (सबसे छोटा + सबसे बड़ा ≤ बाकी दोनों का योग)।",
        "<b>4-Bar Inversions:</b> Beam Engine (Crank-Rocker), Coupling Rod of Locomotive (Double Crank), Watt's Indicator (Double Rocker)।",
        "<b>Single Slider Crank Inversions:</b> 1) Cylinder Fixed → Reciprocating Engine/Compressor; 2) Crank Fixed → <b>Whitworth Quick Return</b> & Rotary Engine; 3) Connecting Rod Fixed → <b>Crank & Slotted Lever Quick Return</b> & Oscillating Cylinder; 4) Slider Fixed → Hand Pump (Pendulum Pump)।",
        "<b>Double Slider Crank Inversions:</b> Elliptical Trammel, Scotch Yoke, <b>Oldham's Coupling</b> (Parallel Offset Shafts जोड़ने हेतु)।"
      ],
      "examples": [
        "साइकिल के पैडल और चेन गियर <b>Higher Pair</b> हैं, जबकि दरवाज़े का कब्जा (Hinge) <b>Lower Turning Pair</b> है।"
      ],
      "formulas": [
        "Kutzbach Equation (Planar DOF): F = 3(L − 1) − 2J − H",
        "Grubler's Criterion (F = 1, H = 0): 3L − 2J − 4 = 0",
        "Grashof's Law: s + l ≤ p + q",
        "Number of Instantaneous Centres (I-Centres): N = n(n − 1) / 2"
      ],
      "trick": "<b>Grashof Inversions की ट्रिक — 'S-A-O (सॉ)':</b><br/>• <b>S</b>hortest Fixed → Double Crank<br/>• <b>A</b>djacent to shortest Fixed → Crank-Rocker<br/>• <b>O</b>pposite to shortest Fixed → Double Rocker!",
      "examFacts": [
        "<b>Oldham's Coupling</b> Double Slider Crank का Inversion है जिसका उपयोग दो <b>समानांतर लेकिन थोड़ी हटी हुई (Parallel Non-collinear)</b> शाफ़्टों को जोड़ने में होता है।",
        "<b>Hooke's Joint (Universal Joint)</b> दो प्रतिच्छेदी (Intersecting) शाफ़्टों को जोड़ने में काम आता है।",
        "F = 0 → Structure (Frame), F = 1 → Constrained Mechanism, F < 0 → Superstructure।"
      ],
      "numericals": [
        {
          "q": "एक Four-Bar Mechanism की भुजाएँ 40 mm, 90 mm, 70 mm और 80 mm हैं। जाँचें कि क्या यह Grashof's Law का पालन करता है, और इसके कितने Instantaneous Centres होंगे?",
          "given": "s = 40, l = 90, p = 70, q = 80;  Links n = 4",
          "formula": "Grashof: s + l ≤ p + q ;  I-Centres N = n(n − 1) / 2",
          "sol": "s + l = 40 + 90 = 130.  p + q = 70 + 80 = 150. चूँकि 130 ≤ 150, यह Grashof Mechanism है!  N = 4(4−1)/2 = 6 I-Centres",
          "ans": "हाँ (Grashof Law लागू) और 6 I-Centres"
        }
      ],
      "mcqs": [
        {
          "q": "निम्न में से कौन-सा एक Higher Pair का उदाहरण है?",
          "opts": [
            "Piston and Cylinder",
            "Nut and Bolt (Screw)",
            "Cam and Follower",
            "Shaft in Bearing"
          ],
          "ans": 2,
          "exp": "Cam & Follower में Line या Point Contact होता है, इसलिए यह Higher Pair है।"
        },
        {
          "q": "Oldham's Coupling किस मैकेनिज़्म का Inversion है?",
          "opts": [
            "Four-Bar Chain",
            "Single Slider Crank",
            "Double Slider Crank",
            "Scotch Yoke"
          ],
          "ans": 2,
          "exp": "Double Slider Crank के 3 मुख्य Inversions हैं: Elliptical Trammel, Scotch Yoke और Oldham's Coupling।"
        }
      ]
    },
    {
      "id": "tom_flywheel_gov",
      "title": "Flywheel & Governors — Watt, Porter, Hartnell (फ्लाईव्हील व गवर्नर)",
      "subtitle": "Fluctuation of Energy • Sensitiveness • Hunting • Isochronism",
      "diagram": "flywheel_governor",
      "def": "<b>Flywheel (गतिपालक चक्र)</b> एक ही चक्र के भीतर ऊर्जा संचित व मुक्त करके गति के उतार-चढ़ाव को नियंत्रित करता है। <b>Governor (नियामक)</b> बाहरी लोड बदलने पर ईंधन की सप्लाई घटा-बढ़ाकर औसत गति (Mean Speed) स्थिर रखता है।",
      "points": [
        "<b>Flywheel:</b> यह एक 'ऊर्जा का बैंक (Reservoir of Energy)' है — बाहरी लोड बदलने पर इसका कोई नियंत्रण नहीं होता।",
        "<b>Governor के प्रकार:</b> <b>Pendulum Type</b> (Watt), <b>Dead Weight Type</b> (Porter, Proell), और <b>Spring Controlled</b> (Hartnell, Hartung, Wilson-Hartnell)।",
        "<b>Isochronous Governor:</b> सभी स्लीव स्थितियों पर समान संतुलन गति (N₁ = N₂) — इसकी <b>Sensitiveness अनंत (∞)</b> होती है (व्यावहारिक नहीं)।",
        "<b>Hunting (हंटिंग):</b> जब गवर्नर बहुत ज़्यादा संवेदनशील (Too Sensitive) हो जाए, तो इंजन की स्पीड लगातार ऊपर-नीचे झूलती रहती है — इसे Hunting कहते हैं।"
      ],
      "examples": [
        "गन्ने के जूस की मशीन या पुराने डीजल जनरेटर का भारी लोहे का पहिया <b>Flywheel</b> है, और पावर प्लांट की टरबाइन में लोड के हिसाब से भाप का वॉल्व कंट्रोल करने वाला यंत्र <b>Governor</b> है।"
      ],
      "formulas": [
        "Max Fluctuation of Energy (Flywheel): ΔE = I · ω² · Cs = 2 · E_mean · Cs",
        "Coefficient of Fluctuation of Speed: Cs = (N_max − N_min) / N_mean",
        "Watt Governor Height: h = g / ω² = 895 / N² (मीटर में)",
        "Porter Governor Speed: N² = (895 / h) × [ (m + M) / m ]  (जब भुजाएँ बराबर हों)"
      ],
      "trick": "<b>Flywheel vs Governor की 1-लाइन ट्रिक:</b> <b>Flywheel = चक्र के अंदर (Within Cycle)</b> ऊर्जा बचाए | <b>Governor = लोड बदलने पर (Mean Speed)</b> ईंधन घटाए-बढ़ाए!",
      "examFacts": [
        "<b>Watt Governor</b> केवल <b>कम गति (60–80 RPM)</b> पर काम करता है; अधिक स्पीड पर इसकी संवेदनशीलता बहुत कम हो जाती है।",
        "<b>Hartnell Governor</b> एक Spring-Controlled Governor है जो उच्च गति पर भी बेहतरीन काम करता है।",
        "यदि गवर्नर की <b>Sensitiveness बहुत अधिक</b> हो, तो उसमें <b>Hunting</b> दोष उत्पन्न हो जाता है।"
      ],
      "numericals": [
        {
          "q": "एक Watt Governor 60 RPM पर घूम रहा है। इसकी ऊँचाई (h) ज्ञात करें।",
          "given": "N = 60 RPM",
          "formula": "h = 895 / N² (मीटर में)",
          "sol": "h = 895 / (60)² = 895 / 3600 = 0.2486 m ≈ 24.86 cm",
          "ans": "0.249 m (24.9 cm)"
        }
      ],
      "mcqs": [
        {
          "q": "इंजन पर बाहरी लोड बदलने पर ईंधन की आपूर्ति नियंत्रित करके औसत गति स्थिर कौन रखता है?",
          "opts": [
            "Flywheel",
            "Governor",
            "Clutch",
            "Differential"
          ],
          "ans": 1,
          "exp": "Governor बाहरी लोड में बदलाव के अनुसार ईंधन (Fuel/Steam) की सप्लाई नियंत्रित करता है।"
        },
        {
          "q": "Isochronous Governor की Sensitiveness कितनी होती है?",
          "opts": [
            "शून्य",
            "एक (1)",
            "अनंत (Infinity)",
            "0.5"
          ],
          "ans": 2,
          "exp": "Isochronous Governor में N_max = N_min होता है, इसलिए Sensitiveness = N_mean / (N_max − N_min) = ∞।"
        }
      ]
    },
    {
      "id": "tom_gears",
      "title": "Gears, Law of Gearing & Gear Trains (गियर एवं गियर ट्रेन)",
      "subtitle": "Module • Involute vs Cycloidal • Interference • Epicyclic Gear Train",
      "diagram": "gears",
      "def": "<b>Gear</b> एक Positive Drive (बिना फिसलन वाली ड्राइव) है जो दांतों की मदद से दो शाफ़्टों के बीच निश्चित वेग अनुपात (Constant Velocity Ratio) पर पावर ट्रांसमिट करती है।",
      "points": [
        "<b>Law of Gearing:</b> संपर्क बिंदु पर कॉमन नॉर्मल (Common Normal) हमेशा एक निश्चित बिंदु <b>Pitch Point</b> से होकर गुज़रना चाहिए।",
        "<b>Involute Profile (सबसे अधिक प्रयुक्त):</b> इसमें Pressure Angle (φ = 20° या 14.5°) हमेशा <b>नियत (Constant)</b> रहता है और Center Distance थोड़ा बदलने पर भी Velocity Ratio नहीं बदलता।",
        "<b>Interference (अवरोध):</b> पिनियन के रूट को गियर के टिप द्वारा काट देना। इसे रोकने के लिए दाँतों की न्यूनतम संख्या रखी जाती है (20° Full Depth के लिए <b>T_min = 18</b>; 14.5° के लिए <b>32</b>)।",
        "<b>गियर के प्रकार:</b> <b>Spur/Helical</b> (Parallel Shafts), <b>Bevel</b> (Intersecting Shafts), <b>Worm & Skew/Spiral</b> (Non-parallel, Non-intersecting)।"
      ],
      "examples": [
        "कार के पिछले पहियों का <b>Differential Gearbox</b> एक <b>Epicyclic Gear Train</b> है जो मोड़ पर दोनों पहियों को अलग-अलग स्पीड से घूमने देता है।"
      ],
      "formulas": [
        "Module: m = D / T (mm)  |  Circular Pitch: p_c = π · m  |  Diametral Pitch: P_d = 1 / m",
        "Velocity Ratio: N₁ / N₂ = T₂ / T₁ = D₂ / D₁",
        "Center Distance (External Meshing): C = (D₁ + D₂)/2 = m(T₁ + T₂) / 2",
        "Addendum = 1·m  |  Dedendum = 1.25·m  |  Clearance = 0.25·m  |  Working Depth = 2·m"
      ],
      "trick": "<b>गियर शाफ़्ट दिशा ट्रिक — 'SHP - BI - WN':</b> <b>S</b>pur/<b>H</b>elical = <b>P</b>arallel | <b>B</b>evel = <b>I</b>ntersecting | <b>W</b>orm = <b>N</b>on-parallel Non-intersecting! और <b>20° Involute मिनिमम दाँत = 18</b>!",
      "examFacts": [
        "<b>Herringbone Gear (Double Helical)</b> का उपयोग Helical Gear में उत्पन्न होने वाले <b>Axial Thrust को खत्म (Zero)</b> करने के लिए किया जाता है।",
        "<b>Worm Gear</b> बहुत अधिक Speed Reduction (100:1 तक) के लिए उपयोग होता है और यह Self-Locking हो सकता है।",
        "<b>Revert Gear Train</b> में पहले और आखिरी गियर के अक्ष एक ही सीध में (Co-axial) होते हैं (जैसे घड़ी और लेथ का Back Gear)।"
      ],
      "numericals": [
        {
          "q": "दो Spur Gears के दाँत T₁ = 20 और T₂ = 60 हैं तथा Module m = 4 mm है। यदि पिनियन 900 RPM पर घूमता है, तो गियर की गति (N₂) और Center Distance (C) निकालें।",
          "given": "T₁ = 20, T₂ = 60, m = 4 mm, N₁ = 900 RPM",
          "formula": "N₂ = N₁ × (T₁ / T₂) ;  C = m(T₁ + T₂) / 2",
          "sol": "N₂ = 900 × (20 / 60) = 300 RPM.   C = 4 × (20 + 60) / 2 = 4 × 40 = 160 mm",
          "ans": "N₂ = 300 RPM और Center Distance = 160 mm"
        }
      ],
      "mcqs": [
        {
          "q": "Helical Gear में Axial Thrust को समाप्त करने के लिए किस गियर का उपयोग किया जाता है?",
          "opts": [
            "Spur Gear",
            "Bevel Gear",
            "Herringbone (Double Helical) Gear",
            "Worm Gear"
          ],
          "ans": 2,
          "exp": "Herringbone Gear में दाएँ और बाएँ दोनों दिशा के हेलिक्स होते हैं, जिससे दोनों के Axial Thrust एक-दूसरे को काट देते हैं।"
        },
        {
          "q": "20° Full Depth Involute Gear में Interference से बचने के लिए पिनियन पर न्यूनतम दाँतों की संख्या कितनी होनी चाहिए?",
          "opts": [
            "12",
            "18",
            "24",
            "32"
          ],
          "ans": 1,
          "exp": "20° Full Depth के लिए 18 दाँत, 20° Stub के लिए 14 दाँत और 14.5° के लिए 32 दाँत न्यूनतम होते हैं।"
        }
      ]
    },
    {
      "id": "tom_belts_clutches",
      "title": "Belt Drives, Clutches, Brakes & Balancing (बेल्ट, क्लच व संतुलन)",
      "subtitle": "Tension Ratio • Creep & Slip • Uniform Pressure vs Wear • Self-Locking Brake",
      "diagram": "belt_clutch",
      "def": "<b>Belt Drive</b> दो दूर स्थित शाफ़्टों के बीच घर्षण द्वारा पावर ट्रांसमिट करती है। <b>Clutch</b> इंजन और गियरबॉक्स को जोड़ने-तोड़ने का काम करता है, और <b>Brake</b> चलती मशीन को रोकता है।",
      "points": [
        "<b>Belt Creep (क्रीप):</b> Tight Side और Slack Side पर तनाव के अंतर के कारण बेल्ट का बार-बार फैलना और सिकुड़ना (इलास्टिक गुण के कारण) — इससे गति थोड़ी घटती है।",
        "<b>Crowning of Pulley:</b> पुली की सतह को बीच से हल्का उभरा बनाया जाता है ताकि बेल्ट पुली के <b>केंद्र में बनी रहे (Slip off न हो)</b>।",
        "<b>Clutches के दो सिद्धांत:</b> <b>Uniform Pressure Theory</b> (नए क्लच के लिए) और <b>Uniform Wear Theory</b> (पुराने व व्यावहारिक क्लच के लिए — सुरक्षित डिज़ाइन)।",
        "<b>Balancing:</b> Rotating Masses को 1 ही प्लेन में 1 मास से, और अलग-अलग प्लेन में कम से कम <b>2 Balancing Masses</b> से संतुलित किया जाता है।"
      ],
      "examples": [
        "आटा चक्की में <b>Flat Open Belt</b>, कार के अल्टरनेटर में <b>V-Belt</b>, बाइक में <b>Multi-Plate Clutch</b> और कार में <b>Single-Plate Clutch</b> लगा होता है।"
      ],
      "formulas": [
        "Belt Tension Ratio: T₁ / T₂ = e^(μ·θ)  [V-Belt के लिए: e^(μ·θ / sin β)]",
        "Power Transmitted by Belt: P = (T₁ − T₂) · v (Watts)",
        "Condition for Max Power in Belt: T_c = T_max / 3  ⇒  v_max = √(T_max / 3m)",
        "Single Plate Clutch (n = 2 active faces): T = n · μ · W · R_mean",
        "Uniform Wear Mean Radius: R_m = (R₁ + R₂) / 2  |  Uniform Pressure: R_m = (2/3)·(R₁³−R₂³)/(R₁²−R₂²)"
      ],
      "trick": "<b>बेल्ट Max Power ट्रिक:</b> Centrifugal Tension कुल Max Tension का <b>एक-तिहाई (T_c = T/3)</b> हो, तभी अधिकतम पावर मिलती है! <br/><b>Clutch:</b> <b>N</b>ew = <b>P</b>ressure (NP), <b>O</b>ld = <b>W</b>ear (OW)!",
      "examFacts": [
        "<b>Open Belt</b> में दोनों पुली <b>एक ही दिशा</b> में, और <b>Crossed Belt</b> में <b>विपरीत दिशा</b> में घूमती हैं (Crossed Belt का Angle of Contact ज़्यादा होता है)।",
        "<b>V-Belt</b> में Groove के कारण प्रभावी घर्षण बढ़ जाता है (μ_eff = μ / sin β), इसलिए यह कम दूरी पर अधिक पावर देती है।",
        "<b>Dynamometer</b> दो प्रकार के होते हैं: <b>Absorption</b> (Prony Brake, Rope Brake) और <b>Transmission</b> (Epicyclic, Torsion)।"
      ],
      "numericals": [
        {
          "q": "एक बेल्ट में Tight Side तनाव T₁ = 1500 N, Slack Side तनाव T₂ = 500 N और बेल्ट वेग v = 15 m/s है। ट्रांसमिट की गई पावर निकालें।",
          "given": "T₁ = 1500 N, T₂ = 500 N, v = 15 m/s",
          "formula": "P = (T₁ − T₂) × v",
          "sol": "P = (1500 − 500) × 15 = 1000 × 15 = 15,000 W = 15 kW",
          "ans": "15 kW"
        }
      ],
      "mcqs": [
        {
          "q": "पुली पर Crowning क्यों की जाती है?",
          "opts": [
            "पुली को सुंदर बनाने के लिए",
            "बेल्ट को पुली के बीच में टिकाए रखने के लिए",
            "घर्षण कम करने के लिए",
            "स्पीड बढ़ाने के लिए"
          ],
          "ans": 1,
          "exp": "Crowning (बीच में हल्का उभार) के कारण बेल्ट हमेशा अधिक व्यास वाले मध्य भाग की ओर खिंची रहती है और बाहर नहीं उतरती।"
        },
        {
          "q": "बेल्ट ड्राइव में अधिकतम पावर ट्रांसमिशन के लिए Centrifugal Tension (T_c) का मान कितना होना चाहिए?",
          "opts": [
            "T_max / 2",
            "T_max / 3",
            "T_max / 4",
            "T_max"
          ],
          "ans": 1,
          "exp": "अधिकतम पावर की स्थिति में T_c = T_max / 3 और T₁ = (2/3) T_max होता है।"
        }
      ]
    }
  ]
},
{
  "id": "dom",
  "name": "Design of Machine Elements — DOM (मशीन अभिकल्पन)",
  "icon": "🔩",
  "category": "tech",
  "weight": "Medium-High (6–9 Marks)",
  "topics": [
    {
      "id": "dom_failure_theories",
      "title": "Theories of Failure, Fatigue & Endurance Limit (विफलता के सिद्धांत)",
      "subtitle": "Rankine, Tresca, Von-Mises • S-N Curve • Goodman & Soderberg",
      "diagram": "mohr_circle",
      "def": "जब किसी मशीन अवयव पर एक साथ कई दिशाओं से प्रतिबल (Combined Stresses) लगते हैं, तो वह कब टूटेगा या मुड़ेगा इसका अनुमान लगाने के लिए <b>Theories of Failure</b> उपयोग की जाती हैं।",
      "points": [
        "<b>1. Max Principal Stress Theory (Rankine):</b> केवल <b>Brittle Materials (Cast Iron)</b> के लिए सर्वश्रेष्ठ। ग्राफ़ = Square।",
        "<b>2. Max Shear Stress Theory (Guest / Tresca):</b> <b>Ductile Materials</b> के लिए सबसे सुरक्षित (Conservative) व आसान। ग्राफ़ = Hexagon।",
        "<b>3. Distortion Energy Theory (Von-Mises / Hencky):</b> <b>Ductile Materials</b> के लिए सबसे सटीक (Most Accurate)। ग्राफ़ = Ellipse।",
        "<b>Fatigue Failure (श्रांति विफलता):</b> बार-बार बदलने वाले लोड (Cyclic Load) के कारण Yield Stress से कम प्रतिबल पर ही अवयव का टूट जाना।",
        "<b>Endurance Limit (σ_e):</b> वह अधिकतम प्रतिबल जिसे धातु अनंत चक्रों (10⁶ cycles, Ferrous Metals) तक बिना टूटे सह सकती है (लगभग 0.5 σ_u)।"
      ],
      "examples": [
        "एक लोहे के तार को बार-बार आगे-पीछे मोड़ने पर वह आसानी से टूट जाता है — यही <b>Fatigue Failure</b> है!"
      ],
      "formulas": [
        "Tresca (Max Shear): τ_max = (σ₁ − σ₂)/2 ≤ σ_y / (2 · FOS)",
        "Von-Mises (2D): σ₁² + σ₂² − σ₁σ₂ ≤ (σ_y / FOS)²  (Pure Shear में τ_y = 0.577 σ_y)",
        "Stress Concentration Factor: K_t = σ_max / σ_nominal  (Circular hole in wide plate: K_t = 3)",
        "Soderberg Line (सबसे सुरक्षित): (σ_m / σ_y) + (σ_a / σ_e) = 1 / FOS"
      ],
      "trick": "<b>विफलता के 3 सबसे ज़रूरी सिद्धांत — 'R-B, T-S, V-A':</b> <b>R</b>ankine = <b>B</b>rittle (Cast Iron) | <b>T</b>resca = Ductile (<b>S</b>afe/Conservative) | <b>V</b>on-Mises = Ductile (Most <b>A</b>ccurate)!",
      "examFacts": [
        "<b>Hydrostatic Loading</b> में <b>Distortion Energy (Von-Mises)</b> और <b>Max Shear (Tresca)</b> के अनुसार धातु कभी Yield नहीं होती।",
        "<b>Notch Sensitivity (q):</b> q = (K_f − 1) / (K_t − 1) (मान 0 से 1 के बीच)।",
        "<b>Goodman Line</b> Brittle के लिए (σ_u उपयोग करती है), जबकि <b>Soderberg Line</b> Ductile के लिए सबसे सुरक्षित (σ_y उपयोग करती है) है।"
      ],
      "table": {
        "headers": [
          "सिद्धांत (Theory)",
          "किस पदार्थ के लिए?",
          "2D ग्राफ़ आकृति",
          "विशेषता"
        ],
        "rows": [
          [
            "Rankine (Max Principal)",
            "Brittle (Cast Iron)",
            "Square (वर्ग)",
            "Ductile के लिए Unsafe"
          ],
          [
            "Guest / Tresca (Max Shear)",
            "Ductile (Mild Steel)",
            "Hexagon (षट्भुज)",
            "सबसे सुरक्षित (Conservative)"
          ],
          [
            "Von-Mises (Distortion Energy)",
            "Ductile (Mild Steel)",
            "Ellipse (दीर्घवृत्त)",
            "सबसे सटीक (Best Match)"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "Ductile Materials (तन्य पदार्थों) के लिए सबसे सटीक (Most Accurate) विफलता का सिद्धांत कौन-सा है?",
          "opts": [
            "Rankine's Theory",
            "Von-Mises (Distortion Energy) Theory",
            "St. Venant's Theory",
            "Haigh's Theory"
          ],
          "ans": 1,
          "exp": "प्रयोगों के अनुसार Ductile Materials के लिए Von-Mises (Maximum Distortion Energy Theory) सबसे सटीक परिणाम देती है।"
        },
        {
          "q": "Soderberg Equation डिज़ाइन के लिए किस मान का उपयोग करती है?",
          "opts": [
            "Ultimate Strength (σ_u) और Endurance Limit",
            "Yield Strength (σ_y) और Endurance Limit",
            "केवल Fracture Strength",
            "Shear Modulus"
          ],
          "ans": 1,
          "exp": "Soderberg = Yield (σ_y) + Endurance (σ_e), इसलिए यह सबसे सुरक्षित (Conservative) समीकरण है।"
        }
      ]
    },
    {
      "id": "dom_joints_keys",
      "title": "Riveted, Welded, Cotter/Knuckle Joints, Keys & Couplings",
      "subtitle": "Unwin's Formula • Throat Thickness • Sunk Key • Flange Coupling",
      "diagram": "joints_springs",
      "def": "मशीन के दो भागों को जोड़ने के लिए स्थायी जोड़ (<b>Riveted, Welded</b>) और अस्थायी जोड़ (<b>Bolted, Cotter, Knuckle, Keys, Couplings</b>) उपयोग होते हैं।",
      "points": [
        "<b>Riveted Joint:</b> <b>Lap Joint</b> (प्लेटें एक के ऊपर एक) और <b>Butt Joint</b> (प्लेटें आमने-सामने + Cover Plate)। विफलता के 3 मुख्य तरीके: Tearing of plate, Shearing of rivet, Crushing।",
        "<b>Fillet Weld:</b> विफलता हमेशा न्यूनतम काट <b>Throat (t = 0.707 · s)</b> पर Shear से होती है। Transverse Weld Tensile और Parallel Weld Shear झेलता है।",
        "<b>Cotter Joint:</b> दो को-एक्सियल छड़ों (Co-axial rods) को जोड़ता है जो <b>Tension या Compression</b> झेलती हैं (रोटेशन नहीं)।",
        "<b>Knuckle Joint:</b> केवल <b>Tension</b> (अक्षीय खिंचाव) झेलने वाली दो छड़ों को जोड़ता है और थोड़ा कोणीय घुमाव (Angular movement) देता है।",
        "<b>Keys (चाबी):</b> शाफ़्ट व हब के बीच सापेक्ष घूर्णन रोकती है (Shear व Crushing झेलती है)। <b>Woodruff Key</b> (अर्धचंद्राकार) Tapered Shafts में लगती है।"
      ],
      "examples": [
        "ट्रैक्टर-ट्रॉली का जोड़ (जहाँ थोड़ा मुड़ने की गुंजाइश हो और खिंचाव लगे) <b>Knuckle Joint</b> है, और साइकिल के पैडल क्रैंक में <b>Cotter Pin</b> लगती है।"
      ],
      "formulas": [
        "Unwin's Formula (Rivet Diameter): d = 6 · √t (mm)  [जब प्लेट मोटाई t > 8 mm हो]",
        "Efficiency of Riveted Joint: η = Least of (P_t, P_s, P_c) / P_solid",
        "Fillet Weld Throat Thickness: t = s · cos 45° = 0.707 · s  (जहाँ s = Weld Leg Size)",
        "Parallel Fillet Weld Strength: P = 0.707 · s · l · τ  (Double fillet के लिए × 2)"
      ],
      "trick": "<b>जोड़ों की सीधी ट्रिक:</b> <b>Knuckle = केवल Tension</b> (क्योंकि Compression में मुड़ जाएगा!) | <b>Cotter = Tension + Compression</b> | <b>Fillet Weld Throat = 0.707 s</b>!",
      "examFacts": [
        "<b>Caulking और Fullering</b> का उपयोग बॉयलर के Riveted Joints को <b>Leak-Proof (भाप-रोधी)</b> बनाने के लिए किया जाता है।",
        "<b>Sunk Key</b> के मानक आयाम: चौड़ाई w = d/4 और मोटाई t = d/6 (Square Key के लिए w = t = d/4)।",
        "<b>Muff / Sleeve Coupling</b> और <b>Flange Coupling</b> Rigid Couplings हैं; <b>Bushed-Pin Flange Coupling</b> Flexible Coupling है।"
      ],
      "numericals": [
        {
          "q": "16 mm मोटी बॉयलर प्लेटों को जोड़ने के लिए Unwin के सूत्र से Rivet का व्यास (d) निकालें।",
          "given": "t = 16 mm",
          "formula": "d = 6 · √t",
          "sol": "d = 6 × √16 = 6 × 4 = 24 mm",
          "ans": "24 mm"
        }
      ],
      "mcqs": [
        {
          "q": "Fillet Weld में Throat Thickness (t) और Weld Size (s) का संबंध क्या होता है?",
          "opts": [
            "t = 0.5 s",
            "t = 0.707 s",
            "t = 1.414 s",
            "t = s"
          ],
          "ans": 1,
          "exp": "45° समकोण त्रिभुज के कारण न्यूनतम काट Throat Thickness t = s·cos 45° = 0.707 s होती है।"
        },
        {
          "q": "निम्न में से कौन-सा जोड़ मुख्यतः केवल Tensile Load (खिंचाव) सहने के लिए उपयोग होता है?",
          "opts": [
            "Cotter Joint",
            "Knuckle Joint",
            "Flange Coupling",
            "Riveted Butt Joint"
          ],
          "ans": 1,
          "exp": "Knuckle Joint में पिन पर मुड़ने की आज़ादी होती है, इसलिए यह केवल Tensile Load सहता है।"
        }
      ]
    },
    {
      "id": "dom_springs",
      "title": "Helical & Leaf Springs (स्प्रिंग अभिकल्पन)",
      "subtitle": "Spring Index • Wahl Factor • Stiffness • Series & Parallel Springs",
      "diagram": "joints_springs",
      "def": "<b>Spring</b> एक प्रत्यास्थ अवयव (Elastic Member) है जो लोड लगने पर झटके की ऊर्जा सोखता है और लोड हटने पर पुनः अपनी आकृति प्राप्त कर लेता है।",
      "points": [
        "<b>Close-Coiled Helical Spring:</b> तार मुख्य रूप से <b>Torsional Shear Stress</b> झेलता है (Helix Angle < 10°)।",
        "<b>Spring Index (C = D / d):</b> कॉइल के औसत व्यास (D) और तार के व्यास (d) का अनुपात (आदर्श मान: <b>4 से 12</b>)।",
        "<b>Wahl Stress Factor (K):</b> यह Direct Shear और तार की वक्रता (Curvature Effect) दोनों के कारण बढ़े हुए तनाव को दर्शाता है।",
        "<b>Leaf Spring (पत्ती स्प्रिंग):</b> ट्रक व गाड़ियों के सस्पेंशन में लगती है — यह <b>Uniform Strength Beam</b> की तरह Bending झेलती है।",
        "<b>Nipping of Leaf Spring:</b> मास्टर लीफ़ व अन्य पत्तियों के बीच शुरुआती गैप रखकर बोल्ट कसना ताकि सभी पत्तियों पर प्रतिबल समान (Equalize) हो सके।"
      ],
      "examples": [
        "बाइक का शॉकर <b>Helical Compression Spring</b> है और ट्रक के पहियों के ऊपर लगी लोहे की पत्तियाँ <b>Semi-Elliptic Leaf Spring</b> हैं।"
      ],
      "formulas": [
        "Max Shear Stress in Helical Spring: τ = K · (8 W D) / (π d³)  [जहाँ Wahl Factor K = (4C−1)/(4C−4) + 0.615/C]",
        "Deflection: δ = (8 W D³ n) / (G d⁴) = (8 W C³ n) / (G d)",
        "Spring Stiffness (Rate): k = W / δ = (G d⁴) / (8 D³ n)  ⇒  k ∝ 1 / n",
        "Springs in Series: 1/k_eq = 1/k₁ + 1/k₂  |  Springs in Parallel: k_eq = k₁ + k₂"
      ],
      "trick": "<b>स्प्रिंग काटने की ट्रिक (बहुत बार पूछा गया!):</b> अगर <b>k</b> स्टिफ़नेस वाली स्प्रिंग को <b>2 बराबर टुकड़ों</b> में काट दिया जाए (n आधा हो जाए), तो हर टुकड़े की स्टिफ़नेस <b>दोगुनी (2k)</b> हो जाती है क्योंकि k ∝ 1/n!",
      "examFacts": [
        "यदि दो समान स्प्रिंग (प्रत्येक की स्टिफ़नेस k) को <b>Parallel</b> जोड़ें तो k_eq = 2k, और <b>Series</b> जोड़ें तो k_eq = k/2।",
        "<b>Open-Coiled Helical Spring</b> में तार पर Torsion और Bending दोनों लगते हैं।"
      ],
      "numericals": [
        {
          "q": "एक Helical Spring की Stiffness 40 N/mm है। यदि इसे बीच से काटकर 2 बराबर भागों में बाँट दिया जाए और दोनों भागों को Parallel जोड़ दिया जाए, तो नई Stiffness क्या होगी?",
          "given": "मूल k = 40 N/mm;  2 बराबर टुकड़े ⇒ प्रत्येक टुकड़े की स्टिफ़नेस = 2k",
          "formula": "k_piece = 2k ;  k_parallel = k_piece + k_piece",
          "sol": "प्रत्येक टुकड़ा = 2 × 40 = 80 N/mm.  Parallel में जोड़ने पर k_eq = 80 + 80 = 160 N/mm",
          "ans": "160 N/mm (मूल का 4 गुना!)"
        }
      ],
      "mcqs": [
        {
          "q": "Close-Coiled Helical Spring का तार मुख्यतः किस प्रतिबल के अधीन होता है?",
          "opts": [
            "Tensile Stress",
            "Compressive Stress",
            "Torsional Shear Stress",
            "Bending Stress"
          ],
          "ans": 2,
          "exp": "Close-Coiled Helical Spring में अक्षीय लोड W के कारण तार में मुख्यतः मरोड़ कर्तन प्रतिबल (Torsional Shear Stress) उत्पन्न होता है।"
        },
        {
          "q": "यदि एक स्प्रिंग (stiffness = k) को दो बराबर टुकड़ों में काट दिया जाए, तो प्रत्येक टुकड़े की stiffness कितनी होगी?",
          "opts": [
            "k / 2",
            "k",
            "2k",
            "4k"
          ],
          "ans": 2,
          "exp": "चूँकि k = Gd⁴ / (8D³n), इसलिए फेरों की संख्या n आधी होने पर स्टिफ़नेस दोगुनी (2k) हो जाती है।"
        }
      ]
    },
    {
      "id": "dom_bearings",
      "title": "Journal & Rolling Contact Bearings (बेयरिंग्स)",
      "subtitle": "Hydrodynamic Lubrication • Sommerfeld Number • Bearing Life L10",
      "diagram": "bearings",
      "def": "<b>Bearing</b> वह मशीन अवयव है जो घूमने वाली शाफ़्ट को सहारा देता है और घर्षण (Friction) को कम करते हुए लोड को फ्रेम तक पहुँचाता है।",
      "points": [
        "<b>Sliding Contact (Journal Bearing):</b> शाफ़्ट व बेयरिंग के बीच तेल की पतली फिल्म (Hydrodynamic Lubrication) होती है — उच्च गति व भारी लोड (जैसे Steam Turbine शाफ़्ट) के लिए सर्वोत्तम।",
        "<b>Hydrostatic Bearing:</b> इसमें बाहरी पंप द्वारा दबाव से तेल भेजा जाता है (शून्य स्पीड पर भी घर्षण नहीं)।",
        "<b>Rolling Contact (Anti-Friction) Bearing:</b> <b>Ball Bearing</b> (Point Contact — हल्का लोड, उच्च स्पीड) और <b>Roller Bearing</b> (Line Contact — भारी लोड)।",
        "<b>Rating Life (L₁₀):</b> वह जीवनकाल (Million Revolutions में) जिसे किसी समूह के <b>90% बेयरिंग</b> बिना थकान (Fatigue) के पूरा कर लेते हैं।"
      ],
      "examples": [
        "पावर प्लांट की विशाल स्टीम टरबाइन में <b>Hydrodynamic Journal Bearing</b> और छत के पंखे व बाइक के पहिए में <b>Ball Bearing</b> लगी होती है।"
      ],
      "formulas": [
        "Bearing Life Equation: L₁₀ = (C / P)^k  (Million Revolutions)  [जहाँ C = Dynamic Load Capacity, P = Equivalent Load]",
        "Exponent k: <b>Ball Bearing के लिए k = 3</b>  |  <b>Roller Bearing के लिए k = 10/3 (3.33)</b>",
        "Sommerfeld Number: S = (r / c)² · (μ N / p)  [Dimensionless]",
        "Bearing Characteristic Number = Z·N / p  (McKee Equation / Petroff's Equation)"
      ],
      "trick": "<b>बेयरिंग लोड-लाइफ़ ट्रिक:</b> Ball Bearing (k = 3) पर अगर <b>लोड आधा (P/2)</b> कर दिया जाए, तो उसकी ज़िंदगी <b>2³ = 8 गुना</b> बढ़ जाती है! और लोड दोगुना करने पर ज़िंदगी <b>1/8</b> रह जाती है!",
      "examFacts": [
        "<b>Thrust Bearing</b> का उपयोग शाफ़्ट के अक्ष के समानांतर लगने वाले <b>Axial Load</b> को सहने के लिए किया जाता है।",
        "<b>Tapered Roller Bearing</b> भारी Radial और Axial दोनों लोड एक साथ झेल सकती है।",
        "<b>Babbitt Metal</b> (टिन/लेड आधारित) का उपयोग Journal Bearing की लाइनिंग के लिए होता है क्योंकि इसमें Embeddability बहुत अच्छी होती है।"
      ],
      "numericals": [
        {
          "q": "एक Ball Bearing की Dynamic Load Capacity C = 20 kN है और उस पर Equivalent Load P = 10 kN लग रहा है। इसकी Rating Life (L₁₀) निकालें।",
          "given": "C = 20 kN, P = 10 kN, Ball Bearing ⇒ k = 3",
          "formula": "L₁₀ = (C / P)³ Million Revolutions",
          "sol": "L₁₀ = (20 / 10)³ = (2)³ = 8 Million Revolutions (8 × 10⁶ चक्कर)",
          "ans": "8 Million Revolutions"
        }
      ],
      "table": {
        "headers": [
          "गुण (Property)",
          "Ball Bearing",
          "Roller Bearing",
          "Journal Bearing"
        ],
        "rows": [
          [
            "संपर्क (Contact)",
            "Point Contact",
            "Line Contact",
            "Area (Oil Film)"
          ],
          [
            "लोड क्षमता",
            "हल्का / मध्यम",
            "भारी लोड",
            "अत्यंत भारी + उच्च गति"
          ],
          [
            "शुरुआती घर्षण",
            "बहुत कम (Anti-friction)",
            "कम",
            "अधिक (Starting में)"
          ],
          [
            "Life Exponent (k)",
            "k = 3",
            "k = 10/3 (3.33)",
            "थकान सीमा नहीं"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "यदि किसी Ball Bearing पर लगने वाले लोड को आधा (Half) कर दिया जाए, तो उसकी Rating Life कितनी गुनी हो जाएगी?",
          "opts": [
            "2 गुनी",
            "4 गुनी",
            "8 गुनी",
            "10 गुनी"
          ],
          "ans": 2,
          "exp": "L₁₀ = (C/P)³; लोड आधा करने पर (2)³ = 8 गुना जीवनकाल बढ़ जाता है।"
        },
        {
          "q": "Hydrodynamic Journal Bearing में कौन-सी विमाहीन संख्या (Dimensionless Number) उपयोग होती है?",
          "opts": [
            "Reynolds Number",
            "Sommerfeld Number",
            "Froude Number",
            "Mach Number"
          ],
          "ans": 1,
          "exp": "Sommerfeld Number S = (r/c)²(μN/p) Journal Bearing के स्नेहन और डिज़ाइन का मुख्य पैरामीटर है।"
        }
      ]
    }
  ]
}
);
