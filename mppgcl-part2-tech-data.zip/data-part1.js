window.MPPGCL_SUBJECTS = window.MPPGCL_SUBJECTS || [];
window.MPPGCL_SUBJECTS.push(
{
  "id": "power_plant",
  "name": "Power Plant Engineering (पावर प्लांट इंजीनियरिंग)",
  "icon": "🏭",
  "category": "tech",
  "weight": "Very High (MPPGCL Core • 15–18 Marks)",
  "topics": [
    {
      "id": "pp_thermal",
      "title": "Thermal Power Plant & 4 Main Circuits (थर्मल पावर प्लांट के 4 परिपथ)",
      "subtitle": "Coal-Ash, Air-Flue Gas, Feed Water-Steam & Cooling Circuits",
      "diagram": "thermal_plant",
      "def": "<b>Thermal Power Plant (तापीय विद्युत संयंत्र)</b> वह संयंत्र है जहाँ कोयले (Coal) की रासायनिक ऊर्जा को जलाकर पहले ऊष्मीय ऊर्जा (Steam), फिर टरबाइन द्वारा यांत्रिक ऊर्जा (Mechanical Energy) और अंत में जनरेटर द्वारा विद्युत ऊर्जा (Electrical Energy) में बदला जाता है। यह <b>Rankine Cycle</b> पर कार्य करता है।",
      "points": [
        "<b>1. Coal & Ash Circuit:</b> Coal Storage → Coal Handling → Pulverizer (कोयले को बारीक पाउडर बनाना) → Boiler Furnace → Ash Handling & ESP (Electrostatic Precipitator)।",
        "<b>2. Air & Flue Gas Circuit:</b> FD Fan → Air Preheater (हवा को गरम करना) → Furnace → Superheater → Economizer → Air Preheater → ESP → ID Fan → Chimney।",
        "<b>3. Feed Water & Steam Circuit:</b> Condenser → Condensate Extraction Pump (CEP) → Low/High Pressure Heaters → Boiler Feed Pump (BFP) → Economizer → Boiler → Superheater → Steam Turbine → Condenser।",
        "<b>4. Cooling Water Circuit:</b> Condenser से गरम पानी Cooling Tower में ठंडा होकर पुनः सर्कुलेट होता है।"
      ],
      "examples": [
        "MPPGCL के बड़े थर्मल पावर प्लांट्स: <b>श्री सिंगाजी (खंडवा)</b>, <b>सतपुड़ा (सारनी, बैतूल)</b>, <b>संजय गांधी (बिरसिंहपुर, उमरिया)</b> और <b>अमरकंटक (चचाई, अनूपपुर)</b>।",
        "Pulverized Coal (पिसा हुआ कोयला) ठीक वैसे ही तेज़ी से जलता है जैसे लकड़ी के बड़े टुकड़े की तुलना में लकड़ी का बुरादा।"
      ],
      "formulas": [
        "Overall Efficiency (η_overall) = η_boiler × η_turbine × η_generator (सामान्यतः 30% – 38%)",
        "Heat Rate = 3600 / η_overall (kJ/kWh)",
        "Plant Load Factor (PLF) = Average Load / Installed Capacity"
      ],
      "trick": "<b>Flue Gas के रास्ते की ट्रिक — 'B-S-E-A-E-C':</b> <b>B</b>oiler → <b>S</b>uperheater → <b>E</b>conomizer → <b>A</b>ir Preheater → <b>E</b>SP → <b>C</b>himney (इसी क्रम में धुआँ बाहर निकलता है — MPPGCL में बार-बार क्रम पूछा जाता है!)",
      "examFacts": [
        "<b>ESP (Electrostatic Precipitator)</b> का कार्य फ्लू गैस से <b>Fly Ash (उड़ने वाली राख)</b> को 99% तक हटाना है।",
        "<b>Pulverized Coal</b> का उपयोग करने से दहन दक्षता (Combustion Efficiency) बढ़ती है और कम Excess Air लगती है।",
        "थर्मल पावर प्लांट में सबसे अधिक ऊष्मा की हानि (Maximum Heat Loss ~50%) <b>Condenser</b> में होती है।",
        "<b>Deaerator</b> का कार्य फीड वॉटर से घुली हुई ऑक्सीजन (Dissolved O₂) व CO₂ निकालकर बॉयलर को जंग (Corrosion) से बचाना है।"
      ],
      "table": {
        "headers": [
          "उपकरण (Component)",
          "स्थान (Location)",
          "मुख्य कार्य (Main Function)"
        ],
        "rows": [
          [
            "Superheater",
            "Furnace के पास",
            "Saturated steam को Superheated steam बनाना"
          ],
          [
            "Economizer",
            "Superheater के बाद",
            "Flue gas से Feed water को पहले गरम करना"
          ],
          [
            "Air Preheater",
            "Economizer के बाद",
            "Flue gas से Combustion Air को गरम करना"
          ],
          [
            "ESP",
            "Air Preheater व Chimney के बीच",
            "Fly Ash (धूल/राख) को विद्युत आवेश से पकड़ना"
          ],
          [
            "Cooling Tower",
            "Condenser के बाहर",
            "Condenser के गरम पानी को ठंडा करना"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "Thermal Power Plant में Flue Gas के प्रवाह का सही क्रम (Correct Sequence) क्या है?",
          "opts": [
            "Boiler → Economizer → Superheater → Air Preheater",
            "Boiler → Superheater → Economizer → Air Preheater",
            "Boiler → Air Preheater → Economizer → Superheater",
            "Boiler → ESP → Superheater → Economizer"
          ],
          "ans": 1,
          "exp": "सही क्रम B-S-E-A-E-C है: Boiler → Superheater → Economizer → Air Preheater → ESP → Chimney।"
        },
        {
          "q": "थर्मल पावर प्लांट में अधिकतम ऊष्मा हानि (Maximum Heat Loss) कहाँ होती है?",
          "opts": [
            "Boiler",
            "Turbine",
            "Condenser",
            "Chimney"
          ],
          "ans": 2,
          "exp": "Condenser में भाप की गुप्त ऊष्मा (Latent Heat) ठंडे पानी को दे दी जाती है, जिससे ~50% ऊर्जा नष्ट होती है।"
        },
        {
          "q": "Electrostatic Precipitator (ESP) का मुख्य कार्य क्या है?",
          "opts": [
            "पानी गरम करना",
            "कोयला पीसना",
            "Flue Gas से Fly Ash हटाना",
            "भाप का दबाव बढ़ाना"
          ],
          "ans": 2,
          "exp": "ESP उच्च वोल्टेज इलेक्ट्रोड की मदद से फ्लू गैस में मौजूद Fly Ash कणों को अलग करता है।"
        }
      ]
    },
    {
      "id": "pp_rankine",
      "title": "Rankine Cycle, Reheat & Regeneration (रैंकिन चक्र)",
      "subtitle": "Ideal Vapour Power Cycle • Efficiency • Work Ratio • SSC",
      "diagram": "rankine",
      "def": "<b>Rankine Cycle (रैंकिन चक्र)</b> सभी Steam Power Plants का आदर्श चक्र (Ideal Cycle) है। इसमें कुल 4 प्रक्रम (Processes) होते हैं: <b>2 Reversible Adiabatic (Isentropic)</b> और <b>2 Constant Pressure (Isobaric)</b> प्रक्रम।",
      "points": [
        "<b>Process 1–2 (Turbine):</b> Isentropic Expansion (s = constant) — कार्य मिलता है (W_T = h₁ − h₂)।",
        "<b>Process 2–3 (Condenser):</b> Constant Pressure Heat Rejection (P = constant) — Q_out = h₂ − h₃।",
        "<b>Process 3–4 (Pump):</b> Isentropic Compression — पंप कार्य W_P = h₄ − h₃ = v_f(P₁ − P₂)।",
        "<b>Process 4–1 (Boiler):</b> Constant Pressure Heat Addition — Q_in = h₁ − h₄।",
        "<b>Reheating:</b> टरबाइन में भाप की नमी (Moisture) कम करती है और Work Output बढ़ाती है।",
        "<b>Regeneration (Feed Water Heating):</b> Mean Temperature of Heat Addition बढ़ाकर <b>Thermal Efficiency</b> बढ़ाती है और Carnot के करीब लाती है।"
      ],
      "examples": [
        "घरेलू प्रेशर कुकर की भाप जब सीटी को ऊपर उठाती है, तो ऊष्मा से यांत्रिक कार्य बनता है — यही सिद्धांत बड़े स्केल पर रैंकिन चक्र में चलता है।"
      ],
      "formulas": [
        "W_net = W_T − W_P = (h₁ − h₂) − (h₄ − h₃)",
        "η_Rankine = W_net / Q_in = [(h₁ − h₂) − W_P] / (h₁ − h₄)",
        "Work Ratio (WR) = W_net / W_T (Rankine में बहुत उच्च ~0.99)",
        "Specific Steam Consumption (SSC) = 3600 / W_net (kg/kWh)",
        "Pump Work W_P = v_f × (P_boiler − P_condenser) (kJ/kg, जब P kPa में हो)"
      ],
      "trick": "<b>दक्षता बढ़ाने के 3 मंत्र — 'B↑ C↓ S↑':</b> <b>B</b>oiler Pressure बढ़ाओ, <b>C</b>ondenser Pressure घटाओ, और <b>S</b>uperheating बढ़ाओ — तीनों से रैंकिन दक्षता (η) बढ़ती है!",
      "examFacts": [
        "Rankine Cycle की तुलना में Carnot Cycle में <b>Pump Work अधिक</b> होता है (गीली भाप को दबाना कठिन है), इसलिए व्यावहारिक प्लांट रैंकिन चक्र पर चलते हैं।",
        "<b>Reheating</b> करने से हमेशा <b>Dryness Fraction (x) बढ़ता है</b> (ब्लेड इरोजन कम होता है), लेकिन Efficiency थोड़ी बढ़ या घट भी सकती है।",
        "<b>Regenerative Cycle</b> में टरबाइन से बीच में भाप निकालकर (Bleeding) फीड वॉटर गरम किया जाता है — इससे <b>η बढ़ती है</b>, लेकिन प्रति kg भाप Work Output घटता है।"
      ],
      "numericals": [
        {
          "q": "एक Rankine Cycle में Turbine Work = 950 kJ/kg, Pump Work = 10 kJ/kg और Boiler में दी गई ऊष्मा Q_in = 2800 kJ/kg है। Cycle Efficiency व SSC निकालें।",
          "given": "W_T = 950 kJ/kg, W_P = 10 kJ/kg, Q_in = 2800 kJ/kg",
          "formula": "W_net = W_T − W_P;  η = (W_net / Q_in) × 100;  SSC = 3600 / W_net",
          "sol": "W_net = 950 − 10 = 940 kJ/kg.  η = (940 / 2800) × 100 = 33.57%.  SSC = 3600 / 940 = 3.83 kg/kWh",
          "ans": "η = 33.57% और SSC = 3.83 kg/kWh"
        },
        {
          "q": "बॉयलर दाब 40 bar और कंडेंसर दाब 0.1 bar पर पंप कार्य (Pump Work) निकालें (v_f = 0.001 m³/kg)।",
          "given": "P₁ = 40 bar = 4000 kPa, P₂ = 0.1 bar = 10 kPa, v_f = 0.001 m³/kg",
          "formula": "W_P = v_f × (P₁ − P₂)",
          "sol": "W_P = 0.001 × (4000 − 10) = 0.001 × 3990 = 3.99 kJ/kg",
          "ans": "3.99 kJ/kg (लगभग 4 kJ/kg)"
        }
      ],
      "mcqs": [
        {
          "q": "Rankine Cycle में कौन-कौन से प्रक्रम (Processes) होते हैं?",
          "opts": [
            "2 Isothermal + 2 Isobaric",
            "2 Isentropic + 2 Isobaric",
            "2 Isentropic + 2 Isochoric",
            "2 Isothermal + 2 Isentropic"
          ],
          "ans": 1,
          "exp": "Rankine Cycle में 2 Isentropic (Turbine, Pump) और 2 Constant Pressure/Isobaric (Boiler, Condenser) प्रक्रम होते हैं।"
        },
        {
          "q": "Steam Power Plant में Reheating का मुख्य उद्देश्य क्या है?",
          "opts": [
            "Condenser का आकार बढ़ाना",
            "Turbine ब्लेड्स पर नमी (Moisture) कम करना",
            "Pump Work बढ़ाना",
            "Boiler Pressure कम करना"
          ],
          "ans": 1,
          "exp": "Reheating से भाप का Dryness Fraction बढ़ता है, जिससे टरबाइन के अंतिम स्टेज के ब्लेड्स का कटाव (Erosion) रुकता है।"
        },
        {
          "q": "Condenser Pressure घटाने से Rankine Cycle की Efficiency पर क्या प्रभाव पड़ता है?",
          "opts": [
            "बढ़ती है",
            "घटती है",
            "कोई बदलाव नहीं",
            "शून्य हो जाती है"
          ],
          "ans": 0,
          "exp": "Condenser Pressure घटाने से Heat Rejection का तापमान घटता है, जिससे Net Work और Efficiency दोनों बढ़ते हैं।"
        }
      ]
    },
    {
      "id": "pp_boilers",
      "title": "Steam Boilers, Mountings & Accessories (बॉयलर, माउंटिंग्स व एक्सेसरीज़)",
      "subtitle": "Fire-Tube vs Water-Tube • High Pressure Boilers • IBR Rules",
      "diagram": "boiler",
      "def": "<b>Steam Boiler (भाप बॉयलर)</b> एक बंद दबाव पात्र (Closed Pressure Vessel) है जो ईंधन की ऊष्मा से पानी को उच्च दाब व तापमान की भाप में बदलता है। <b>Indian Boiler Regulation (IBR)</b> के अनुसार बॉयलर का आयतन 22.75 लीटर से अधिक होता है।",
      "points": [
        "<b>Fire-Tube Boiler:</b> गरम गैसें ट्यूब के <b>अंदर</b> और पानी बाहर होता है — उदाहरण: <b>Cochran, Lancashire, Cornish, Locomotive, Scotch Marine</b>। (दबाव < 25 bar)।",
        "<b>Water-Tube Boiler:</b> पानी ट्यूब के <b>अंदर</b> और गरम गैसें बाहर होती हैं — उदाहरण: <b>Babcock & Wilcox, Stirling, La-Mont, Benson, Loeffler, Velox</b>। (उच्च दाब व बड़े पावर प्लांट्स)।",
        "<b>Boiler Mountings (अनिवार्य सुरक्षा उपकरण):</b> इनके बिना बॉयलर नहीं चल सकता (7 मुख्य माउंटिंग्स)।",
        "<b>Boiler Accessories (दक्षता बढ़ाने वाले उपकरण):</b> ये बॉयलर की Efficiency बढ़ाते हैं (Economizer, Superheater, Air Preheater, Feed Pump, Injector)।"
      ],
      "examples": [
        "<b>Benson Boiler</b> एक Supercritical Once-Through Boiler है जिसमें <b>कोई Steam Drum नहीं होता</b> (दबाव > 221.2 bar) — आधुनिक 660 MW MPPGCL यूनिट्स में यही तकनीक लगती है।"
      ],
      "formulas": [
        "Equivalent Evaporation (m_e) = m_a × (h − h_f1) / 2257 (kg of steam/kg of fuel)",
        "Factor of Evaporation (F_e) = (h − h_f1) / 2257",
        "Boiler Efficiency (η_b) = [m_a × (h − h_f1)] / (m_f × CV)"
      ],
      "trick": "<b>Fire-Tube बॉयलर की ट्रिक — 'Simple C-C-L-L':</b> <b>S</b>cotch Marine, <b>C</b>ochran, <b>C</b>ornish, <b>L</b>ancashire, <b>L</b>ocomotive — बाक़ी सभी (Babcock, Benson, La-Mont, Loeffler, Stirling) <b>Water-Tube</b> हैं! <br/><b>Mountings vs Accessories:</b> जो <b>सुरक्षा (Safety)</b> करे वो Mounting (जैसे Fusible Plug, Safety Valve), जो <b>पैसा/ईंधन बचाए</b> वो Accessory (जैसे Economizer)!",
      "examFacts": [
        "<b>Fusible Plug</b> (गनमेटल + टिन मिश्रधातु) बॉयलर को <b>कम पानी (Low Water Level)</b> के कारण फटने से बचाता है।",
        "<b>Blow-off Cock</b> का कार्य बॉयलर की तली में जमी कीचड़/तलछट (Mud/Sediments) को बाहर निकालना है।",
        "<b>La-Mont</b> और <b>Benson</b> Forced Circulation बॉयलर हैं; <b>Benson Boiler</b> में Steam Drum नहीं होता।",
        "<b>Loeffler Boiler</b> में भाप का निर्माण पहले से सुपरहीटेड भाप द्वारा पानी को गरम करके किया जाता है (नमक जमाव रोकने के लिए)।"
      ],
      "numericals": [
        {
          "q": "एक बॉयलर 1 kg कोयला जलाकर 8 kg भाप बनाता है। यदि भाप की एन्थैल्पी h = 2757 kJ/kg और फीड वॉटर की h_f1 = 500 kJ/kg हो, तो Equivalent Evaporation निकालें।",
          "given": "m_a = 8 kg/kg fuel, h = 2757 kJ/kg, h_f1 = 500 kJ/kg",
          "formula": "m_e = m_a × (h − h_f1) / 2257",
          "sol": "m_e = 8 × (2757 − 500) / 2257 = 8 × (2257 / 2257) = 8 kg/kg fuel",
          "ans": "8 kg of steam per kg of fuel"
        }
      ],
      "table": {
        "headers": [
          "Boiler Mountings (सुरक्षा - अनिवार्य)",
          "Boiler Accessories (दक्षता - वैकल्पिक)"
        ],
        "rows": [
          [
            "Safety Valve (अतिरिक्त दाब छोड़ना)",
            "Economizer (फीड वॉटर गरम करना)"
          ],
          [
            "Water Level Indicator (जल स्तर देखना)",
            "Superheater (भाप का तापमान बढ़ाना)"
          ],
          [
            "Pressure Gauge (Bourdon Tube)",
            "Air Preheater (हवा को गरम करना)"
          ],
          [
            "Fusible Plug (ओवरहीटिंग से बचाव)",
            "Feed Pump (उच्च दाब पर पानी भेजना)"
          ],
          [
            "Blow-off Cock & Feed Check Valve",
            "Steam Injector & Steam Separator"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "निम्न में से किस High Pressure Boiler में कोई Steam Drum नहीं होता?",
          "opts": [
            "La-Mont Boiler",
            "Benson Boiler",
            "Loeffler Boiler",
            "Babcock & Wilcox"
          ],
          "ans": 1,
          "exp": "Benson Boiler एक Supercritical Once-Through बॉयलर है (> 221.2 bar) जहाँ पानी बिना उबले सीधे भाप बन जाता है, इसलिए Drum की ज़रूरत नहीं होती।"
        },
        {
          "q": "निम्न में से कौन-सा Boiler Mounting नहीं है (अर्थात् Accessory है)?",
          "opts": [
            "Fusible Plug",
            "Blow-off Cock",
            "Economizer",
            "Feed Check Valve"
          ],
          "ans": 2,
          "exp": "Economizer बॉयलर की दक्षता बढ़ाने वाला Accessory है, जबकि बाकी तीनों अनिवार्य सुरक्षा Mountings हैं।"
        },
        {
          "q": "Cochran Boiler किस प्रकार का बॉयलर है?",
          "opts": [
            "Horizontal Water-Tube",
            "Vertical Fire-Tube",
            "High Pressure Forced Circulation",
            "Supercritical"
          ],
          "ans": 1,
          "exp": "Cochran एक Vertical, Multi-tubular, Fire-Tube, Natural Circulation बॉयलर है।"
        }
      ]
    },
    {
      "id": "pp_steam_turbines",
      "title": "Steam Turbines — Impulse, Reaction & Compounding (स्टीम टरबाइन)",
      "subtitle": "De-Laval, Parsons • Degree of Reaction • Velocity & Pressure Compounding",
      "diagram": "turbine_impulse_reaction",
      "def": "<b>Steam Turbine (भाप टरबाइन)</b> उच्च दाब की भाप की तापीय ऊर्जा को पहले गतिज ऊर्जा (Kinetic Energy) और फिर रोटर ब्लेड्स द्वारा घूर्णी यांत्रिक ऊर्जा (Rotational Work) में बदलती है।",
      "points": [
        "<b>Impulse Turbine (जैसे De-Laval):</b> पूरा Pressure Drop केवल <b>Nozzle</b> में होता है। Moving Blades में दाब नियत (Constant Pressure) रहता है।",
        "<b>Reaction Turbine (जैसे Parsons):</b> Pressure Drop <b>Fixed Blades और Moving Blades दोनों</b> में होता है।",
        "<b>Degree of Reaction (R):</b> Moving Blades में Enthalpy Drop ÷ कुल Stage Enthalpy Drop। Impulse के लिए <b>R = 0</b>, और Parsons (50% Reaction) के लिए <b>R = 0.5</b> होता है।",
        "<b>Compounding (रोटर की गति कम करने हेतु):</b> 1) <b>Velocity Compounding (Curtis)</b>, 2) <b>Pressure Compounding (Rateau)</b>, 3) <b>Pressure-Velocity Compounding</b>।"
      ],
      "examples": [
        "बच्चों की कागज़ की फिरकी पर फूँक मारना <b>Impulse</b> है, और बगीचे का घूमने वाला पानी का फव्वारा (Lawn Sprinkler) <b>Reaction</b> सिद्धांत का उदाहरण है।"
      ],
      "formulas": [
        "Degree of Reaction (R) = Δh_moving / (Δh_fixed + Δh_moving)",
        "Optimum Blade Speed Ratio (ρ = u/V₁): Impulse = (cos α)/2 ; Parsons Reaction = cos α",
        "Maximum Blade Efficiency (η_max): Impulse = cos²α ; Parsons Reaction = (2 cos²α) / (1 + cos²α)",
        "Diagram Efficiency = 2u(V_w1 + V_w2) / V₁²"
      ],
      "trick": "<b>Compounding याद रखने की ट्रिक — 'Cu-Ve, Ra-Pre':</b> <b>Cu</b>rtis = <b>Ve</b>locity Compounding, <b>Ra</b>teau = <b>Pre</b>ssure Compounding! और <b>Parsons = 50% (R = 0.5)</b>।",
      "examFacts": [
        "De-Laval Impulse Turbine की गति बहुत अधिक (लगभग 30,000 RPM) होती है, जिसे कम करने के लिए <b>Compounding</b> की जाती है।",
        "Parsons Reaction Turbine में Fixed और Moving Blades की आकृति एक समान (Symmetrical: α = β₂, θ = φ) होती है।",
        "Steam Turbine Governing के 3 तरीके: <b>Throttle Governing</b>, <b>Nozzle Control Governing</b>, और <b>By-pass Governing</b> (Overload के लिए)।"
      ],
      "numericals": [
        {
          "q": "एक Single-Stage Impulse Turbine का Nozzle Angle α = 20° है (cos 20° = 0.94)। इसकी Maximum Blade Efficiency और Optimum Speed Ratio निकालें।",
          "given": "α = 20°, cos 20° = 0.94",
          "formula": "ρ_opt = (cos α)/2 ;  η_max = cos²α",
          "sol": "ρ_opt = 0.94 / 2 = 0.47.  η_max = (0.94)² = 0.8836 = 88.36%",
          "ans": "ρ_opt = 0.47 और η_max = 88.36%"
        }
      ],
      "mcqs": [
        {
          "q": "Parsons Steam Turbine के लिए Degree of Reaction (R) का मान कितना होता है?",
          "opts": [
            "0",
            "0.5 (50%)",
            "1.0 (100%)",
            "0.25"
          ],
          "ans": 1,
          "exp": "Parsons Turbine एक 50% Reaction Turbine है जिसमें आधा एन्थैल्पी ड्रॉप Fixed Blades में और आधा Moving Blades में होता है।"
        },
        {
          "q": "Curtis Turbine किस प्रकार की Compounding का उदाहरण है?",
          "opts": [
            "Pressure Compounding",
            "Velocity Compounding",
            "Reaction Stage",
            "Throttle Governing"
          ],
          "ans": 1,
          "exp": "ट्रिक 'Cu-Ve, Ra-Pre': Curtis = Velocity Compounding और Rateau = Pressure Compounding।"
        },
        {
          "q": "Impulse Turbine की अधिकतम ब्लेड दक्षता (Maximum Blade Efficiency) का सूत्र क्या है?",
          "opts": [
            "sin²α",
            "cos²α",
            "(cos α)/2",
            "2 cos²α / (1 + cos²α)"
          ],
          "ans": 1,
          "exp": "Single-stage Impulse Turbine के लिए η_max = cos²α होता है जब ρ = (cos α)/2 हो।"
        }
      ]
    },
    {
      "id": "pp_condensers",
      "title": "Condensers, Cooling Towers & Boiler Draught (कंडेंसर व ड्राफ्ट)",
      "subtitle": "Surface vs Jet Condenser • Vacuum Efficiency • Chimney Draught",
      "diagram": "condenser",
      "def": "<b>Steam Condenser (भाप संघनित्र)</b> टरबाइन से निकलने वाली Exhaust Steam को वायुमंडलीय दाब से नीचे (Vacuum में) ठंडा करके शुद्ध पानी (Condensate) में बदलता है, जिससे टरबाइन का कार्य बढ़ता है और शुद्ध पानी दोबारा बॉयलर में भेजा जा सके।",
      "points": [
        "<b>Jet Condenser (Mixing Type):</b> भाप और ठंडा पानी सीधे आपस में मिलते हैं — सस्ता है, लेकिन Condensate शुद्ध नहीं रहता (बॉयलर में सीधे उपयोग नहीं)।",
        "<b>Surface Condenser (Non-Mixing Type):</b> भाप और ठंडा पानी अलग-अलग रहते हैं (ट्यूब के अंदर पानी, बाहर भाप)। सभी बड़े Thermal Power Plants में यही उपयोग होता है।",
        "<b>Boiler Draught (ड्राफ्ट):</b> भट्ठी में हवा भेजने और धुआँ निकालने के लिए बनाया गया दाब अंतर (Pressure Difference)।",
        "<b>Balanced Draught (FD + ID Fan):</b> बड़े पावर प्लांट्स में सबसे उत्तम — भट्ठी में दाब वायुमंडलीय दाब से थोड़ा कम रखा जाता है ताकि आग बाहर न निकले।"
      ],
      "examples": [
        "थर्मल पावर प्लांट के बाहर दिखने वाले बड़े <b>Hyperbolic Towers</b> असल में चिमनी नहीं, बल्कि <b>Natural Draught Cooling Towers</b> होते हैं जिनसे सफ़ेद भाप निकलती है।"
      ],
      "formulas": [
        "Vacuum Efficiency (η_v) = Actual Vacuum / Ideal Vacuum = P_vac / (P_baro − P_steam)",
        "Condenser Efficiency (η_c) = (t_wo − t_wi) / (t_s − t_wi)",
        "Chimney Height condition for Max Discharge: T_g / T_a = 2(m+1)/m  (लगभग T_g ≈ 600 K)"
      ],
      "trick": "<b>FD vs ID Fan की ट्रिक:</b> <b>F</b>D (Forced) = <b>F</b>ront (हवा को अंदर धकेलेगा, ठंडी हवा, कम बिजली)। <b>I</b>D (Induced) = <b>I</b>nside से बाहर खींचेगा (चिमनी के पास, गरम धुआँ, ज़्यादा बिजली)!",
      "examFacts": [
        "<b>Surface Condenser</b> में शुद्ध Condensate प्राप्त होने के कारण इसकी Vacuum Capacity बहुत उच्च होती है।",
        "चिमनी द्वारा प्राप्त अधिकतम डिस्चार्ज (Maximum Discharge) की स्थिति में Chimney Efficiency बहुत कम (< 1%) होती है।",
        "<b>Steam Jet Ejector</b> का उपयोग कंडेंसर से हवा (Air) निकालकर वैक्यूम बनाए रखने में किया जाता है।"
      ],
      "numericals": [
        {
          "q": "एक कंडेंसर में Barometer Reading = 760 mm Hg, Actual Vacuum = 700 mm Hg और भाप के तापमान पर Saturation Pressure = 40 mm Hg है। Vacuum Efficiency निकालें।",
          "given": "P_baro = 760 mm Hg, Actual Vacuum = 700 mm Hg, P_s = 40 mm Hg",
          "formula": "η_v = Actual Vacuum / (P_baro − P_s)",
          "sol": "Ideal Vacuum = 760 − 40 = 720 mm Hg.  η_v = (700 / 720) × 100 = 97.22%",
          "ans": "97.22%"
        }
      ],
      "mcqs": [
        {
          "q": "बड़े थर्मल पावर प्लांट्स में किस प्रकार का Condenser उपयोग किया जाता है?",
          "opts": [
            "Parallel Flow Jet",
            "Barometric Jet",
            "Surface Condenser",
            "Ejector Condenser"
          ],
          "ans": 2,
          "exp": "Surface Condenser में भाप व ठंडा पानी नहीं मिलते, जिससे 100% शुद्ध Condensate दोबारा बॉयलर में उपयोग हो जाता है।"
        },
        {
          "q": "Balanced Draught System में कौन-से पंखे उपयोग होते हैं?",
          "opts": [
            "केवल FD Fan",
            "केवल ID Fan",
            "FD Fan और ID Fan दोनों",
            "केवल चिमनी"
          ],
          "ans": 2,
          "exp": "Balanced Draught में FD Fan (हवा धकेलने) और ID Fan (धुआँ खींचने) दोनों लगे होते हैं।"
        }
      ]
    },
    {
      "id": "pp_hydro_nuclear",
      "title": "Hydro, Nuclear & Gas Power Plants (जल, परमाणु व गैस संयंत्र)",
      "subtitle": "Penstock, Surge Tank • Moderator, Control Rods • Brayton Cycle",
      "diagram": "mp_power_map",
      "def": "थर्मल के अलावा बिजली उत्पादन के तीन प्रमुख संयंत्र <b>Hydroelectric (जल विद्युत)</b>, <b>Nuclear (परमाणु ऊर्जा)</b> और <b>Gas Turbine Power Plant</b> हैं। MPPGCL में हाइड्रो और न्यूक्लियर के घटकों से सीधे प्रश्न आते हैं।",
      "points": [
        "<b>Hydro Power Plant:</b> Reservoir → Dam → <b>Penstock</b> (हाई प्रेशर पाइप) → <b>Surge Tank</b> (Water Hammer से बचाव) → Turbine → <b>Draft Tube</b> (Reaction Turbine में) → Tail Race।",
        "<b>Nuclear Power Plant (Fission - विखंडन):</b> Fuel = <b>U-235, Pu-239</b>। <b>Moderator</b> (तेज़ न्यूट्रॉन को धीमा करने हेतु): Heavy Water (D₂O), Graphite, Beryllium।",
        "<b>Control Rods (चेन रिएक्शन नियंत्रित करने हेतु):</b> <b>Cadmium (Cd)</b> या <b>Boron (B)</b> — अतिरिक्त न्यूट्रॉन सोखती हैं।",
        "<b>Coolant (ऊष्मा बाहर ले जाने हेतु):</b> Water, CO₂, Liquid Sodium (Fast Breeder Reactor में)।"
      ],
      "examples": [
        "मध्य प्रदेश में प्रमुख जल विद्युत संयंत्र: <b>गांधी सागर (चंबल नदी)</b>, <b>बाणसागर (सोन नदी)</b>, <b>इंदिरा सागर व ओंकारेश्वर (नर्मदा नदी)</b>, और <b>पेंच व बरगी</b>।"
      ],
      "formulas": [
        "Hydro Power Output (P) = η × ρ × g × Q × H (Watts)",
        "Brayton Cycle (Gas Turbine) Efficiency: η = 1 − 1 / (r_p)^((γ−1)/γ)",
        "Optimum Pressure Ratio for Max Work in Brayton Cycle: r_p = (T_max / T_min)^(γ / [2(γ−1)])"
      ],
      "trick": "<b>Nuclear के 2 पक्के सवाल — 'Mo-DG' & 'Co-BC':</b> <b>Mo</b>derator = <b>D</b>₂O (Heavy Water) व <b>G</b>raphite; <b>Co</b>ntrol Rod = <b>B</b>oron व <b>C</b>admium!",
      "examFacts": [
        "<b>Surge Tank</b> को Penstock पर लगाया जाता है ताकि अचानक लोड घटने पर <b>Water Hammer (जल आघात)</b> से पाइप न फटे।",
        "<b>Fast Breeder Reactor (FBR)</b> में <b>कोई Moderator नहीं होता</b> और Coolant के रूप में <b>Liquid Sodium</b> उपयोग होता है।",
        "Hydro Power Plant <b>Peak Load</b> और Base Load दोनों के लिए उपयुक्त है क्योंकि यह 2–3 मिनट में चालू हो जाता है, जबकि Nuclear केवल <b>Base Load</b> प्लांट है।"
      ],
      "table": {
        "headers": [
          "प्लांट प्रकार",
          "मुख्य उपयोग (Load)",
          "Initial Cost",
          "Running Cost"
        ],
        "rows": [
          [
            "Thermal (Coal)",
            "Base Load",
            "मध्यम",
            "अधिक (कोयला)"
          ],
          [
            "Hydroelectric",
            "Base & Peak Load",
            "अधिक (बाँध)",
            "सबसे कम (निःशुल्क पानी)"
          ],
          [
            "Nuclear",
            "केवल Base Load",
            "सबसे अधिक",
            "बहुत कम"
          ],
          [
            "Diesel / Gas",
            "Peak / Standby Load",
            "सबसे कम",
            "सबसे अधिक"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "Hydroelectric Power Plant में Surge Tank का मुख्य कार्य क्या है?",
          "opts": [
            "पानी साफ करना",
            "Water Hammer से Penstock की रक्षा करना",
            "बिजली स्टोर करना",
            "टरबाइन की स्पीड बढ़ाना"
          ],
          "ans": 1,
          "exp": "जब टरबाइन का वॉल्व अचानक बंद होता है, तो Penstock में भारी दबाव तरंग (Water Hammer) बनती है जिसे Surge Tank सोख लेता है।"
        },
        {
          "q": "Nuclear Reactor में Control Rods किस धातु की बनी होती हैं?",
          "opts": [
            "Graphite",
            "Cadmium या Boron",
            "Uranium",
            "Liquid Sodium"
          ],
          "ans": 1,
          "exp": "Cadmium और Boron अतिरिक्त न्यूट्रॉन को अवशोषित करके नाभिकीय शृंखला अभिक्रिया को नियंत्रित करती हैं।"
        },
        {
          "q": "निम्न में से किस रिएक्टर में Moderator की आवश्यकता नहीं होती?",
          "opts": [
            "PWR",
            "BWR",
            "CANDU",
            "Fast Breeder Reactor (FBR)"
          ],
          "ans": 3,
          "exp": "Fast Breeder Reactor तेज़ न्यूट्रॉनों पर चलता है, इसलिए इसमें न्यूट्रॉन धीमे करने वाले Moderator की आवश्यकता नहीं होती।"
        }
      ]
    }
  ]
},
{
  "id": "thermodynamics",
  "name": "Thermodynamics (ऊष्मागतिकी)",
  "icon": "🔥",
  "category": "tech",
  "weight": "Very High (12–15 Marks)",
  "topics": [
    {
      "id": "td_basics_zeroth",
      "title": "Basic Concepts, Zeroth Law & First Law (शून्यवाँ व प्रथम नियम)",
      "subtitle": "System, Intensive/Extensive Properties • SFEE • PMM-1",
      "diagram": "thermo_laws",
      "def": "<b>Thermodynamics</b> ऊष्मा (Heat), कार्य (Work) और ऊर्जा के रूपांतरण का विज्ञान है। <b>Zeroth Law</b> तापमान मापन (Temperature Measurement) का आधार है, जबकि <b>First Law</b> ऊर्जा संरक्षण (Conservation of Energy) पर आधारित है।",
      "points": [
        "<b>Open System:</b> Mass और Energy दोनों बाहर-अंदर जा सकते हैं (जैसे Turbine, Boiler, Compressor, Nozzle)।",
        "<b>Closed System:</b> केवल Energy का आदान-प्रदान, Mass नियत रहता है (जैसे Piston-Cylinder बिना वॉल्व के)।",
        "<b>Intensive Property (द्रव्यमान से स्वतंत्र):</b> Pressure (P), Temperature (T), Density (ρ), Viscosity, Specific Volume।",
        "<b>Extensive Property (द्रव्यमान पर निर्भर):</b> Mass, Volume (V), Energy (U, H, S, KE, PE)।",
        "<b>First Law:</b> चक्रीय प्रक्रम (Cycle) के लिए ∮δQ = ∮δW। प्रक्रम के लिए δQ = dU + δW। <b>PMM-1</b> (बिना ऊर्जा लिए काम करने वाली मशीन) असंभव है।"
      ],
      "examples": [
        "कमरे को बीच से दो भागों में बाँटने पर <b>तापमान (T)</b> और <b>दाब (P)</b> नहीं बदलते (Intensive), लेकिन <b>आयतन (V)</b> और <b>द्रव्यमान (m)</b> आधे हो जाते हैं (Extensive)!"
      ],
      "formulas": [
        "First Law (Non-flow): Q = ΔU + W  (जहाँ ΔU = m·Cv·ΔT)",
        "Enthalpy: H = U + PV ;  Ideal Gas: PV = mRT ;  Cp − Cv = R ;  γ = Cp/Cv (Air = 1.4)",
        "SFEE (Open System): h₁ + V₁²/2 + gZ₁ + q = h₂ + V₂²/2 + gZ₂ + w",
        "Nozzle Exit Velocity: V₂ = √(2000 × Δh) m/s (जब Δh kJ/kg में हो)",
        "Throttling Process (Porous Plug/Capillary): h₁ = h₂ (Isenthalpic, W = 0, Q = 0)"
      ],
      "trick": "<b>Intensive vs Extensive पहचानने की ट्रिक:</b> किसी भी चीज़ के <b>दो बराबर टुकड़े</b> करो — जो <b>आधा न हो</b> (जैसे T, P, ρ) वह <b>INtensive (INdependent)</b> है! सभी <b>Specific</b> गुण (प्रति kg) हमेशा Intensive होते हैं।",
      "examFacts": [
        "<b>Heat और Work</b> दोनों <b>Path Functions</b> (Inexact Differentials) हैं, जबकि Internal Energy (U), Enthalpy (H) व Entropy (S) <b>Point Functions</b> (Properties) हैं।",
        "<b>Free Expansion (निर्वात में प्रसार):</b> Q = 0, W = 0, ΔU = 0 और Ideal Gas के लिए T₁ = T₂ (लेकिन यह <b>Irreversible</b> प्रक्रम है)।",
        "<b>Throttling Process</b> में Enthalpy नियत (h₁ = h₂) रहती है और यह भी एक Irreversible प्रक्रम है।"
      ],
      "numericals": [
        {
          "q": "एक Closed System को 80 kJ ऊष्मा दी जाती है और सिस्टम द्वारा 35 kJ कार्य किया जाता है। Internal Energy में परिवर्तन (ΔU) ज्ञात करें।",
          "given": "Q = +80 kJ, W = +35 kJ",
          "formula": "Q = ΔU + W  ⇒  ΔU = Q − W",
          "sol": "ΔU = 80 − 35 = +45 kJ (आंतरिक ऊर्जा 45 kJ बढ़ेगी)",
          "ans": "+45 kJ"
        },
        {
          "q": "एक Steam Nozzle में भाप की एन्थैल्पी में गिरावट Δh = 50 kJ/kg है (प्रारंभिक वेग नगण्य)। निकास वेग (Exit Velocity V₂) निकालें।",
          "given": "Δh = 50 kJ/kg, V₁ ≈ 0",
          "formula": "V₂ = √(2000 × Δh)",
          "sol": "V₂ = √(2000 × 50) = √100000 = 316.2 m/s",
          "ans": "316.2 m/s"
        }
      ],
      "mcqs": [
        {
          "q": "निम्न में से कौन-सी एक Intensive Property है?",
          "opts": [
            "Volume",
            "Enthalpy",
            "Density (घनत्व)",
            "Entropy"
          ],
          "ans": 2,
          "exp": "Density (ρ = m/V) द्रव्यमान के आकार पर निर्भर नहीं करती, इसलिए यह Intensive Property है।"
        },
        {
          "q": "Throttling Process के दौरान कौन-सा गुण नियत (Constant) रहता है?",
          "opts": [
            "Entropy",
            "Enthalpy",
            "Pressure",
            "Internal Energy"
          ],
          "ans": 1,
          "exp": "Throttling एक Isenthalpic (h₁ = h₂) और Irreversible प्रक्रम है।"
        },
        {
          "q": "Zeroth Law of Thermodynamics किसका आधार प्रदान करता है?",
          "opts": [
            "ऊर्जा संरक्षण",
            "तापमान मापन (Temperature Measurement)",
            "एन्ट्रॉपी",
            "ऊष्मा की दिशा"
          ],
          "ans": 1,
          "exp": "शून्यवाँ नियम तापीय साम्य (Thermal Equilibrium) और थर्मामीटर द्वारा तापमान मापन का सिद्धांत देता है।"
        }
      ]
    },
    {
      "id": "td_second_entropy",
      "title": "Second Law, Carnot Cycle & Entropy (द्वितीय नियम व एन्ट्रॉपी)",
      "subtitle": "Kelvin-Planck, Clausius • COP • Clausius Inequality • PMM-2",
      "diagram": "thermo_laws",
      "def": "<b>Second Law of Thermodynamics</b> ऊष्मा के प्रवाह की दिशा और ऊर्जा की गुणवत्ता (Quality) बताता है। <b>Kelvin-Planck Statement</b> Heat Engine से और <b>Clausius Statement</b> Refrigerator/Heat Pump से संबंधित है।",
      "points": [
        "<b>Kelvin-Planck Statement:</b> ऐसा कोई Heat Engine (PMM-2) बनाना असंभव है जो एक ही Source से ऊष्मा लेकर 100% कार्य में बदल दे (Sink अनिवार्य है)।",
        "<b>Clausius Statement:</b> बिना बाहरी कार्य (Work Input) दिए ऊष्मा ठंडी वस्तु से गरम वस्तु की ओर नहीं बह सकती।",
        "<b>Carnot Theorem:</b> दो निश्चित तापमानों (T₁, T₂) के बीच काम करने वाले सभी इंजनों में Reversible (Carnot) Engine की दक्षता अधिकतम होती है, और यह केवल T₁, T₂ पर निर्भर करती है (Working Fluid पर नहीं)।",
        "<b>Clausius Inequality:</b> ∮(δQ/T) ≤ 0  (<b>= 0</b> Reversible, <b>< 0</b> Irreversible, <b>> 0</b> Impossible)।"
      ],
      "examples": [
        "गरम चाय का कप अपने आप ठंडा होता है (ऊष्मा उच्च T → निम्न T), लेकिन कमरे की हवा से ऊष्मा लेकर चाय अपने आप गरम नहीं होती — यही द्वितीय नियम है।"
      ],
      "formulas": [
        "Carnot Engine Efficiency: η_carnot = 1 − (T₂ / T₁)  [हमेशा Kelvin (K = °C + 273) में!]",
        "COP of Refrigerator = T₂ / (T₁ − T₂)",
        "COP of Heat Pump = T₁ / (T₁ − T₂)",
        "Golden Relation: (COP)_HP = (COP)_Ref + 1  तथा  (COP)_HP = 1 / η_carnot",
        "Entropy Change: dS ≥ δQ / T ;  Isolated System के लिए ΔS_universe ≥ 0"
      ],
      "trick": "<b>याद रखने का सुनहरा नियम:</b> हमेशा तापमान को <b>Kelvin (T = °C + 273)</b> में बदलकर ही फॉर्मूले में रखना — वरना 100% उत्तर गलत होगा! और <b>HP हमेशा Ref से 1 बड़ा</b> होता है।",
      "examFacts": [
        "<b>PMM-2 (Perpetual Motion Machine of 2nd Kind)</b> Kelvin-Planck Statement का उल्लंघन करती है।",
        "किसी <b>Isolated System</b> की Entropy कभी घट नहीं सकती (हमेशा बढ़ती है या स्थिर रहती है — Principle of Increase of Entropy)।",
        "<b>T-s Diagram</b> के नीचे का क्षेत्रफल (Area under T-s curve) Reversible प्रक्रम में <b>Heat Transfer (Q)</b> दर्शाता है, जबकि <b>P-V Diagram</b> के नीचे का क्षेत्रफल <b>Work (W)</b> दर्शाता है।"
      ],
      "numericals": [
        {
          "q": "एक Carnot Engine 627°C और 27°C के बीच कार्य करता है। इसकी Maximum Efficiency ज्ञात करें।",
          "given": "T₁ = 627 + 273 = 900 K,  T₂ = 27 + 273 = 300 K",
          "formula": "η = 1 − (T₂ / T₁)",
          "sol": "η = 1 − (300 / 900) = 1 − 1/3 = 2/3 = 0.6667 = 66.67%",
          "ans": "66.67%"
        },
        {
          "q": "यदि एक Reversible Refrigerator का COP = 4 है, तो इन्हीं तापमानों के बीच काम करने वाले Heat Pump का COP और Heat Engine की Efficiency क्या होगी?",
          "given": "(COP)_Ref = 4",
          "formula": "(COP)_HP = (COP)_Ref + 1 ;  η_HE = 1 / (COP)_HP",
          "sol": "(COP)_HP = 4 + 1 = 5.   η_HE = 1 / 5 = 0.20 = 20%",
          "ans": "(COP)_HP = 5 तथा η_HE = 20%"
        }
      ],
      "mcqs": [
        {
          "q": "यदि ∮(δQ/T) < 0 हो, तो वह चक्र (Cycle) कैसा होगा?",
          "opts": [
            "Reversible",
            "Irreversible",
            "Impossible",
            "Isothermal"
          ],
          "ans": 1,
          "exp": "Clausius Inequality के अनुसार: = 0 (Reversible), < 0 (Irreversible), > 0 (Impossible)।"
        },
        {
          "q": "Carnot Engine की दक्षता किस पर निर्भर करती है?",
          "opts": [
            "Working Fluid पर",
            "केवल Source और Sink के तापमानों पर",
            "पिस्टन के आकार पर",
            "ईंधन के प्रकार पर"
          ],
          "ans": 1,
          "exp": "Carnot Theorem के अनुसार η = 1 − T₂/T₁ केवल दो तापमान सीमाओं पर निर्भर करती है।"
        },
        {
          "q": "PMM-2 किस नियम का उल्लंघन करता है?",
          "opts": [
            "Zeroth Law",
            "First Law",
            "Kelvin-Planck Statement",
            "Clausius Statement"
          ],
          "ans": 2,
          "exp": "PMM-2 एकल स्रोत से 100% कार्य बनाता है, जो Kelvin-Planck कथन के विरुद्ध है।"
        }
      ]
    },
    {
      "id": "td_pure_steam",
      "title": "Properties of Pure Substances & Steam (शुद्ध पदार्थ व भाप)",
      "subtitle": "Dryness Fraction • Triple Point • Critical Point • Steam Calorimeters",
      "diagram": "rankine",
      "def": "<b>Pure Substance (शुद्ध पदार्थ)</b> वह पदार्थ है जिसकी रासायनिक संरचना (Chemical Composition) हर जगह एक समान और स्थिर हो — जैसे पानी, भाप, हवा (गैसीय अवस्था में)।",
      "points": [
        "<b>Triple Point of Water:</b> वह बिंदु जहाँ ठोस (बर्फ़), द्रव (पानी) और गैस (भाप) तीनों एक साथ संतुलन में रहते हैं — <b>T = 0.01°C (273.16 K)</b>, <b>P = 0.00611 bar</b>।",
        "<b>Critical Point of Water:</b> वह उच्चतम बिंदु जहाँ Latent Heat (h_fg) <b>शून्य</b> हो जाती है और पानी बिना उबले सीधे भाप बन जाता है — <b>T_c = 374.15°C</b>, <b>P_c = 221.2 bar</b>।",
        "<b>Dryness Fraction (x):</b> गीली भाप में सूखी भाप का अंश: x = m_v / (m_v + m_f)। Saturated Liquid के लिए x = 0, Dry Saturated Steam के लिए x = 1।",
        "<b>Dryness Fraction मापने के यंत्र:</b> Separating, Throttling (उच्च x > 0.95 के लिए) और Combined Separating & Throttling Calorimeter।"
      ],
      "examples": [
        "केतली की टोंटी से निकलता हुआ सफ़ेद धुआँ असल में <b>Wet Steam</b> (पानी की सूक्ष्म बूँदें) है; असली <b>Superheated Steam</b> अदृश्य (रंगहीन) होती है!"
      ],
      "formulas": [
        "Enthalpy of Wet Steam: h = h_f + x · h_fg",
        "Enthalpy of Superheated Steam: h_sup = h_g + Cp_s (T_sup − T_sat)",
        "Specific Volume of Wet Steam: v ≈ x · v_g",
        "Entropy of Wet Steam: s = s_f + x · s_fg"
      ],
      "trick": "<b>पानी के 2 जादुई नंबर रट लो:</b> <b>Triple Point = 0.01°C</b> | <b>Critical Point = 374°C, 221.2 bar</b> (यहाँ h_fg = 0 — हर JE परीक्षा का फेवरेट प्रश्न!)",
      "examFacts": [
        "दाब (Pressure) बढ़ाने पर पानी का <b>Boiling Point बढ़ता है</b>, लेकिन <b>Latent Heat (h_fg) घटती है</b> और Critical Point पर 0 हो जाती है।",
        "<b>Mollier Diagram</b> असल में <b>h-s (Enthalpy vs Entropy)</b> ग्राफ़ है — इसमें Constant Pressure रेखाएँ दाईं ओर ऊपर फैलती (Diverge) हैं।",
        "<b>Throttling Calorimeter</b> अकेले बहुत गीली भाप (Low x) का मापन नहीं कर सकता क्योंकि Throttling के बाद भाप Superheated होनी चाहिए।"
      ],
      "numericals": [
        {
          "q": "एक नमूने में 1.8 kg सूखी भाप और 0.2 kg पानी के कण हैं। यदि h_f = 500 kJ/kg और h_fg = 2200 kJ/kg हो, तो Dryness Fraction (x) और Enthalpy (h) निकालें।",
          "given": "m_v = 1.8 kg, m_f = 0.2 kg, h_f = 500 kJ/kg, h_fg = 2200 kJ/kg",
          "formula": "x = m_v / (m_v + m_f) ;  h = h_f + x·h_fg",
          "sol": "x = 1.8 / (1.8 + 0.2) = 1.8 / 2.0 = 0.9.   h = 500 + (0.9 × 2200) = 500 + 1980 = 2480 kJ/kg",
          "ans": "x = 0.9 और h = 2480 kJ/kg"
        }
      ],
      "mcqs": [
        {
          "q": "पानी के Critical Point पर गुप्त ऊष्मा (Latent Heat h_fg) का मान कितना होता है?",
          "opts": [
            "2257 kJ/kg",
            "अधिकतम",
            "शून्य (Zero)",
            "100 kJ/kg"
          ],
          "ans": 2,
          "exp": "Critical Point (374.15°C, 221.2 bar) पर द्रव और वाष्प रेखाएँ मिल जाती हैं, इसलिए h_fg = 0 हो जाता है।"
        },
        {
          "q": "Mollier Diagram किन दो गुणों के बीच खींचा जाता है?",
          "opts": [
            "P और V",
            "T और s",
            "h (Enthalpy) और s (Entropy)",
            "P और h"
          ],
          "ans": 2,
          "exp": "Mollier Chart एक h-s (Enthalpy-Entropy) आरेख है जिसका उपयोग स्टीम टरबाइन की गणना में होता है।"
        }
      ]
    },
    {
      "id": "td_gas_cycles",
      "title": "Air Standard Cycles — Otto, Diesel, Dual & Brayton (वायु मानक चक्र)",
      "subtitle": "Compression Ratio • Cut-off Ratio • Efficiency Comparison",
      "diagram": "carnot_otto_diesel",
      "def": "<b>Air Standard Cycles</b> IC इंजनों और गैस टरबाइनों का विश्लेषण करने के लिए प्रयुक्त आदर्श चक्र हैं, जिनमें हवा को Ideal Gas (γ = 1.4) मानकर ऊष्मा का आदान-प्रदान दर्शाया जाता है।",
      "points": [
        "<b>Otto Cycle (Petrol / SI Engine):</b> Heat Addition और Heat Rejection दोनों <b>Constant Volume (V = C)</b> पर होते हैं। Compression Ratio r = 6 से 10।",
        "<b>Diesel Cycle (Slow-Speed CI Engine):</b> Heat Addition <b>Constant Pressure (P = C)</b> पर और Heat Rejection Constant Volume पर होता है। r = 14 से 22।",
        "<b>Dual Cycle (Modern High-Speed Diesel):</b> ऊष्मा का कुछ भाग V = C पर और कुछ भाग P = C पर जोड़ा जाता है।",
        "<b>Brayton / Joule Cycle (Gas Turbine):</b> Heat Addition व Rejection दोनों <b>Constant Pressure (P = C)</b> पर होते हैं।"
      ],
      "examples": [
        "बाइक/पेट्रोल कार का इंजन <b>Otto Cycle</b> पर, और भारी ट्रक/जेनरेटर का डीजल इंजन <b>Diesel / Dual Cycle</b> पर चलता है।"
      ],
      "formulas": [
        "Otto Efficiency: η_otto = 1 − [ 1 / r^(γ−1) ]  (जहाँ r = V₁/V₂)",
        "Diesel Efficiency: η_diesel = 1 − [ 1 / r^(γ−1) ] × [ (ρ^γ − 1) / (γ(ρ − 1)) ]  (जहाँ ρ = Cut-off Ratio V₃/V₂)",
        "Brayton Efficiency: η_brayton = 1 − [ 1 / r_p^((γ−1)/γ) ]"
      ],
      "trick": "<b>दक्षता तुलना की गोल्डन ट्रिक (बार-बार पूछा जाने वाला प्रश्न!):</b><br/>1) <b>Same Compression Ratio (r) & Heat Input:</b> <b>η_Otto > η_Dual > η_Diesel</b> (याद रखो: 'O-D-D')।<br/>2) <b>Same Max Pressure & Temp (P_max, T_max):</b> ठीक उल्टा → <b>η_Diesel > η_Dual > η_Otto</b>!",
      "examFacts": [
        "Diesel Cycle में <b>Cut-off Ratio (ρ) बढ़ने पर</b> Efficiency <b>घटती है</b>।",
        "Stirling और Ericsson Cycles (Regeneration के साथ) की दक्षता <b>Carnot Cycle के बराबर</b> होती है।",
        "Otto Cycle की दक्षता केवल Compression Ratio (r) और γ पर निर्भर करती है।"
      ],
      "numericals": [
        {
          "q": "एक Otto Cycle का Compression Ratio r = 8 है। यदि γ = 1.4 हो (8^0.4 ≈ 2.3), तो Air Standard Efficiency ज्ञात करें।",
          "given": "r = 8, γ = 1.4",
          "formula": "η_otto = 1 − (1 / r^(γ−1))",
          "sol": "η_otto = 1 − (1 / 8^0.4) = 1 − (1 / 2.3) = 1 − 0.435 = 0.565 = 56.5%",
          "ans": "56.5%"
        }
      ],
      "table": {
        "headers": [
          "चक्र (Cycle)",
          "Heat Addition",
          "Heat Rejection",
          "उपयोग (Application)"
        ],
        "rows": [
          [
            "Otto Cycle",
            "Constant Volume",
            "Constant Volume",
            "Petrol (SI) Engine"
          ],
          [
            "Diesel Cycle",
            "Constant Pressure",
            "Constant Volume",
            "Low-Speed Diesel Engine"
          ],
          [
            "Dual Cycle",
            "Part V=C, Part P=C",
            "Constant Volume",
            "High-Speed Diesel Engine"
          ],
          [
            "Brayton Cycle",
            "Constant Pressure",
            "Constant Pressure",
            "Gas Turbine / Jet Engine"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "समान Compression Ratio (r) और समान Heat Input के लिए किस चक्र की दक्षता सबसे अधिक होती है?",
          "opts": [
            "Diesel Cycle",
            "Dual Cycle",
            "Otto Cycle",
            "सभी बराबर"
          ],
          "ans": 2,
          "exp": "समान Compression Ratio पर η_Otto > η_Dual > η_Diesel होता है।"
        },
        {
          "q": "समान अधिकतम दाब और तापमान (Same P_max & T_max) के लिए किस चक्र की दक्षता सबसे अधिक होती है?",
          "opts": [
            "Otto Cycle",
            "Diesel Cycle",
            "Dual Cycle",
            "Brayton Cycle"
          ],
          "ans": 1,
          "exp": "समान P_max व T_max पर Diesel Cycle को अधिक Compression Ratio मिलता है, इसलिए η_Diesel > η_Dual > η_Otto।"
        }
      ]
    }
  ]
},
{
  "id": "fluid_mechanics",
  "name": "Fluid Mechanics & Hydraulic Machines (तरल यांत्रिकी)",
  "icon": "💧",
  "category": "tech",
  "weight": "High (10–14 Marks)",
  "topics": [
    {
      "id": "fm_properties",
      "title": "Fluid Properties, Viscosity & Surface Tension (तरल गुण व श्यानता)",
      "subtitle": "Newton's Law of Viscosity • Non-Newtonian • Capillarity • Vapour Pressure",
      "diagram": "fluid_types",
      "def": "<b>Fluid (तरल)</b> वह पदार्थ है जो अत्यंत छोटे Shear Stress के लगने पर भी लगातार विरूपित (Continuously Deform) होता रहता है। <b>Viscosity (श्यानता)</b> तरल की परतों के बीच सापेक्ष गति का विरोध करने का गुण है।",
      "points": [
        "<b>Newton's Law of Viscosity:</b> Shear Stress (τ) = μ · (du/dy)। जहाँ μ = Dynamic Viscosity (इकाई: <b>Pa·s</b> या <b>Poise</b>; 1 Pa·s = 10 Poise)।",
        "<b>Kinematic Viscosity (ν):</b> ν = μ / ρ (इकाई: m²/s या <b>Stoke</b>; 1 Stoke = 10⁻⁴ m²/s)।",
        "<b>तापमान का प्रभाव:</b> तापमान बढ़ने पर <b>द्रवों (Liquids) की श्यानता घटती है</b> (Cohesion घटता है), जबकि <b>गैसों की श्यानता बढ़ती है</b> (Molecular momentum transfer बढ़ता है)।",
        "<b>Surface Tension (σ):</b> द्रव की सतह के खिंचाव का बल प्रति इकाई लंबाई (N/m) — यह केवल <b>Cohesion (ससंजन)</b> के कारण होता है।",
        "<b>Capillarity (केशिकत्व):</b> Cohesion व Adhesion दोनों के कारण। पानी (काँच में) ऊपर चढ़ता है (θ < 90°), जबकि पारा (Mercury) नीचे गिरता है (θ > 90° ≈ 128°)।"
      ],
      "examples": [
        "सर्दियों में नारियल का तेल या शहद गाढ़ा हो जाता है (कम T → ज़्यादा Viscosity)। बारिश की बूँदें <b>Surface Tension</b> के कारण गोल होती हैं।"
      ],
      "formulas": [
        "τ = μ · (du / dy)  |  1 Pa·s = 10 Poise  |  1 m²/s = 10⁴ Stokes",
        "Pressure inside Liquid Droplet: ΔP = 4σ / d ;  Soap Bubble: ΔP = 8σ / d ;  Liquid Jet: ΔP = 2σ / d",
        "Capillary Rise/Fall: h = (4σ cos θ) / (ρ g d)",
        "Bulk Modulus (K) = −dP / (dV/V) = 1 / Compressibility (β)"
      ],
      "trick": "<b>बूँद-बुलबुले की ट्रिक — '2-4-8 (Jet-Drop-Bubble)':</b> Jet = <b>2</b>σ/d, Droplet = <b>4</b>σ/d, Soap Bubble = <b>8</b>σ/d (साबुन के बुलबुले की 2 सतहें होती हैं इसलिए दोगुना!)।",
      "examFacts": [
        "<b>Ideal Fluid:</b> Incompressible (ρ = C) और Non-viscous (μ = 0) होता है।",
        "<b>Cavitation (कैविटेशन)</b> तब होता है जब किसी स्थान पर द्रव का दाब उसके <b>Vapour Pressure</b> से कम हो जाता है।",
        "<b>Bingham Plastic</b> का उदाहरण टूथपेस्ट व सीवेज स्लज है; <b>Pseudoplastic (n < 1)</b> का खून व पेंट; <b>Dilatant (n > 1)</b> का क्विकसैंड व स्टार्च है।"
      ],
      "numericals": [
        {
          "q": "दो समानांतर प्लेटों के बीच 2 mm मोटी तेल की परत (μ = 0.5 Pa·s) है। यदि ऊपरी प्लेट 1 m/s से चले और निचली स्थिर हो, तो Shear Stress (τ) निकालें।",
          "given": "μ = 0.5 Pa·s, du = 1 m/s, dy = 2 mm = 0.002 m",
          "formula": "τ = μ × (du / dy)",
          "sol": "τ = 0.5 × (1 / 0.002) = 0.5 × 500 = 250 N/m² (Pa)",
          "ans": "250 Pa"
        }
      ],
      "mcqs": [
        {
          "q": "तापमान बढ़ाने पर गैसों की श्यानता (Viscosity of Gases) पर क्या प्रभाव पड़ता है?",
          "opts": [
            "घटती है",
            "बढ़ती है",
            "अपरिवर्तित रहती है",
            "पहले घटती फिर बढ़ती है"
          ],
          "ans": 1,
          "exp": "तापमान बढ़ने पर गैस अणुओं की गतिज ऊर्जा व टक्कर (Molecular Momentum Transfer) बढ़ने से श्यानता बढ़ती है (जबकि द्रवों में घटती है)।"
        },
        {
          "q": "1 Poise किसके बराबर होता है?",
          "opts": [
            "10 N·s/m²",
            "0.1 N·s/m²",
            "0.01 N·s/m²",
            "100 N·s/m²"
          ],
          "ans": 1,
          "exp": "1 Pa·s (N·s/m²) = 10 Poise, इसलिए 1 Poise = 0.1 N·s/m²।"
        },
        {
          "q": "साबुन के बुलबुले (Soap Bubble) के अंदर अतिरिक्त दाब (ΔP) कितना होता है?",
          "opts": [
            "2σ/d",
            "4σ/d",
            "8σ/d",
            "σ/d"
          ],
          "ans": 2,
          "exp": "साबुन के बुलबुले में हवा के संपर्क की दो सतहें (अंदर व बाहर) होती हैं, इसलिए ΔP = 8σ/d।"
        }
      ]
    },
    {
      "id": "fm_pressure_buoyancy",
      "title": "Fluid Statics, Pressure, Manometers & Buoyancy (दाब व उत्प्लावन)",
      "subtitle": "Pascal's Law • Centre of Pressure • Metacentric Height",
      "diagram": "bernoulli",
      "def": "<b>Pascal's Law</b> के अनुसार स्थिर तरल के किसी बिंदु पर दाब सभी दिशाओं में समान होता है। <b>Archimedes Principle</b> के अनुसार किसी डूबी हुई वस्तु पर लगने वाला उत्प्लावन बल (Buoyant Force) उसके द्वारा हटाए गए तरल के भार के बराबर होता है।",
      "points": [
        "<b>Hydrostatic Law:</b> P = ρ·g·h। <b>Absolute Pressure = Atmospheric Pressure + Gauge Pressure</b>।",
        "<b>Centre of Pressure (h*):</b> वह बिंदु जहाँ कुल द्रव-स्थैतिक बल कार्य करता है — यह हमेशा <b>Centre of Gravity (CG) से नीचे</b> होता है (केवल क्षैतिज सतह पर बराबर)।",
        "<b>Piezometer:</b> केवल हल्के धनात्मक द्रव दाब के लिए (गैस या वैक्यूम नहीं माप सकता)। <b>U-Tube Manometer</b> से उच्च व ऋणात्मक दाब दोनों मापते हैं।",
        "<b>Stability of Floating Body:</b> Metacentre (M), Centre of Gravity (G) से <b>ऊपर (GM > 0)</b> होना चाहिए।",
        "<b>Stability of Submerged Body:</b> Centre of Buoyancy (B), G से <b>ऊपर</b> होना चाहिए।"
      ],
      "examples": [
        "हाइड्रोलिक जैक (कार उठाने वाला) और हाइड्रोलिक ब्रेक <b>Pascal's Law</b> पर काम करते हैं। लोहे का जहाज़ पानी में तैरता है क्योंकि उसका Metacentre (M), G के ऊपर रहता है।"
      ],
      "formulas": [
        "P_abs = P_atm + P_gauge  (1 atm = 101.325 kPa = 10.33 m of water = 760 mm of Hg)",
        "Total Hydrostatic Force: F = ρ·g·A·x̄",
        "Centre of Pressure (Vertical Plate): h* = x̄ + (I_G / A·x̄)",
        "Metacentric Height: GM = BM − BG  (जहाँ BM = I / V_submerged)"
      ],
      "trick": "<b>तैरती vs डूबी वस्तु की स्थिरता (Stability):</b> <b>F</b>loating = <b>M</b> above G ('<b>F</b>or <b>M</b>other')। <b>S</b>ubmerged = <b>B</b> above G ('<b>S</b>ub-<b>B</b>')!",
      "examFacts": [
        "एक ऊर्ध्वाधर आयताकार प्लेट (ऊँचाई H, पानी की सतह से सटी हुई) का <b>Centre of Pressure (h*) = 2H/3</b> गहराई पर होता है।",
        "<b>Barometer</b> वायुमंडलीय दाब (Atmospheric Pressure) मापता है, और <b>Bourdon Gauge</b> उच्च गेज दाब मापता है।",
        "जहाज़ की Metacentric Height (GM) बढ़ने से स्थिरता तो बढ़ती है, लेकिन <b>Rolling तेज़ (असहज)</b> हो जाती है।"
      ],
      "table": {
        "headers": [
          "अवस्था (Condition)",
          "Floating Body (तैरती वस्तु)",
          "Submerged Body (डूबी वस्तु)"
        ],
        "rows": [
          [
            "Stable Equilibrium",
            "M is above G (GM > 0)",
            "B is above G"
          ],
          [
            "Unstable Equilibrium",
            "M is below G (GM < 0)",
            "B is below G"
          ],
          [
            "Neutral Equilibrium",
            "M coincides with G (GM = 0)",
            "B coincides with G"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "1 Atmospheric Pressure पानी के कितने मीटर कॉलम के बराबर होता है?",
          "opts": [
            "7.6 m",
            "10.33 m",
            "13.6 m",
            "1.01 m"
          ],
          "ans": 1,
          "exp": "P = ρgh ⇒ h = 101325 / (1000 × 9.81) = 10.33 m of water (या 760 mm of Hg)।"
        },
        {
          "q": "किसी तैरती हुई वस्तु (Floating Body) के Stable Equilibrium के लिए क्या आवश्यक है?",
          "opts": [
            "M, G से नीचे हो",
            "M, G से ऊपर हो",
            "B, G से ऊपर हो",
            "M और G एक बिंदु पर हों"
          ],
          "ans": 1,
          "exp": "Floating Body के लिए Metacentre (M) हमेशा Centre of Gravity (G) के ऊपर होना चाहिए (GM > 0)।"
        }
      ]
    },
    {
      "id": "fm_kinematics_bernoulli",
      "title": "Continuity Equation, Bernoulli's Theorem & Flow Meters (बर्नौली प्रमेय)",
      "subtitle": "Venturimeter • Orificemeter • Pitot Tube • Stream & Potential Function",
      "diagram": "bernoulli",
      "def": "<b>Continuity Equation (सातत्य समीकरण)</b> द्रव्यमान संरक्षण (Conservation of Mass) पर और <b>Bernoulli's Equation</b> ऊर्जा संरक्षण (Conservation of Energy) पर आधारित है।",
      "points": [
        "<b>Continuity Equation (Incompressible):</b> A₁V₁ = A₂V₂ = Discharge (Q)। पाइप पतला होने पर वेग (V) बढ़ता है।",
        "<b>Bernoulli's Assumptions:</b> प्रवाह Steady, Incompressible, Irrotational और Inviscid (Ideal) होना चाहिए।",
        "<b>Venturimeter (Cd = 0.96–0.98):</b> पाइप में Discharge (Q) मापता है। इसका Diverging Cone लंबा (5°–7°) रखा जाता है ताकि <b>Flow Separation</b> न हो।",
        "<b>Orificemeter (Cd = 0.62–0.65):</b> सस्ता है लेकिन Head Loss ज़्यादा होता है।",
        "<b>Pitot Tube:</b> किसी एक बिंदु पर तरल का <b>वेग (Velocity)</b> मापता है (Stagnation Point पर V = 0)।"
      ],
      "examples": [
        "बाग़ में पानी के पाइप का मुँह अंगूठे से दबाने पर पानी तेज़ धार से दूर जाता है — यही <b>Continuity Equation (A₁V₁ = A₂V₂)</b> है!"
      ],
      "formulas": [
        "Continuity: Q = A₁V₁ = A₂V₂ (m³/s)",
        "Bernoulli: (P/ρg) + (V²/2g) + Z = Constant  (Pressure + Kinetic + Datum Head)",
        "Venturimeter Discharge: Q = Cd · [A₁A₂ / √(A₁² − A₂²)] · √(2gh)",
        "Pitot Tube Velocity: V = Cv · √(2gh)",
        "Discharge Coefficient Relation: Cd = Cc × Cv"
      ],
      "trick": "<b>तीनों यंत्रों की ट्रिक:</b> <b>V</b>enturi & <b>O</b>rifice = <b>Discharge (Q)</b> मापते हैं; <b>P</b>itot Tube = <b>P</b>oint <b>V</b>elocity मापता है! और Cd: Venturi (0.98) > Orifice (0.64)।",
      "examFacts": [
        "<b>Stream Function (ψ)</b> केवल 2D Flow में परिभाषित है; इसका अस्तित्व <b>Continuity Equation</b> को संतुष्ट करता है।",
        "<b>Velocity Potential Function (φ)</b> का अस्तित्व <b>Irrotational Flow</b> दर्शाता है। ψ व φ रेखाएँ एक-दूसरे को <b>90° (Orthogonal)</b> पर काटती हैं।",
        "<b>Rotameter</b> एक Variable Area Flow Meter है जो ऊर्ध्वाधर (Vertical) लगाया जाता है।"
      ],
      "numericals": [
        {
          "q": "एक पाइप के प्रवेश पर व्यास 20 cm और वेग 2 m/s है। यदि निकास पर व्यास 10 cm हो, तो निकास वेग (V₂) ज्ञात करें।",
          "given": "d₁ = 20 cm, V₁ = 2 m/s, d₂ = 10 cm",
          "formula": "A₁V₁ = A₂V₂  ⇒  d₁²·V₁ = d₂²·V₂",
          "sol": "V₂ = V₁ × (d₁/d₂)² = 2 × (20/10)² = 2 × 4 = 8 m/s",
          "ans": "8 m/s"
        }
      ],
      "mcqs": [
        {
          "q": "Bernoulli's Equation किस संरक्षण नियम पर आधारित है?",
          "opts": [
            "Mass",
            "Momentum",
            "Energy (ऊर्जा संरक्षण)",
            "Angular Momentum"
          ],
          "ans": 2,
          "exp": "बर्नौली प्रमेय Ideal Fluid के लिए ऊर्जा संरक्षण (Pressure + Kinetic + Potential Energy = Constant) को दर्शाता है।"
        },
        {
          "q": "Pitot Tube का उपयोग क्या मापने के लिए किया जाता है?",
          "opts": [
            "पाइप का Discharge",
            "किसी बिंदु पर तरल का वेग (Velocity)",
            "तरल की श्यानता",
            "सतह का तनाव"
          ],
          "ans": 1,
          "exp": "Pitot Tube Stagnation Pressure की मदद से किसी बिंदु पर प्रवाह का वेग V = √(2gh) मापता है।"
        }
      ]
    },
    {
      "id": "fm_pipe_flow",
      "title": "Pipe Flow, Reynolds Number & Head Losses (पाइप प्रवाह व हानियाँ)",
      "subtitle": "Laminar vs Turbulent • Darcy-Weisbach • Hagen-Poiseuille • Water Hammer",
      "diagram": "bernoulli",
      "def": "पाइप में प्रवाहित तरल का व्यवहार <b>Reynolds Number (Re)</b> द्वारा तय होता है — जो Inertia Force और Viscous Force का अनुपात है। घर्षण (Friction) के कारण पाइप में प्रमुख दाब हानि (Major Head Loss) होती है।",
      "points": [
        "<b>पाइप में प्रवाह के प्रकार:</b> <b>Re < 2000</b> → Laminar Flow; <b>2000 – 4000</b> → Transition; <b>Re > 4000</b> → Turbulent Flow।",
        "<b>Laminar Pipe Flow (Hagen-Poiseuille):</b> Velocity Profile <b>Parabolic</b> होती है। केंद्र पर अधिकतम वेग औसत वेग का दोगुना होता है (<b>U_max = 2·V_avg</b>)।",
        "<b>Friction Factor (Laminar Flow):</b> <b>f = 64 / Re</b> (और Friction Coefficient f' = 16 / Re)।",
        "<b>Major Loss (Friction):</b> Darcy-Weisbach समीकरण द्वारा। <b>Minor Losses:</b> Sudden Expansion, Contraction, Bend, Entry व Exit में।",
        "<b>Hydraulic Gradient Line (HGL):</b> (P/ρg + Z) को जोड़ती है; <b>Total Energy Line (TEL):</b> HGL से V²/2g ऊपर होती है।"
      ],
      "examples": [
        "लंबे पानी के पाइप में दूर जाने पर नल का प्रेशर कम हो जाता है — यही Darcy-Weisbach <b>Friction Head Loss (h_f)</b> है।"
      ],
      "formulas": [
        "Reynolds Number: Re = (ρ V D) / μ = (V D) / ν",
        "Darcy-Weisbach Equation: h_f = (f L V²) / (2 g D)  [जहाँ f = Darcy Friction Factor]",
        "Sudden Expansion Loss: h_e = (V₁ − V₂)² / (2g)",
        "Maximum Power Transmission through Pipe: जब h_f = H / 3  (तब अधिकतम दक्षता η = 66.67%)",
        "Hydraulic Diameter (Non-circular pipe): D_h = 4A / P"
      ],
      "trick": "<b>पाइप से अधिकतम पावर (Max Power) की ट्रिक:</b> जब 1/3 हेड घर्षण में खर्च हो (<b>h_f = H/3</b>), तो बाकी <b>2/3 = 66.67%</b> अधिकतम दक्षता मिलती है!",
      "examFacts": [
        "पाइप के <b>Exit Loss = V²/2g</b> और <b>Sharp Entry Loss = 0.5·V²/2g</b> होता है।",
        "Laminar Flow में Shear Stress वितरण पाइप की त्रिज्या के साथ <b>रेखीय (Linear)</b> होता है (केंद्र पर 0, दीवार पर अधिकतम)।",
        "<b>Series Pipes</b> में Discharge (Q) समान रहता है और Head Loss जुड़ते हैं; <b>Parallel Pipes</b> में Head Loss समान रहता है और Q जुड़ता है।"
      ],
      "numericals": [
        {
          "q": "एक पाइप में Laminar Flow के लिए Reynolds Number Re = 1600 है। Darcy Friction Factor (f) ज्ञात करें।",
          "given": "Re = 1600 (Laminar, क्योंकि Re < 2000)",
          "formula": "f = 64 / Re",
          "sol": "f = 64 / 1600 = 0.04",
          "ans": "f = 0.04"
        }
      ],
      "mcqs": [
        {
          "q": "पाइप के माध्यम से अधिकतम पावर ट्रांसमिट होने पर अधिकतम दक्षता (Max Efficiency) कितनी होती है?",
          "opts": [
            "50%",
            "66.67%",
            "75%",
            "100%"
          ],
          "ans": 1,
          "exp": "अधिकतम पावर के लिए h_f = H/3 होना चाहिए, तब η = (H − H/3)/H = 2/3 = 66.67%।"
        },
        {
          "q": "पाइप में Laminar Flow के लिए केंद्र पर अधिकतम वेग व औसत वेग का अनुपात (U_max / V_avg) कितना होता है?",
          "opts": [
            "1.5",
            "2.0",
            "1.33",
            "0.5"
          ],
          "ans": 1,
          "exp": "सर्कुलर पाइप में Laminar Flow के लिए U_max = 2·V_avg (और दो समानांतर प्लेटों के बीच 1.5·V_avg) होता है।"
        }
      ]
    },
    {
      "id": "fm_turbines",
      "title": "Hydraulic Turbines — Pelton, Francis & Kaplan (हाइड्रोलिक टरबाइन)",
      "subtitle": "Head • Flow Direction • Specific Speed • Draft Tube • Unit Quantities",
      "diagram": "hydro_turbines",
      "def": "<b>Hydraulic Turbine</b> बहते या ऊँचाई से गिरते पानी की हाइड्रोलिक ऊर्जा को यांत्रिक ऊर्जा (Mechanical Power) में बदलती है। मुख्यतः दो प्रकार की होती हैं: <b>Impulse (Pelton)</b> और <b>Reaction (Francis, Kaplan)</b>।",
      "points": [
        "<b>Pelton Wheel:</b> Tangential Flow, Impulse Turbine — <b>High Head (> 250m)</b> व Low Discharge। इसमें Spear Valve से प्रवाह नियंत्रित होता है। बकेट का विक्षेपण कोण <b>165°</b> रखा जाता है।",
        "<b>Francis Turbine:</b> Inward/Mixed Flow, Reaction Turbine — <b>Medium Head (60–250m)</b> व Medium Discharge।",
        "<b>Kaplan Turbine:</b> Axial Flow, Reaction Turbine — <b>Low Head (< 60m)</b> व High Discharge। इसके रनर ब्लेड्स <b>Adjustable (घुमाए जा सकने वाले)</b> होते हैं (Propeller में Fixed)।",
        "<b>Draft Tube:</b> केवल Reaction Turbines (Francis/Kaplan) के निकास पर लगता है — यह गतिज ऊर्जा को दाब ऊर्जा में बदलता है और टरबाइन को Tail Race के ऊपर लगाने की सुविधा देता है।"
      ],
      "examples": [
        "ऊँचे पहाड़ी झरनों पर <b>Pelton</b> और नर्मदा/चंबल जैसी बड़ी मैदानी नदियों के बाँधों पर <b>Francis / Kaplan</b> टरबाइन लगती हैं।"
      ],
      "formulas": [
        "Specific Speed of Turbine: N_s = (N √P) / H^(5/4)  [जहाँ P kW में, H मीटर में]",
        "Pelton Wheel Jet Ratio (m) = D / d  (सामान्यतः 11 से 16)",
        "No. of Buckets on Pelton Wheel: Z = 15 + (D / 2d) = 15 + 0.5 m",
        "Overall Efficiency: η_o = η_h × η_m × η_v"
      ],
      "trick": "<b>Specific Speed (Ns) याद रखने की ट्रिक — 'P-F-K (कम से ज़्यादा)':</b> <b>P</b>elton (10–60) → <b>F</b>rancis (60–300) → <b>K</b>aplan (300–1000)। Head ठीक उल्टा होता है (Pelton सबसे ज़्यादा Head)!",
      "examFacts": [
        "<b>Pelton Wheel</b> में अधिकतम Hydraulic Efficiency के लिए ब्लेड वेग u = V₁/2 (Speed Ratio ≈ 0.45) होना चाहिए।",
        "<b>Runaway Speed</b> वह अधिकतम स्पीड है जिस पर टरबाइन बिना किसी लोड (Zero Load) के पूरे खुले गेट पर घूमती है।",
        "<b>Cavitation</b> केवल Reaction Turbines (विशेषकर Draft Tube व Runner Exit) में होता है, Pelton में नहीं।"
      ],
      "numericals": [
        {
          "q": "एक Pelton Wheel का व्यास D = 1.2 m और Jet व्यास d = 0.1 m है। बकेट्स की संख्या (Z) निकालें।",
          "given": "D = 1.2 m, d = 0.1 m ⇒ Jet Ratio m = D/d = 12",
          "formula": "Z = 15 + (D / 2d) = 15 + 0.5 m",
          "sol": "Z = 15 + (0.5 × 12) = 15 + 6 = 21 Buckets",
          "ans": "21 Buckets"
        }
      ],
      "mcqs": [
        {
          "q": "कम हेड (Low Head < 60m) और अधिक पानी (High Discharge) के लिए कौन-सी टरबाइन सर्वोत्तम है?",
          "opts": [
            "Pelton Wheel",
            "Francis Turbine",
            "Kaplan Turbine",
            "De-Laval Turbine"
          ],
          "ans": 2,
          "exp": "Kaplan एक Axial Flow Reaction टरबाइन है जो Low Head व High Discharge (Ns = 300–1000) के लिए सबसे उपयुक्त है।"
        },
        {
          "q": "Draft Tube का उपयोग किस टरबाइन में किया जाता है?",
          "opts": [
            "Pelton Wheel",
            "Reaction Turbines (Francis & Kaplan)",
            "केवल Steam Turbine",
            "इनमें से कोई नहीं"
          ],
          "ans": 1,
          "exp": "Draft Tube केवल Reaction Turbines में लगाया जाता है क्योंकि इनके निकास पर दाब वायुमंडलीय दाब से कम होता है।"
        }
      ]
    },
    {
      "id": "fm_pumps",
      "title": "Hydraulic Pumps — Centrifugal & Reciprocating (पंप)",
      "subtitle": "Priming • Cavitation • NPSH • Air Vessel • Specific Speed",
      "diagram": "pumps",
      "def": "<b>Hydraulic Pump</b> मोटर से यांत्रिक ऊर्जा लेकर पानी को दाब ऊर्जा (Pressure Energy) देता है और नीचे से ऊँचाई पर पहुँचाता है।",
      "points": [
        "<b>Centrifugal Pump (Rotodynamic):</b> अपकेंद्रीय बल (Centrifugal Force) पर कार्य करता है — High Discharge, Low/Medium Head। <b>Backward Curved Vanes</b> सबसे अधिक दक्ष होते हैं।",
        "<b>Priming (प्राइमिंग):</b> Centrifugal Pump चालू करने से पहले Suction Pipe व Casing को पानी से भरकर हवा निकालना — बिना Priming के पंप पानी नहीं खींचेगा!",
        "<b>Cavitation & NPSH:</b> सक्शन साइड पर दाब कम होने से भाप के बुलबुले बनना व फूटना। इससे बचने के लिए <b>Available NPSH > Required NPSH</b> होना चाहिए।",
        "<b>Reciprocating Pump (Positive Displacement):</b> Low Discharge, Very High Head। इसमें <b>Air Vessel</b> लगाकर प्रवाह को एकसमान (Uniform) बनाया जाता है और Friction Work बचाया जाता है।"
      ],
      "examples": [
        "घर की छत की टंकी भरने वाली टुल्लू/मोनोब्लॉक मोटर <b>Centrifugal Pump</b> है, और गाँव का हैंडपंप <b>Reciprocating Pump</b> का उदाहरण है।"
      ],
      "formulas": [
        "Specific Speed of Pump: N_s = (N √Q) / H^(3/4)  [ध्यान दें: टरबाइन में H^(5/4) और पंप में H^(3/4)!]",
        "Manometric Efficiency: η_mano = (g · H_m) / (V_w2 · u₂)",
        "Slip of Reciprocating Pump = Q_th − Q_act  (Negative Slip तब होता है जब Delivery Pipe छोटा और Suction Pipe लंबा हो!)",
        "Multi-stage Pump: Impellers in Series → High Head ;  Impellers in Parallel → High Discharge"
      ],
      "trick": "<b>पंप Series vs Parallel की ट्रिक — 'S-H, P-D':</b> <b>S</b>eries = <b>H</b>ead बढ़ेगा (ऊँचाई), <b>P</b>arallel = <b>D</b>ischarge बढ़ेगा (मात्रा)!",
      "examFacts": [
        "Centrifugal Pump चालू करते समय <b>Delivery Valve को बंद (Closed)</b> रखना चाहिए ताकि शुरुआती मोटर करंट कम रहे।",
        "Reciprocating Pump में <b>Air Vessel</b> लगाने से Single-Acting पंप में <b>84.8%</b> और Double-Acting में <b>39.2%</b> Friction Work की बचत होती है।",
        "<b>Foot Valve (Non-return Valve)</b> सक्शन पाइप के सबसे निचले सिरे पर लगाया जाता है ताकि पंप बंद होने पर पानी वापस न गिरे।"
      ],
      "numericals": [
        {
          "q": "एक Centrifugal Pump 0.05 m³/s पानी को 20 m ऊँचाई पर चढ़ाता है। यदि Overall Efficiency 80% हो (g = 10 m/s²), तो आवश्यक Shaft Power निकालें।",
          "given": "Q = 0.05 m³/s, H = 20 m, η = 0.80, ρ = 1000 kg/m³",
          "formula": "Shaft Power (P) = (ρ g Q H) / η",
          "sol": "Water Power = 1000 × 10 × 0.05 × 20 = 10,000 W = 10 kW.  Shaft Power = 10 / 0.80 = 12.5 kW",
          "ans": "12.5 kW"
        }
      ],
      "mcqs": [
        {
          "q": "Centrifugal Pump की Specific Speed का सही सूत्र क्या है?",
          "opts": [
            "N√P / H^(5/4)",
            "N√Q / H^(3/4)",
            "N√Q / H^(5/4)",
            "N√P / H^(3/4)"
          ],
          "ans": 1,
          "exp": "पंप के लिए N_s = N√Q / H^(3/4) होता है (जबकि टरबाइन के लिए N√P / H^(5/4))।"
        },
        {
          "q": "दो Centrifugal Pumps को Series में जोड़ने से क्या बढ़ता है?",
          "opts": [
            "Discharge (मात्रा)",
            "Head (ऊँचाई/दाब)",
            "Cavitation",
            "Slip"
          ],
          "ans": 1,
          "exp": "ट्रिक S-H, P-D: Series में Head दोगुना और Parallel में Discharge दोगुना होता है।"
        }
      ]
    }
  ]
}
);
