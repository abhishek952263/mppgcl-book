window.MPPGCL_SUBJECTS = window.MPPGCL_SUBJECTS || [];
window.MPPGCL_SUBJECTS.push(
{
  "id": "ic_rac_ht",
  "name": "IC Engines, RAC & Heat Transfer (आईसी इंजन, प्रशीतन व ऊष्मा अंतरण)",
  "icon": "❄️",
  "category": "tech",
  "weight": "High (8–11 Marks)",
  "topics": [
    {
      "id": "ic_4stroke_knocking",
      "title": "IC Engines — 2-Stroke/4-Stroke, Knocking, Octane & Cetane",
      "subtitle": "SI vs CI Engine • Detonation • Ignition Delay • Valve Timing",
      "diagram": "ic_engine",
      "def": "<b>Internal Combustion (IC) Engine</b> वह ऊष्मा इंजन है जिसमें ईंधन का दहन सिलेंडर के अंदर ही होता है। मुख्यतः दो प्रकार के होते हैं: <b>SI Engine (Petrol — Spark Ignition, Otto Cycle)</b> और <b>CI Engine (Diesel — Compression Ignition, Diesel/Dual Cycle)</b>।",
      "points": [
        "<b>4-Stroke Engine:</b> 4 पिस्टन स्ट्रोक्स = क्रैंकशाफ़्ट के <b>2 चक्कर (720°)</b> में 1 पावर स्ट्रोक। इसमें Poppet Valves होते हैं और Thermal Efficiency अधिक होती है।",
        "<b>2-Stroke Engine:</b> 2 पिस्टन स्ट्रोक्स = क्रैंकशाफ़्ट के <b>1 चक्कर (360°)</b> में 1 पावर स्ट्रोक। इसमें Valves की जगह <b>Ports</b> (Inlet, Transfer, Exhaust) होते हैं और <b>Scavenging</b> (ताज़ी हवा से धुआँ बाहर निकालना) होता है।",
        "<b>Knocking in SI Engine (Petrol):</b> दहन के <b>अंत में (End Charge)</b> स्वतः प्रज्वलन (Auto-ignition) के कारण धात्विक खटखटाहट। <b>रोकने का उपाय:</b> Compression Ratio घटाएँ, High Octane Fuel (TEL) डालें, Spark Plug केंद्र में रखें।",
        "<b>Knocking in CI Engine (Diesel):</b> दहन की <b>शुरुआत में (Long Ignition Delay)</b> बहुत सारा डीजल एक साथ जलना। <b>रोकने का उपाय:</b> Compression Ratio <b>बढ़ाएँ</b>, High Cetane Fuel डालें, Intake Air गरम करें।",
        "<b>Octane Number (Petrol):</b> Iso-octane (100) व n-Heptane (0) का मिश्रण — Anti-knock गुण बताता है। <b>Cetane Number (Diesel):</b> n-Cetane (100) व α-methylnaphthalene (0) — Self-ignition गुण बताता है।"
      ],
      "examples": [
        "बाइक (Hero/Honda) में <b>4-Stroke SI Engine</b>, पुरानी Bajaj Chetak स्कूटर में <b>2-Stroke SI Engine</b>, और ट्रैक्टर/ट्रक/डीजल जनरेटर में <b>4-Stroke CI Engine</b> होता है।"
      ],
      "formulas": [
        "Indicated Power (IP) = (P_mi · L · A · N · k) / (60 × n)  [4-Stroke में n = 2 ; 2-Stroke में n = 1]",
        "Brake Power (BP) = (2 π N T) / 60  |  Friction Power (FP) = IP − BP",
        "Mechanical Efficiency: η_mech = BP / IP",
        "Indicated Thermal Efficiency: η_ith = IP / (m_f × CV)  |  Brake Thermal Efficiency: η_bth = BP / (m_f × CV)"
      ],
      "trick": "<b>SI vs CI Knocking की उल्टी ट्रिक (एग्ज़ाम का पक्का प्रश्न!):</b> जो चीज़ Petrol (SI) में Knocking <b>रोकती</b> है, वही Diesel (CI) में Knocking <b>बढ़ाती</b> है!<br/>• High Compression Ratio: SI में Knocking ↑, CI में Knocking ↓<br/>• High Self-Ignition Temp: SI के लिए अच्छा, CI के लिए बुरा!",
      "examFacts": [
        "<b>Morse Test</b> का उपयोग केवल <b>Multi-Cylinder Engines</b> की Indicated Power (IP) और Friction Power (FP) निकालने के लिए किया जाता है।",
        "<b>Willan's Line Method</b> का उपयोग केवल <b>Diesel (CI) Engines</b> की Friction Power निकालने के लिए होता है।",
        "पेट्रोल इंजन के लिए Stoichiometric (रासायनिक रूप से सही) <b>Air-Fuel Ratio = 14.7 : 1 (लगभग 15:1)</b> होता है।",
        "<b>Supercharging / Turbocharging</b> का मुख्य उद्देश्य इंजन में हवा का घनत्व बढ़ाकर <b>Power Output बढ़ाना</b> है (यह Diesel इंजन में Knocking भी घटाता है)।"
      ],
      "numericals": [
        {
          "q": "एक 4-स्ट्रोक इंजन की Indicated Power = 50 kW और Friction Power = 10 kW है। Brake Power और Mechanical Efficiency ज्ञात करें।",
          "given": "IP = 50 kW, FP = 10 kW",
          "formula": "BP = IP − FP ;  η_mech = (BP / IP) × 100",
          "sol": "BP = 50 − 10 = 40 kW.  η_mech = (40 / 50) × 100 = 80%",
          "ans": "BP = 40 kW और η_mech = 80%"
        }
      ],
      "table": {
        "headers": [
          "गुण (Parameter)",
          "SI Engine (Petrol)",
          "CI Engine (Diesel)"
        ],
        "rows": [
          [
            "आदर्श चक्र (Cycle)",
            "Otto Cycle (V = C)",
            "Diesel / Dual Cycle"
          ],
          [
            "Compression Ratio (r)",
            "6 से 10",
            "14 से 22"
          ],
          [
            "ईंधन की गुणवत्ता",
            "Octane Number (85–95)",
            "Cetane Number (45–55)"
          ],
          [
            "Load Control (Governing)",
            "Quantity (Throttle Valve)",
            "Quality (Fuel Injector)"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "Diesel (CI) Engine में Knocking कम करने के लिए ईंधन का Cetane Number कैसा होना चाहिए?",
          "opts": [
            "कम (Low)",
            "अधिक (High)",
            "शून्य",
            "कोई प्रभाव नहीं"
          ],
          "ans": 1,
          "exp": "उच्च Cetane Number से Ignition Delay कम होता है, जिससे डीजल इंजन में Knocking घटती है।"
        },
        {
          "q": "Morse Test का उपयोग किस इंजन के लिए किया जाता है?",
          "opts": [
            "Single Cylinder Petrol",
            "Single Cylinder Diesel",
            "Multi-Cylinder Engines",
            "Steam Turbine"
          ],
          "ans": 2,
          "exp": "Morse Test में बारी-बारी से एक-एक सिलेंडर को बंद करके Multi-Cylinder Engine की IP व FP निकाली जाती है।"
        },
        {
          "q": "4-Stroke इंजन में 1 पावर स्ट्रोक के लिए क्रैंकशाफ़्ट कितने डिग्री घूमती है?",
          "opts": [
            "180°",
            "360°",
            "540°",
            "720° (2 चक्कर)"
          ],
          "ans": 3,
          "exp": "4-स्ट्रोक इंजन में 4 स्ट्रोक्स = 2 क्रैंक चक्कर = 720° में 1 पावर स्ट्रोक मिलता है।"
        }
      ]
    },
    {
      "id": "rac_vcr_var",
      "title": "Refrigeration — VCR Cycle, VAR Cycle & Refrigerants (प्रशीतन)",
      "subtitle": "1 Ton of Refrigeration • Subcooling & Superheating • Eco-Friendly Refrigerants",
      "diagram": "vcr_cycle",
      "def": "<b>Refrigeration (प्रशीतन)</b> किसी बंद स्थान से ऊष्मा निकालकर उसका तापमान वातावरण के तापमान से नीचे बनाए रखने की प्रक्रिया है। घरेलू फ्रिज व AC <b>Vapour Compression Refrigeration (VCR)</b> चक्र पर चलते हैं।",
      "points": [
        "<b>1 Ton of Refrigeration (1 TR):</b> 0°C पर 1 टन (1000 kg) बर्फ़ को 24 घंटे में पिघलाने से प्राप्त ठंडक की दर — <b>1 TR = 3.5 kW = 210 kJ/min</b>।",
        "<b>VCR Cycle के 4 अंग:</b> 1) Compressor (Isentropic Compression), 2) Condenser (P=C Heat Rejection), 3) <b>Expansion / Capillary Valve (Isenthalpic Throttling h₃ = h₄)</b>, 4) Evaporator (P=C Cooling / Refrigeration Effect)।",
        "<b>Subcooling (अवशीतन):</b> कंडेंसर के बाद द्रव को और ठंडा करने से Refrigeration Effect बढ़ता है (Compressor Work समान) ⇒ <b>COP हमेशा बढ़ता है!</b>",
        "<b>VAR Cycle (Vapour Absorption):</b> इसमें Compressor के स्थान पर <b>Absorber + Pump + Generator</b> होता है। यह बेकार ऊष्मा (Waste Heat / Solar) से चलता है। उदाहरण: <b>NH₃-Water</b> (NH₃ Refrigerant, Water Absorbent) और <b>LiBr-Water</b> (Water Refrigerant, LiBr Absorbent — AC के लिए)।"
      ],
      "examples": [
        "1.5 Ton के AC की कूलिंग क्षमता = 1.5 × 3.5 = <b>5.25 kW</b> होती है। घरेलू फ्रिज के पीछे की जाली <b>Condenser</b> है जो गरम रहती है, और अंदर का फ़्रीज़र बॉक्स <b>Evaporator</b> है।"
      ],
      "formulas": [
        "1 TR = 3.5 kW = 210 kJ/min = 50 kcal/min",
        "COP of VCR Cycle = Refrigeration Effect / Work Input = (h₁ − h₄) / (h₂ − h₁)",
        "Power Required (kW) = (3.5 × TR) / COP",
        "Max COP of VAR System = [ T_e / (T_c − T_e) ] × [ (T_g − T_c) / T_g ]"
      ],
      "trick": "<b>VAR Refrigerant की पक्की ट्रिक (ग़लती से बचो!):</b><br/>• <b>Ammonia-Water:</b> <b>NH₃ = Refrigerant</b>, Water = Absorbent (0°C से नीचे बर्फ़ जमाने हेतु)<br/>• <b>LiBr-Water:</b> <b>Water = Refrigerant</b>, LiBr = Absorbent (केवल > 0°C एयर कंडीशनिंग हेतु!)",
      "examFacts": [
        "घरेलू फ्रिज में Expansion Device के रूप में <b>Capillary Tube</b> उपयोग होती है।",
        "<b>R-12 (CFC)</b> ओज़ोन परत को नुकसान पहुँचाता है, इसलिए अब <b>R-134a (HFC — Ozone Friendly)</b> और <b>R-600a (Isobutane)</b> उपयोग होते हैं।",
        "<b>Bell-Coleman Cycle (Air Refrigeration)</b> हवाई जहाज़ (Aircraft) में उपयोग होता है क्योंकि हवा हल्की और सुरक्षित होती है। यह <b>Reversed Brayton Cycle</b> है।",
        "<b>Electrolux Refrigerator (3-Fluid System)</b> में कोई पंप या कंप्रेसर नहीं होता (NH₃ + Water + Hydrogen) — Hydrogen वाष्पीकरण की दर बढ़ाता है।"
      ],
      "numericals": [
        {
          "q": "एक 2 Ton (2 TR) के रेफ्रिजरेशन प्लांट का COP = 3.5 है। इसे चलाने के लिए आवश्यक कंप्रेसर पावर (kW में) निकालें।",
          "given": "Capacity = 2 TR = 2 × 3.5 = 7 kW,  COP = 3.5",
          "formula": "COP = Cooling Capacity / Power  ⇒  Power = Capacity / COP",
          "sol": "Power = 7 / 3.5 = 2 kW",
          "ans": "2 kW"
        }
      ],
      "mcqs": [
        {
          "q": "1 Ton of Refrigeration (1 TR) किसके बराबर होता है?",
          "opts": [
            "1.5 kW",
            "3.5 kW (210 kJ/min)",
            "5.0 kW",
            "10 kW"
          ],
          "ans": 1,
          "exp": "1 TR = 3.5167 kW (लगभग 3.5 kW या 210 kJ/min)।"
        },
        {
          "q": "LiBr-Water Vapour Absorption System में Refrigerant कौन होता है?",
          "opts": [
            "Lithium Bromide",
            "Water (पानी)",
            "Ammonia",
            "Hydrogen"
          ],
          "ans": 1,
          "exp": "LiBr-Water सिस्टम में Water (पानी) Refrigerant और Lithium Bromide Absorbent का कार्य करता है।"
        },
        {
          "q": "VCR Cycle में Expansion Valve (Capillary Tube) में कौन-सा प्रक्रम होता है?",
          "opts": [
            "Isentropic",
            "Isothermal",
            "Isenthalpic (Throttling)",
            "Isobaric"
          ],
          "ans": 2,
          "exp": "Expansion Valve में दाब घटता है और Enthalpy नियत (h₃ = h₄) रहती है — यह Isenthalpic Throttling है।"
        }
      ]
    },
    {
      "id": "rac_psychrometry",
      "title": "Psychrometry & Air Conditioning (साइक्रोमेट्री व एयर कंडीशनिंग)",
      "subtitle": "DBT, WBT, DPT • Relative Humidity • Cooling & Dehumidification",
      "diagram": "vcr_cycle",
      "def": "<b>Psychrometry (आर्द्रतामिति)</b> शुष्क हवा (Dry Air) और जलवाष्प (Water Vapour) के मिश्रण के गुणों का अध्ययन है। Air Conditioning का उद्देश्य तापमान के साथ-साथ आर्द्रता (Humidity), वायु वेग व शुद्धता को आरामदायक स्तर पर रखना है।",
      "points": [
        "<b>DBT (Dry Bulb Temp):</b> सामान्य थर्मामीटर से मापा गया हवा का तापमान।",
        "<b>WBT (Wet Bulb Temp):</b> गीले कपड़े से लिपटे थर्मामीटर का तापमान। <b>Wet Bulb Depression = DBT − WBT</b>।",
        "<b>DPT (Dew Point Temp):</b> वह तापमान जिस पर हवा को ठंडा करने पर जलवाष्प की पहली बूँद (ओस) बनती है।",
        "<b>Saturated Air (100% RH) के लिए:</b> <b>DBT = WBT = DPT</b> (Wet Bulb Depression = 0)। Unsaturated Air के लिए: <b>DBT > WBT > DPT</b>।",
        "<b>Summer Air Conditioning:</b> <b>Cooling & Dehumidification</b> (ठंडा करना + नमी घटाना)। <b>Winter AC:</b> <b>Heating & Humidification</b>।"
      ],
      "examples": [
        "गर्मियों का <b>Desert Cooler (हवा कूलर)</b> <b>Evaporative Cooling (Adiabatic Humidification)</b> पर काम करता है — इसमें WBT व Enthalpy नियत रहती है और सूखी गर्मी में बेहतरीन ठंडक मिलती है (लेकिन बरसात/उमस में काम नहीं करता!)।"
      ],
      "formulas": [
        "Specific Humidity (ω) = 0.622 · P_v / (P_b − P_v)  (kg of vapour / kg of dry air)",
        "Relative Humidity (φ or RH) = P_v / P_vs",
        "Sensible Heat Factor (SHF) = Sensible Heat / (Sensible Heat + Latent Heat)",
        "Bypass Factor (BPF) = (T_out − T_coil) / (T_in − T_coil)  |  Coil Efficiency = 1 − BPF"
      ],
      "trick": "<b>Summer vs Winter AC की ट्रिक:</b><br/>• <b>Summer AC:</b> Cool + <b>De</b>humidify (गर्मी व पसीने की नमी हटाओ)<br/>• <b>Winter AC:</b> Heat + Humidify (ठंड व रूखापन हटाओ)<br/>• <b>Saturated Air:</b> तीनों बराबर → <b>DBT = WBT = DPT</b>!",
      "examFacts": [
        "<b>Human Comfort Conditions:</b> तापमान <b>22°C – 25°C</b> और Relative Humidity <b>40% – 60%</b>।",
        "<b>Sensible Heating / Cooling</b> के दौरान Specific Humidity (ω) और Dew Point Temp (DPT) <b>नियत (Constant)</b> रहते हैं।",
        "<b>Sling Psychrometer</b> का उपयोग एक साथ DBT और WBT मापने के लिए किया जाता है।"
      ],
      "table": {
        "headers": [
          "प्रक्रम (Psychrometric Process)",
          "क्या नियत (Constant)?",
          "उदाहरण / उपयोग"
        ],
        "rows": [
          [
            "Sensible Heating / Cooling",
            "ω (Specific Humidity) & DPT",
            "रूम हीटर / सूखी कूलिंग कॉइल"
          ],
          [
            "Cooling & Dehumidification",
            "तापमान ↓ और ω ↓",
            "Summer AC (घरेलू AC)"
          ],
          [
            "Heating & Humidification",
            "तापमान ↑ और ω ↑",
            "Winter AC (ठंडे प्रदेश)"
          ],
          [
            "Evaporative Cooling",
            "WBT व Enthalpy नियत",
            "Desert Air Cooler (कूलर)"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "Saturated Air (100% Relative Humidity) के लिए निम्न में से कौन-सा कथन सही है?",
          "opts": [
            "DBT > WBT > DPT",
            "DBT = WBT = DPT",
            "WBT > DBT",
            "DPT = 0°C"
          ],
          "ans": 1,
          "exp": "100% संतृप्त हवा में वाष्पीकरण रुक जाता है, इसलिए DBT = WBT = DPT हो जाता है।"
        },
        {
          "q": "घरेलू कूलर (Desert Cooler) किस साइक्रोमेट्रिक प्रक्रम पर कार्य करता है?",
          "opts": [
            "Sensible Cooling",
            "Cooling & Dehumidification",
            "Evaporative Cooling (Constant WBT)",
            "Chemical Dehumidification"
          ],
          "ans": 2,
          "exp": "Desert Cooler में पानी वाष्पित होकर हवा को ठंडा करता है (Adiabatic Saturation / Constant WBT)।"
        }
      ]
    },
    {
      "id": "ht_modes_exchangers",
      "title": "Heat Transfer — Conduction, Convection, Radiation & Heat Exchangers",
      "subtitle": "Fourier, Newton & Stefan-Boltzmann Laws • Critical Radius • LMTD",
      "diagram": "condenser",
      "def": "तापमान के अंतर (Temperature Difference) के कारण ऊष्मा का उच्च तापमान से निम्न तापमान की ओर प्रवाह <b>Heat Transfer</b> कहलाता है। इसके 3 माध्यम हैं: <b>Conduction (चालन)</b>, <b>Convection (संवहन)</b> और <b>Radiation (विकिरण)</b>।",
      "points": [
        "<b>Conduction (Fourier's Law):</b> ठोसों में अणुओं के कंपन व मुक्त इलेक्ट्रॉनों द्वारा ऊष्मा प्रवाह: <b>Q = −k A (dT/dx)</b>। Thermal Conductivity (k) सबसे अधिक <b>Diamond / Silver / Copper</b> की होती है।",
        "<b>Convection (Newton's Law of Cooling):</b> तरल गति द्वारा ऊष्मा प्रवाह: <b>Q = h A (T_s − T_∞)</b>।",
        "<b>Radiation (Stefan-Boltzmann Law):</b> विद्युत चुंबकीय तरंगों द्वारा (माध्यम की ज़रूरत नहीं): <b>E_b = σ T⁴</b> (जहाँ σ = 5.67 × 10⁻⁸ W/m²K⁴)।",
        "<b>Critical Radius of Insulation (r_c):</b> वह त्रिज्या जिस पर ऊष्मा हानि अधिकतम होती है। <b>Cylinder/Pipe: r_c = k / h</b> ; <b>Sphere: r_c = 2k / h</b>।",
        "<b>Heat Exchangers:</b> <b>Counter-Flow Heat Exchanger</b> की दक्षता व LMTD हमेशा <b>Parallel-Flow</b> से अधिक होती है (कम सतह क्षेत्रफल लगता है)।"
      ],
      "examples": [
        "बिजली के पतले तार पर प्लास्टिक (Insulation) चढ़ाने से तार ठंडा रहता है क्योंकि तार की त्रिज्या Critical Radius से कम होती है, जिससे ऊष्मा हानि बढ़ती है!"
      ],
      "formulas": [
        "Fourier's Law (Conduction): Q = k · A · (T₁ − T₂) / L  |  Thermal Resistance R_th = L / (k·A)",
        "Newton's Law (Convection): Q = h · A · ΔT  |  Convective Resistance = 1 / (h·A)",
        "Stefan-Boltzmann (Black Body): E_b = σ · T⁴  |  Wien's Displacement Law: λ_max · T = 2898 μm·K",
        "Critical Radius: Cylinder r_c = k / h ;  Sphere r_c = 2k / h",
        "Dimensionless Numbers: Nusselt Nu = hL/k | Prandtl Pr = μCp/k | Biot Bi = hL_c/k"
      ],
      "trick": "<b>Heat Transfer के 4 ज़रूरी नंबर — 'Nu-Co, Bi-Lu, Pr-Flu, Gr-Free':</b> <b>Nu</b>sselt = <b>Co</b>nvection, <b>Bi</b>ot (<0.1) = <b>Lu</b>mped Analysis, <b>Pr</b>andtl = <b>Flu</b>id Property, <b>Gr</b>ashof = <b>Free</b> Convection!",
      "examFacts": [
        "<b>Kirchhoff's Law:</b> तापीय साम्य में किसी पिंड की Emissivity (ε) उसकी Absorptivity (α) के बराबर (<b>ε = α</b>) होती है।",
        "<b>Black Body</b> के लिए α = 1, ρ = 0, τ = 0 होता है। <b>White Body</b> के लिए ρ = 1।",
        "<b>Fins (Extended Surfaces)</b> का उपयोग Convection ऊष्मा अंतरण बढ़ाने के लिए किया जाता है (जैसे बाइक के इंजन सिलेंडर पर पंख) — ये तब सबसे असरदार होते हैं जब <b>h कम हो</b> (हवा में)।"
      ],
      "numericals": [
        {
          "q": "एक स्टीम पाइप पर लगे इंसुलेशन की Thermal Conductivity k = 0.2 W/m·K है और बाहर हवा का Convective Coefficient h = 10 W/m²·K है। Critical Radius of Insulation (r_c) निकालें।",
          "given": "k = 0.2 W/m·K, h = 10 W/m²·K (पाइप = Cylinder)",
          "formula": "r_c = k / h",
          "sol": "r_c = 0.2 / 10 = 0.02 m = 20 mm (2 cm)",
          "ans": "20 mm (2 cm)"
        }
      ],
      "mcqs": [
        {
          "q": "बेलनाकार पाइप (Cylinder) के लिए Critical Radius of Insulation का सूत्र क्या होता है?",
          "opts": [
            "2k / h",
            "k / h",
            "h / k",
            "k / 2h"
          ],
          "ans": 1,
          "exp": "Cylinder/Pipe के लिए r_c = k/h और Sphere (गोले) के लिए r_c = 2k/h होता है।"
        },
        {
          "q": "समान इनलेट व आउटलेट तापमानों के लिए किस Heat Exchanger का LMTD अधिक और क्षेत्रफल कम लगता है?",
          "opts": [
            "Parallel Flow",
            "Counter Flow",
            "दोनों बराबर",
            "इनमें से कोई नहीं"
          ],
          "ans": 1,
          "exp": "Counter-Flow Heat Exchanger में तापमान का अंतर पूरे पाइप में संतुलित रहता है, इसलिए LMTD अधिक और दक्षता उच्च होती है।"
        }
      ]
    }
  ]
},
{
  "id": "production_mat",
  "name": "Production, Material Science & Metrology (उत्पादन व पदार्थ विज्ञान)",
  "icon": "🔧",
  "category": "tech",
  "weight": "High (10–13 Marks)",
  "topics": [
    {
      "id": "prod_iron_carbon",
      "title": "Engineering Materials, Iron-Carbon Diagram & Heat Treatment",
      "subtitle": "Crystal Structures • Pearlite, Martensite • Annealing, Normalizing, Tempering",
      "diagram": "iron_carbon",
      "def": "<b>Iron-Carbon (Fe-Fe₃C) Diagram</b> स्टील (< 2% C) और कास्ट आयरन (2% – 6.67% C) की विभिन्न सूक्ष्म संरचनाओं (Microstructures) को तापमान व कार्बन प्रतिशत के अनुसार दर्शाता है। <b>Heat Treatment</b> नियंत्रित गरम व ठंडा करके धातु के यांत्रिक गुण बदलने की विधि है।",
      "points": [
        "<b>Crystal Structures:</b> <b>BCC</b> (α-Iron/Ferrite, Cr, W — APF = 0.68, Coordination No. = 8), <b>FCC</b> (γ-Iron/Austenite, Al, Cu, Ni — सबसे ज़्यादा Ductile, APF = 0.74, CN = 12), <b>HCP</b> (Mg, Zn, Ti — APF = 0.74, CN = 12)।",
        "<b>3 मुख्य अभिक्रियाएँ (Fe-C Diagram):</b> 1) <b>Eutectoid (727°C, 0.8% C):</b> Austenite → <b>Pearlite</b> (Ferrite + Cementite); 2) <b>Eutectic (1147°C, 4.3% C):</b> Liquid → <b>Ledeburite</b>; 3) <b>Peritectic (1495°C, 0.18% C)</b>।",
        "<b>Cooling Rate का असर:</b> Furnace Cooling (Annealing) → <b>Coarse Pearlite (नरम)</b>; Air Cooling (Normalizing) → <b>Fine Pearlite</b>; Water/Brine Quenching (Hardening) → <b>Martensite (सबसे कठोर व भंगुर)</b>।",
        "<b>Tempering:</b> Hardening के बाद भंगुरता (Brittleness) घटाने और Toughness बढ़ाने हेतु पुनः गरम करना।",
        "<b>Case Hardening (केवल सतह कठोर, अंदर नरम):</b> Carburizing, <b>Nitriding</b> (सबसे कठोर सतह, बिना Quenching के), Cyaniding, Induction/Flame Hardening।"
      ],
      "examples": [
        "लेथ मशीन का बेड (Bed) <b>Grey Cast Iron</b> का बनता है क्योंकि इसमें मौजूद Flake Graphite कंपन (Vibration) को शानदार तरीके से सोख लेता है (High Damping Capacity)।"
      ],
      "formulas": [
        "Atomic Packing Factor (APF): Simple Cubic = 0.52 | BCC = 0.68 | FCC & HCP = 0.74",
        "Brass = Copper + Zinc (Cu + Zn)  |  Bronze = Copper + Tin (Cu + Sn)",
        "18-4-1 HSS (High Speed Steel) = 18% Tungsten (W), 4% Chromium (Cr), 1% Vanadium (V)",
        "18-8 Stainless Steel = 18% Chromium (जंगरोधी) + 8% Nickel"
      ],
      "trick": "<b>Brass vs Bronze की अचूक ट्रिक — 'Bra-Z, Bro-T':</b> Bra<b>ss</b> में Z नहीं है तो <b>Z</b>inc (Cu+Zn) | Bro<b>nze</b> में Z है तो <b>T</b>in (Cu+Sn) — हमेशा उल्टा! <br/><b>Cooling Medium:</b> <b>A</b>nnealing = Furnace, <b>N</b>ormalizing = <b>A</b>ir, <b>H</b>ardening = Water/Oil (Quenching)!",
      "examFacts": [
        "<b>Cementite (Fe₃C)</b> में <b>6.67% Carbon</b> होता है और यह सबसे कठोर व भंगुर फेज़ है; <b>Ferrite</b> सबसे नरम व तन्य (Ductile) है।",
        "<b>Invar</b> (36% Ni + 64% Fe) का तापीय प्रसार गुणांक लगभग शून्य होता है (मापन टेप व घड़ियों में उपयोग)।",
        "<b>Spheroidizing Annealing</b> का उपयोग High Carbon Steel की <b>Machinability</b> सुधारने के लिए किया जाता है।"
      ],
      "table": {
        "headers": [
          "Heat Treatment",
          "Cooling Medium",
          "मुख्य उद्देश्य (Purpose)"
        ],
        "rows": [
          [
            "Annealing",
            "Furnace (बहुत धीमा)",
            "धातु को नरम बनाना, Internal Stress हटाना"
          ],
          [
            "Normalizing",
            "Still Air (हवा में)",
            "Grain Structure महीन करना, मज़बूती बढ़ाना"
          ],
          [
            "Hardening (Quenching)",
            "Water / Brine / Oil",
            "Martensite बनाकर अधिकतम कठोरता देना"
          ],
          [
            "Tempering",
            "Reheat (< 727°C) + Air",
            "भंगुरता घटाना और Toughness बढ़ाना"
          ],
          [
            "Nitriding",
            "NH₃ Gas (500–550°C)",
            "बिना Quenching के अत्यंत कठोर सतह (Gears)"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "Iron-Carbon Diagram में Eutectoid Point कितने कार्बन प्रतिशत और तापमान पर होता है?",
          "opts": [
            "4.3% C, 1147°C",
            "0.8% C, 727°C",
            "2.0% C, 910°C",
            "6.67% C, 1539°C"
          ],
          "ans": 1,
          "exp": "0.8% C और 727°C पर Eutectoid अभिक्रिया होती है जिसमें Austenite बदलकर Pearlite बनाता है।"
        },
        {
          "q": "मशीन के बेड (जैसे Lathe Bed) बनाने के लिए Grey Cast Iron क्यों उपयोग किया जाता है?",
          "opts": [
            "उच्च तन्य सामर्थ्य के कारण",
            "उच्च कंपन अवशोषण क्षमता (High Damping Capacity)",
            "हल्के वज़न के कारण",
            "जंगरोधी होने के कारण"
          ],
          "ans": 1,
          "exp": "Grey Cast Iron में मुक्त ग्रेफ़ाइट फ्लेक्स होते हैं जो कंपन (Vibrations) को सोख लेते हैं और संपीड़न में बहुत मज़बूत होते हैं।"
        },
        {
          "q": "18-4-1 High Speed Steel (HSS) में 18% क्या होता है?",
          "opts": [
            "Chromium",
            "Tungsten (टंगस्टन)",
            "Vanadium",
            "Nickel"
          ],
          "ans": 1,
          "exp": "18-4-1 HSS = 18% Tungsten (Red Hardness हेतु) + 4% Chromium + 1% Vanadium।"
        }
      ]
    },
    {
      "id": "prod_casting",
      "title": "Metal Casting, Patterns, Gating & Defects (ढलाई एवं कास्टिंग)",
      "subtitle": "Pattern Allowances • Chvorinov's Rule • Die & Centrifugal Casting • Defects",
      "diagram": "welding_casting",
      "def": "<b>Casting (ढलाई)</b> सबसे पुरानी निर्माण प्रक्रिया है जिसमें पिघली हुई धातु (Molten Metal) को एक साँचे (Mould Cavity) में डालकर ठंडा करके वांछित आकार दिया जाता है।",
      "points": [
        "<b>Pattern Allowances:</b> 1) <b>Shrinkage Allowance</b> (सिकुड़न हेतु — Shrinkage Rule से मापा जाता है), 2) <b>Draft / Taper Allowance</b> (साँचे से पैटर्न आसानी से निकालने हेतु), 3) <b>Machining Allowance</b>, 4) <b>Shake/Rapping Allowance</b> (एकमात्र <b>Negative Allowance</b>!), 5) <b>Distortion/Camber Allowance</b>।",
        "<b>Gating System:</b> Pouring Basin → <b>Sprue</b> (ऊर्ध्वाधर टेपर नली, Aspiration रोकने हेतु Parabolic/Tapered) → Runner → Gate → Mould Cavity → <b>Riser</b>।",
        "<b>Riser (राइज़र):</b> यह पिघली धातु का रिज़र्वॉयर है जो ठोस बनते समय होने वाले <b>Liquid & Solidification Shrinkage</b> की पूर्ति करता है।",
        "<b>Chills & Chaplets:</b> <b>Chills</b> (धातु टुकड़े) मोटे हिस्से को जल्दी ठंडा करके Directional Solidification करते हैं; <b>Chaplets</b> साँचे के अंदर <b>Core को सहारा</b> देते हैं।",
        "<b>Special Castings:</b> <b>Centrifugal Casting</b> (बिना Core के खोखले पाइप बनाना), <b>Investment (Lost-Wax) Casting</b> (टरबाइन ब्लेड्स, गहने — उच्च फिनिश), <b>Die Casting</b> (Al/Zn के बड़े पैमाने पर पार्ट्स)।"
      ],
      "examples": [
        "इंजन ब्लॉक, पंप केसिंग, टरबाइन हाउसिंग और फ्लाईव्हील <b>Casting</b> से बनाए जाते हैं।"
      ],
      "formulas": [
        "Chvorinov's Rule (Solidification Time): t_s = k · (V / A)²  [V = Volume, A = Surface Area]",
        "Optimal Riser Shape (न्यूनतम A/V): Sphere (आदर्श), व्यावहारिक रूप से Cylinder (H = D)",
        "Permeability Number = (V · H) / (P · A · T)"
      ],
      "trick": "<b>कास्टिंग के 4 सीधे सवाल रट लो:</b><br/>• एकमात्र <b>Negative Allowance</b> = Shake/Rapping Allowance<br/>• <b>Core को सहारा</b> = Chaplets<br/>• <b>बिना Core के खोखले पाइप</b> = True Centrifugal Casting<br/>• <b>गैस फँसने का दोष</b> = Blow Holes (कम Permeability से)!",
      "examFacts": [
        "<b>Green Sand Moulding</b> में 'Green' का अर्थ रंग नहीं, बल्कि रेत में <b>नमी (Moisture ~4–8%)</b> की उपस्थिति है।",
        "<b>Hot Tear</b> दोष उच्च तापमान पर सिकुड़न में बाधा आने के कारण होता है; <b>Cold Shut</b> तब होता है जब धातु की दो धाराएँ ठीक से न मिल पाएँ (कम Pouring Temp)।"
      ],
      "table": {
        "headers": [
          "कास्टिंग दोष (Defect)",
          "मुख्य कारण (Cause)",
          "बचाव (Remedy)"
        ],
        "rows": [
          [
            "Blow Holes / Pinholes",
            "रेत में अधिक नमी / कम Permeability",
            "अच्छी Venting व सही Permeability"
          ],
          [
            "Shrinkage Cavity",
            "Riser का छोटा होना / अपर्याप्त फीडिंग",
            "सही Riser व Chills का उपयोग"
          ],
          [
            "Misrun / Cold Shut",
            "धातु का तापमान कम होना (कम Fluidity)",
            "Pouring Temp बढ़ाना"
          ],
          [
            "Hot Tears",
            "ठोस बनते समय बाधा (Excessive Restraint)",
            "रेत की Collapsibility बढ़ाना"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "निम्न में से कौन-सा एक Negative Pattern Allowance है?",
          "opts": [
            "Shrinkage Allowance",
            "Draft Allowance",
            "Shake (Rapping) Allowance",
            "Machining Allowance"
          ],
          "ans": 2,
          "exp": "पैटर्न को हिलाकर (Rap करके) निकालने से कैविटी थोड़ी बड़ी हो जाती है, इसलिए पैटर्न थोड़ा छोटा बनाया जाता है (Negative Allowance)।"
        },
        {
          "q": "साँचे (Mould) के अंदर Core को सहारा देने के लिए किसका उपयोग किया जाता है?",
          "opts": [
            "Chills",
            "Chaplets",
            "Riser",
            "Sprue"
          ],
          "ans": 1,
          "exp": "Chaplets उसी धातु के छोटे सहारे होते हैं जो Core को साँचे में सही स्थान पर टिकाए रखते हैं।"
        }
      ]
    },
    {
      "id": "prod_welding",
      "title": "Welding Processes, Gas Flames, Soldering & Brazing (वेल्डिंग)",
      "subtitle": "Arc Polarity (DCEN/DCEP) • 3 Oxy-Acetylene Flames • TIG vs MIG • Resistance",
      "diagram": "welding_casting",
      "def": "<b>Welding</b> दो धातु के टुकड़ों को ऊष्मा या दबाव (या दोनों) की मदद से परमाणु स्तर पर स्थायी रूप से जोड़ने की प्रक्रिया है।",
      "points": [
        "<b>Oxy-Acetylene Gas Welding के 3 फ्लेम:</b><br/>1) <b>Neutral Flame (O₂ : C₂H₂ = 1:1, ~3200°C):</b> स्टील, कास्ट आयरन, Al के लिए सबसे सामान्य।<br/>2) <b>Carburizing / Reducing Flame (अधिक Acetylene, 3 Zones):</b> High Carbon Steel, Monel।<br/>3) <b>Oxidizing Flame (अधिक Oxygen, सबसे गरम ~3300°C):</b> केवल <b>Brass व Bronze</b> (पीतल-काँसा) के लिए।",
        "<b>DC Arc Welding Polarity:</b> <b>Straight Polarity (DCEN):</b> Electrode (−), Workpiece (+) ⇒ 2/3 ऊष्मा Workpiece पर (मोटी प्लेटों की गहरी वेल्डिंग)। <b>Reverse Polarity (DCEP):</b> Electrode (+) ⇒ पतली शीट व एल्युमिनियम के लिए।",
        "<b>TIG (GTAW):</b> <b>Non-consumable Tungsten Electrode</b> + Inert Gas (Argon/Helium) — पतली शीट, Al, Mg, Stainless Steel के लिए सबसे साफ वेल्ड।",
        "<b>MIG (GMAW):</b> <b>Consumable Wire Electrode</b> + Inert/CO₂ Gas — तेज़ और मोटी प्लेटों के लिए।",
        "<b>Brazing vs Soldering:</b> दोनों में Base Metal नहीं पिघलता (केवल Filler Metal पिघलता है)। <b>Soldering: < 450°C</b> (Pb-Sn); <b>Brazing: > 450°C</b> (Spelter: Cu-Zn)।"
      ],
      "examples": [
        "रेल की पटरियों को जोड़ने के लिए <b>Thermit Welding</b> (Al + Fe₂O₃ की रासायनिक ऊष्मा) और कार की बॉडी शीट्स जोड़ने के लिए <b>Spot Resistance Welding</b> उपयोग होती है।"
      ],
      "formulas": [
        "Resistance Welding Heat (Joule's Law): H = I² · R · t (Joules)",
        "Arc Voltage–Length Relation: V = a + b · L  (जहाँ L = Arc Length)",
        "Power Source for Arc Welding: <b>Drooping Characteristics (Constant Current Transformer)</b>"
      ],
      "trick": "<b>3 मुख्य वेल्डिंग ट्रिक्स:</b><br/>• <b>Oxidizing Flame</b> = सबसे गरम, केवल <b>Brass</b> के लिए<br/>• <b>TIG = Non-Consumable</b> Tungsten | <b>MIG = Consumable</b> Wire<br/>• <b>450°C की रेखा:</b> नीचे = Soldering, ऊपर = Brazing!",
      "examFacts": [
        "<b>Submerged Arc Welding (SAW)</b> में आर्क दानेदार फ्लक्स (Granular Flux) के नीचे ढका रहता है — कोई चिंगारी/धुआँ नहीं, भारी प्लेटों की फ्लैट वेल्डिंग हेतु।",
        "<b>Flux Coating (इलेक्ट्रोड पर लेप)</b> पिघली धातु को हवा की ऑक्सीजन/नाइट्रोजन से बचाती है (Slag बनाकर) और आर्क स्थिर रखती है।",
        "<b>Friction Welding</b> और <b>Ultrasonic Welding</b> Solid-State Welding हैं (धातु बिना पिघले जुड़ती है)।"
      ],
      "numericals": [
        {
          "q": "Spot Welding में 10,000 A का करंट 0.2 सेकंड तक प्रवाहित होता है। यदि जोड़ का प्रतिरोध R = 0.0001 Ω हो, तो उत्पन्न ऊष्मा (H) ज्ञात करें।",
          "given": "I = 10⁴ A, R = 10⁻⁴ Ω, t = 0.2 s",
          "formula": "H = I² · R · t",
          "sol": "H = (10⁴)² × 10⁻⁴ × 0.2 = 10⁸ × 10⁻⁴ × 0.2 = 10⁴ × 0.2 = 2000 Joules (2 kJ)",
          "ans": "2000 J (2 kJ)"
        }
      ],
      "mcqs": [
        {
          "q": "ब्रास (Brass) की गैस वेल्डिंग के लिए किस प्रकार के फ्लेम का उपयोग किया जाता है?",
          "opts": [
            "Neutral Flame",
            "Carburizing Flame",
            "Oxidizing Flame",
            "इनमें से कोई नहीं"
          ],
          "ans": 2,
          "exp": "Oxidizing Flame (अधिक O₂) पीतल में मौजूद जिंक के वाष्पीकरण को रोकता है।"
        },
        {
          "q": "रेल की पटरियों को जोड़ने के लिए किस वेल्डिंग प्रक्रिया का उपयोग किया जाता है?",
          "opts": [
            "TIG Welding",
            "Spot Welding",
            "Thermit Welding",
            "MIG Welding"
          ],
          "ans": 2,
          "exp": "Thermit Welding में एल्युमिनियम और आयरन ऑक्साइड की Exothermic अभिक्रिया से पिघला लोहा बनता है जो पटरियों को जोड़ता है।"
        }
      ]
    },
    {
      "id": "prod_machining",
      "title": "Metal Cutting, Lathe, Milling, Shaper & Grinding (मशीनिंग)",
      "subtitle": "Single Point Tool • Taylor's Tool Life • Up vs Down Milling • Quick Return",
      "diagram": "gears",
      "def": "<b>Machining</b> एक Material Removal प्रक्रिया है जिसमें कटिंग टूल की मदद से वर्कपीस से अतिरिक्त धातु चिप्स (Chips) के रूप में काटकर सटीक आकार व सतह फिनिश प्राप्त की जाती है।",
      "points": [
        "<b>3 प्रकार की चिप्स:</b> <b>Continuous Chips</b> (Ductile धातु, उच्च गति, अधिक Rake Angle), <b>Discontinuous Chips</b> (Brittle धातु जैसे Cast Iron, कम गति), <b>Continuous with BUE</b> (मध्यम गति, उच्च घर्षण)।",
        "<b>Lathe Machine:</b> Turning, Facing, Taper Turning (Compound Rest, Tailstock Offset, Form Tool, Taper Attachment), Threading, Knurling। <b>Lead Screw</b> में <b>Acme Thread (29°)</b> होती है।",
        "<b>Shaper vs Planer:</b> Shaper में <b>Tool आगे-पीछे (Reciprocate)</b> चलता है (छोटे जॉब), जबकि Planer में <b>Workpiece/Table</b> आगे-पीछे चलता है (बड़े जॉब)। दोनों में Quick Return Mechanism लगता है।",
        "<b>Up Milling vs Down Milling:</b> <b>Up (Conventional) Milling</b> में कटर व फ़ीड विपरीत दिशा में चलते हैं (शुरुआत में चिप मोटाई 0)। <b>Down (Climb) Milling</b> में एक ही दिशा में (बेहतर सतह फिनिश, Backlash Eliminator चाहिए)।",
        "<b>Grinding Wheel:</b> <b>Loading</b> (नरम धातु के कण पहिए के छिद्रों में फँसना), <b>Glazing</b> (पहिए के दाने घिसकर चिकने/चमकदार हो जाना), <b>Dressing</b> (पहिए को फिर से तेज़ करना)।"
      ],
      "examples": [
        "मशीन शॉप में बेलनाकार शाफ़्ट पर चूड़ी काटना (Threading) लेथ पर और गियर के दाँत काटना <b>Milling (Indexing Head)</b> पर किया जाता है।"
      ],
      "formulas": [
        "Cutting Speed (Lathe): V = (π · D · N) / 1000  (m/min, जब D mm में हो)",
        "Taylor's Tool Life Equation: V · T^n = C  (n = 0.1–0.15 HSS, 0.25–0.4 Carbide, 0.5–0.7 Ceramic)",
        "Merchant's Shear Angle Relation: 2φ + β − α = 90°",
        "Chip Thickness Ratio: r = t / t_c  (हमेशा r < 1, क्योंकि चिप मोटी होती है)"
      ],
      "trick": "<b>टूल लाइफ़ पर सबसे ज़्यादा असर किसका? — 'V-F-D':</b> <b>V</b>elocity (सबसे ज़्यादा असर) > <b>F</b>eed > <b>D</b>epth of Cut (सबसे कम असर)! <br/><b>Shaper vs Planer:</b> <b>S</b>haper = <b>S</b>mall job (Tool moves) | <b>P</b>laner = <b>B</b>ig job (Work moves)!",
      "examFacts": [
        "<b>Rake Angle</b> बढ़ने से Cutting Force व पावर कम लगती है, लेकिन टूल की टिप कमज़ोर होती है (Brittle/कठोर धातु के लिए <b>Negative Rake Angle</b> उपयोग होता है)।",
        "<b>Crater Wear</b> टूल के Rake Face पर (Diffusion से) और <b>Flank Wear</b> टूल के Flank Face पर (Abrasion से) होता है।",
        "<b>Forging, Rolling, Extrusion, Wire Drawing</b> Bulk Metal Forming प्रक्रियाएँ हैं; Recrystallization Temp से ऊपर = <b>Hot Working</b>, नीचे = <b>Cold Working</b> (Strain Hardening होता है)।"
      ],
      "numericals": [
        {
          "q": "एक लेथ मशीन पर 100 mm व्यास के जॉब को 300 RPM पर घुमाया जा रहा है। Cutting Speed (m/min में) ज्ञात करें (π = 3.14)।",
          "given": "D = 100 mm, N = 300 RPM",
          "formula": "V = (π · D · N) / 1000",
          "sol": "V = (3.14 × 100 × 300) / 1000 = 3.14 × 30 = 94.2 m/min",
          "ans": "94.2 m/min"
        },
        {
          "q": "Taylor's Equation VT^0.5 = C के अनुसार यदि Cutting Speed को आधा (Half) कर दिया जाए, तो Tool Life कितनी गुनी बढ़ जाएगी?",
          "given": "n = 0.5,  V₂ = V₁ / 2",
          "formula": "V₁ · T₁^n = V₂ · T₂^n  ⇒  (T₂/T₁)^0.5 = V₁/V₂ = 2",
          "sol": "दोनों तरफ़ वर्ग करने पर: T₂ / T₁ = 2² = 4 (Tool Life 4 गुनी हो जाएगी!)",
          "ans": "4 गुनी (4 times)"
        }
      ],
      "mcqs": [
        {
          "q": "Taylor's Tool Life Equation के अनुसार Tool Life को सबसे अधिक कौन प्रभावित करता है?",
          "opts": [
            "Depth of Cut",
            "Feed Rate",
            "Cutting Velocity (Speed)",
            "Coolant"
          ],
          "ans": 2,
          "exp": "क्रम है: Cutting Speed (V) > Feed (f) > Depth of Cut (d)।"
        },
        {
          "q": "Grinding Wheel के कटिंग कणों का घिसकर चिकना व चमकदार हो जाना क्या कहलाता है?",
          "opts": [
            "Loading",
            "Glazing",
            "Truing",
            "Honing"
          ],
          "ans": 1,
          "exp": "कणों का चिकना होकर काटना बंद करना Glazing कहलाता है; और छिद्रों में धातु फँसना Loading कहलाता है।"
        }
      ]
    },
    {
      "id": "prod_metrology",
      "title": "Limits, Fits, Tolerances & Metrology (सहिष्णुता व मापन यंत्र)",
      "subtitle": "Clearance/Interference/Transition Fit • Taylor's Gauge Principle • Vernier & Micrometer",
      "diagram": "limits_fits",
      "def": "बड़े पैमाने पर उत्पादन (Mass Production) में पुर्जों की <b>Interchangeability (परस्पर विनिमेयता)</b> सुनिश्चित करने के लिए <b>Limits, Fits & Tolerances</b> और सूक्ष्म मापन यंत्रों (Metrology) का उपयोग होता है।",
      "points": [
        "<b>Tolerance (सहिष्णुता):</b> अधिकतम स्वीकार्य आकार और न्यूनतम स्वीकार्य आकार का अंतर (Upper Limit − Lower Limit)। <b>Unilateral</b> (एक दिशा में) और <b>Bilateral</b> (दोनों दिशाओं में)।",
        "<b>3 प्रकार के Fits:</b> 1) <b>Clearance Fit:</b> Hole हमेशा Shaft से बड़ा (आसानी से घूमना/खिसकना)। 2) <b>Interference Fit:</b> Shaft हमेशा Hole से बड़ा (Press/Shrink Fit)। 3) <b>Transition Fit:</b> दोनों के बीच ओवरलैप (Tight/Push Fit)।",
        "<b>Hole Basis System (H7-g6):</b> सबसे अधिक प्रयुक्त — इसमें Hole का Lower Deviation शून्य (<b>Capital H</b>) रखकर Shaft का आकार बदला जाता है (क्योंकि Drill/Reamer का आकार तय होता है)।",
        "<b>Taylor's Principle of Gauge Design:</b> <b>GO Gauge</b> को <b>Maximum Metal Limit (MML)</b> पर और <b>NO-GO Gauge</b> को <b>Minimum Metal Limit</b> पर बनाया जाता है।",
        "<b>Metrology यंत्र:</b> <b>Vernier Caliper</b> (LC = 0.02 mm), <b>Micrometer</b> (LC = 0.01 mm), <b>Sine Bar</b> (सटीक कोण मापन, 45° तक), <b>Slip Gauges</b> (Wringing से जुड़ते हैं), <b>Optical Flat</b> (Light Interference से Flatness जाँच)।"
      ],
      "examples": [
        "<b>H7-f7</b> में बड़ा अक्षर <b>'H' Hole</b> को और छोटा अक्षर <b>'f' Shaft</b> को दर्शाता है — चूँकि f (a से h के बीच) है, यह एक <b>Clearance Fit</b> है!"
      ],
      "formulas": [
        "Tolerance = Upper Limit − Lower Limit",
        "Max Clearance = Max Hole − Min Shaft  |  Min Clearance = Min Hole − Max Shaft",
        "Vernier Least Count (LC) = 1 MSD − 1 VSD (सामान्यतः 0.02 mm)",
        "Micrometer Least Count (LC) = Pitch / No. of Thimble Divisions = 0.5 / 50 = 0.01 mm",
        "Sine Bar Angle: sin θ = h / L  (जहाँ L = दोनों रोलर्स के केंद्रों की दूरी)"
      ],
      "trick": "<b>Hole-Shaft Fit अक्षर ट्रिक (H-Hole के साथ):</b> Shaft के अक्षर <b>a से h</b> = <b>Clearance Fit</b> | <b>j, k, m, n</b> = <b>Transition Fit</b> | <b>p से z</b> = <b>Interference Fit</b>!<br/><b>GO Gauge Trick:</b> '<b>GO</b> = <b>M</b>aximum <b>M</b>etal Limit' (Hole के लिए सबसे छोटा व्यास, Shaft के लिए सबसे बड़ा व्यास)!",
      "examFacts": [
        "<b>Plug Gauge</b> से अंदरूनी छेद (Internal Hole) और <b>Snap / Ring Gauge</b> से बाहरी शाफ़्ट (External Shaft) की जाँच होती है।",
        "<b>Sine Bar</b> का उपयोग 45° से बड़े कोण मापने में नहीं किया जाता क्योंकि 45° के बाद त्रुटि बहुत बढ़ जाती है।",
        "<b>Slip Gauges (Johansson Gauges)</b> आपस में <b>Wringing</b> (आणविक आकर्षण + वायुमंडलीय दाब) द्वारा चिपकते हैं।"
      ],
      "numericals": [
        {
          "q": "एक Hole का आकार 50.00 (+0.05 / +0.00) mm और Shaft का आकार 50.00 (−0.02 / −0.05) mm है। Maximum व Minimum Clearance और Fit का प्रकार बताइए।",
          "given": "Hole: Max = 50.05, Min = 50.00 mm.  Shaft: Max = 49.98, Min = 49.95 mm",
          "formula": "Max Cl = Max Hole − Min Shaft ;  Min Cl = Min Hole − Max Shaft",
          "sol": "Max Cl = 50.05 − 49.95 = 0.10 mm.  Min Cl = 50.00 − 49.98 = +0.02 mm. चूँकि दोनों धनात्मक (+) हैं ⇒ Clearance Fit",
          "ans": "Max Cl = 0.10 mm, Min Cl = 0.02 mm (Clearance Fit)"
        }
      ],
      "mcqs": [
        {
          "q": "सामान्य Metric Micrometer का Least Count (अल्पतमांक) कितना होता है?",
          "opts": [
            "0.1 mm",
            "0.02 mm",
            "0.01 mm",
            "0.001 mm"
          ],
          "ans": 2,
          "exp": "सामान्य Micrometer का Pitch = 0.5 mm और Thimble पर 50 भाग होते हैं, इसलिए LC = 0.5/50 = 0.01 mm।"
        },
        {
          "q": "Taylor's Principle के अनुसार GO Gauge को किस सीमा (Limit) पर डिज़ाइन किया जाता है?",
          "opts": [
            "Minimum Metal Limit",
            "Maximum Metal Limit",
            "Nominal Size",
            "Mean Size"
          ],
          "ans": 1,
          "exp": "GO Gauge = Maximum Metal Limit (MML) और NO-GO Gauge = Minimum Metal Limit।"
        }
      ]
    }
  ]
},
{
  "id": "eng_mechanics",
  "name": "Engineering Mechanics (इंजीनियरिंग यांत्रिकी)",
  "icon": "⚖️",
  "category": "tech",
  "weight": "Medium (4–6 Marks)",
  "topics": [
    {
      "id": "em_statics_friction",
      "title": "Forces, Equilibrium, Lami's Theorem & Friction (बल व घर्षण)",
      "subtitle": "Parallelogram Law • Varignon's Theorem • Angle of Repose • Screw Jack",
      "diagram": "columns",
      "def": "<b>Engineering Mechanics</b> बलों के प्रभाव में स्थिर (Statics) और गतिशील (Dynamics) पिंडों के व्यवहार का अध्ययन है। <b>Friction (घर्षण)</b> संपर्क में रखी दो सतहों के बीच सापेक्ष गति का विरोध करने वाला बल है।",
      "points": [
        "<b>Parallelogram Law:</b> दो बलों P व Q (कोण θ) का परिणामी <b>R = √(P² + Q² + 2PQ cos θ)</b>।",
        "<b>Lami's Theorem:</b> यदि एक बिंदु पर लगने वाले <b>3 समतलीय (Coplanar Concurrent)</b> बल संतुलन में हों, तो प्रत्येक बल अपने विपरीत कोण के sin के समानुपाती होता है।",
        "<b>Varignon's Theorem:</b> किसी बिंदु के परितः कई बलों के आघूर्णों का बीजगणितीय योग, उनके परिणामी बल के आघूर्ण के बराबर होता है।",
        "<b>Laws of Dry Friction:</b> घर्षण बल (F = μ·N) अभिलंब प्रतिक्रिया (N) के समानुपाती होता है और <b>संपर्क क्षेत्रफल (Area of Contact) से स्वतंत्र</b> होता है।",
        "<b>Self-Locking Screw Jack:</b> जब Helix Angle (α) ≤ Friction Angle (φ) हो — तब दक्षता हमेशा <b>50% से कम (η < 50%)</b> होती है!"
      ],
      "examples": [
        "चिकने बर्फ़ पर चलना कठिन है क्योंकि μ कम होता है; और ढलान पर रेत का ढेर जिस अधिकतम कोण पर बिना फिसले टिकता है, वही <b>Angle of Repose (α = φ)</b> है।"
      ],
      "formulas": [
        "Resultant of 2 Forces: R = √(P² + Q² + 2 P Q cos θ)",
        "Lami's Theorem: P / sin α = Q / sin β = R / sin γ",
        "Limiting Friction: F_max = μ · N  |  Coefficient of Friction: μ = tan φ (जहाँ φ = Angle of Friction)",
        "Angle of Repose (θ_r) = Angle of Friction (φ)",
        "Max Efficiency of Screw Jack: η_max = (1 − sin φ) / (1 + sin φ)"
      ],
      "trick": "<b>Screw Jack Self-Locking ट्रिक:</b> यदि कोई मशीन <b>Self-Locking</b> है (लोड अपने आप नीचे न गिरे), तो उसकी दक्षता हमेशा <b>< 50%</b> होगी! और <b>Static Friction > Dynamic/Kinetic Friction > Rolling Friction</b>!",
      "examFacts": [
        "एक <b>Couple (बल-युग्म)</b> दो बराबर व विपरीत समानांतर बलों से बनता है जिसका कुल परिणामी बल शून्य होता है और यह केवल शुद्ध घूर्णन (Pure Rotation) उत्पन्न करता है।",
        "घर्षण बल संपर्क सतह के क्षेत्रफल पर <b>निर्भर नहीं करता</b>, केवल सतह के खुरदरेपन (μ) और अभिलंब बल (N) पर निर्भर करता है।"
      ],
      "numericals": [
        {
          "q": "दो बल 30 N और 40 N एक बिंदु पर 90° के कोण पर कार्य कर रहे हैं। उनका परिणामी बल (Resultant R) निकालें।",
          "given": "P = 30 N, Q = 40 N, θ = 90° (cos 90° = 0)",
          "formula": "R = √(P² + Q² + 2PQ cos θ)",
          "sol": "R = √(30² + 40² + 0) = √(900 + 1600) = √2500 = 50 N",
          "ans": "50 N"
        }
      ],
      "mcqs": [
        {
          "q": "Self-Locking Machine (जैसे Screw Jack) की अधिकतम दक्षता (Efficiency) कितनी हो सकती है?",
          "opts": [
            "100%",
            "75%",
            "50% से कम (< 50%)",
            "66.67%"
          ],
          "ans": 2,
          "exp": "Self-Locking स्थिति (α ≤ φ) में मशीन की दक्षता सदैव 50% से कम होती है।"
        },
        {
          "q": "Lami's Theorem कितने बलों के संतुलन पर लागू होता है?",
          "opts": [
            "2 बल",
            "3 समतलीय संगामी बल (3 Coplanar Concurrent Forces)",
            "4 बल",
            "कितने भी बल"
          ],
          "ans": 1,
          "exp": "Lami's Theorem केवल 3 Coplanar Concurrent बलों के संतुलन के लिए लागू होता है।"
        }
      ]
    },
    {
      "id": "em_centroid_dynamics",
      "title": "Centroid, Moment of Inertia & Dynamics (केंद्रक, जड़त्व आघूर्ण व गति)",
      "subtitle": "Parallel & Perpendicular Axis Theorems • Projectile • Coefficient of Restitution",
      "diagram": "sfd_bmd",
      "def": "<b>Centroid (केंद्रक)</b> किसी समतल आकृति का ज्यामितीय केंद्र है। <b>Moment of Inertia (जड़त्व आघूर्ण I)</b> घूर्णन या बंकन के प्रति प्रतिरोध का माप है (इकाई: m⁴ या kg·m²)।",
      "points": [
        "<b>Parallel Axis Theorem:</b> <b>I_AB = I_G + A·h²</b> (किसी भी समानांतर अक्ष के परितः जड़त्व आघूर्ण)।",
        "<b>Perpendicular Axis Theorem:</b> <b>I_zz = I_xx + I_yy</b> (केवल समतल लैमिना के लिए)।",
        "<b>Projectile Motion:</b> अधिकतम क्षैतिज परास (Maximum Horizontal Range) प्रक्षेपण कोण <b>θ = 45°</b> पर मिलती है (R_max = u²/g)।",
        "<b>Collision & Coefficient of Restitution (e):</b> <b>e = (v₂ − v₁) / (u₁ − u₂)</b>। Perfectly Elastic के लिए <b>e = 1</b>, और Perfectly Plastic/Inelastic के लिए <b>e = 0</b>।",
        "<b>D'Alembert's Principle:</b> गतिशील पिंड पर विपरीत दिशा में Inertia Force (−m·a) लगाकर उसे स्थैतिक संतुलन में बदलना।"
      ],
      "examples": [
        "भाला फेंक (Javelin Throw) में खिलाड़ी अधिकतम दूरी के लिए भाले को <b>45° कोण</b> पर फेंकता है!"
      ],
      "formulas": [
        "Rectangle (b × d): I_xx = b d³ / 12  (Base के परितः = b d³ / 3)",
        "Triangle (Base b, Height h): Centroid = h / 3 (आधार से) | I_G = b h³ / 36 | I_base = b h³ / 12",
        "Circle (Dia d): I_xx = I_yy = π d⁴ / 64  |  Polar MOI J = π d⁴ / 32",
        "Projectile: Range R = (u² sin 2θ) / g  |  Max Height H = (u² sin²θ) / (2g)"
      ],
      "trick": "<b>MOI हर (Denominator) ट्रिक:</b> Rectangle = <b>12</b> (Base पर 3), Triangle = <b>36</b> (Base पर 12), Circle = <b>64</b> (Polar = 32) — सीधा रट लो, बहुत बार आता है!",
      "examFacts": [
        "अर्धवृत्त (Semicircle) का केंद्रक आधार से <b>4r / 3π</b> ऊँचाई पर होता है।",
        "<b>Impulse (आवेग) = Force × Time = Change in Momentum (m·v − m·u)</b>।",
        "किसी पिंड के <b>Centre of Gravity (CG)</b> से गुजरने वाले अक्ष के परितः Moment of Inertia हमेशा <b>न्यूनतम (Minimum)</b> होता है।"
      ],
      "table": {
        "headers": [
          "आकृति (Shape)",
          "Centroid (आधार से)",
          "MOI about Centroid (I_G)",
          "MOI about Base"
        ],
        "rows": [
          [
            "Rectangle (b × d)",
            "d / 2",
            "b d³ / 12",
            "b d³ / 3"
          ],
          [
            "Triangle (b × h)",
            "h / 3",
            "b h³ / 36",
            "b h³ / 12"
          ],
          [
            "Circle (Dia d)",
            "d / 2 (Center)",
            "π d⁴ / 64",
            "5π d⁴ / 64"
          ],
          [
            "Semicircle (Rad r)",
            "4r / (3π)",
            "0.11 r⁴",
            "π r⁴ / 8"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "त्रिभुज (आधार b, ऊँचाई h) का उसके केंद्रक (Centroid) के परितः Moment of Inertia कितना होता है?",
          "opts": [
            "bh³ / 12",
            "bh³ / 36",
            "bh³ / 3",
            "bh³ / 48"
          ],
          "ans": 1,
          "exp": "त्रिभुज का MOI केंद्रक के परितः bh³/36 और आधार के परितः bh³/12 होता है।"
        },
        {
          "q": "Perfectly Elastic Collision के लिए Coefficient of Restitution (e) का मान कितना होता है?",
          "opts": [
            "0",
            "0.5",
            "1",
            "अनंत"
          ],
          "ans": 2,
          "exp": "Perfectly Elastic के लिए e = 1 और Perfectly Plastic के लिए e = 0 होता है।"
        }
      ]
    }
  ]
},
{
  "id": "mp_gk_power",
  "name": "MP GK & Power Sector (मध्य प्रदेश GK व MPPGCL विशेष)",
  "icon": "⚡",
  "category": "nontech",
  "weight": "High Non-Tech (10–12 Marks)",
  "topics": [
    {
      "id": "gk_mppgcl_plants",
      "title": "MPPGCL Profile, Thermal & Hydro Power Plants of MP (सबसे महत्वपूर्ण)",
      "subtitle": "Headquarters • Satpura, Singaji, Sanjay Gandhi, Amarkantak • Hydro Plants",
      "diagram": "mp_power_map",
      "def": "<b>MPPGCL (Madhya Pradesh Power Generating Company Limited)</b> मध्य प्रदेश सरकार की प्रमुख विद्युत उत्पादन कंपनी है, जिसकी स्थापना <b>MPSEB के पुनर्गठन</b> के तहत हुई और इसका मुख्यालय <b>शक्ति भवन, रामपुर, जबलपुर</b> में स्थित है।",
      "points": [
        "<b>1. श्री सिंगाजी ताप विद्युत परियोजना (SSTPP):</b> स्थान — <b>दोंगलिया (मूँदी), जिला खंडवा</b> (इंदिरा सागर जलाशय से पानी)। यह MPPGCL का <b>सबसे बड़ा और आधुनिक (Supercritical 660 MW यूनिट्स सहित)</b> थर्मल प्लांट है (कुल क्षमता ~2520 MW)।",
        "<b>2. सतपुड़ा ताप विद्युत गृह (STPS):</b> स्थान — <b>सारनी, जिला बैतूल</b> (तवा नदी / सतपुड़ा डैम, पाथाखेड़ा कोयला क्षेत्र)। स्थापना 1967 (USA के सहयोग से)।",
        "<b>3. संजय गांधी ताप विद्युत गृह (SGTPS):</b> स्थान — <b>बिरसिंहपुर, जिला उमरिया</b> (जोहिला नदी)। क्षमता ~1340 MW।",
        "<b>4. अमरकंटक ताप विद्युत गृह (ATPS):</b> स्थान — <b>चचाई, जिला अनूपपुर</b> (सोन नदी, सोहागपुर कोयला क्षेत्र)। स्थापना 1965।",
        "<b>MP के प्रमुख जल विद्युत (Hydro) संयंत्र:</b> <b>गांधी सागर</b> (मंदसौर, चंबल नदी — MP का पहला जल विद्युत केंद्र, 1960), <b>बाणसागर टोंस</b> (रीवा/सिरमौर, सोन नदी), <b>पेंच</b> (छिंदवाड़ा/सिवनी), <b>बरगी / रानी अवंतीबाई</b> (जबलपुर, नर्मदा), <b>इंदिरा सागर</b> (खंडवा, नर्मदा — 1000 MW), <b>ओंकारेश्वर</b> (खंडवा, नर्मदा)।"
      ],
      "examples": [
        "<b>विंध्याचल सुपर थर्मल पावर स्टेशन (सिंगरौली — 4760 MW)</b> भारत का सबसे बड़ा थर्मल पावर प्लांट है — ध्यान दें कि यह <b>NTPC</b> का है (MPPGCL का नहीं), और सिंगरौली को <b>'मध्य प्रदेश की ऊर्जा राजधानी'</b> कहा जाता है!"
      ],
      "formulas": [
        "MPPGCL मुख्यालय: शक्ति भवन, जबलपुर (Jabalpur)",
        "MP की ऊर्जा राजधानी (Energy Capital): सिंगरौली (बैढ़न)",
        "MP की 3 वितरण कंपनियाँ (DISCOMs): पूर्व (जबलपुर), मध्य (भोपाल), पश्चिम (इंदौर)"
      ],
      "trick": "<b>MPPGCL के 4 थर्मल प्लांट्स याद रखने की ट्रिक — 'सिं-खं, स-बै, सं-उ, अ-अ':</b><br/>• <b>सिं</b>गाजी = <b>खं</b>डवा | <b>स</b>तपुड़ा = सारनी (<b>बै</b>तूल)<br/>• <b>सं</b>जय गांधी = बिरसिंहपुर (<b>उ</b>मरिया) | <b>अ</b>मरकंटक = चचाई (<b>अ</b>नूपपुर)!",
      "examFacts": [
        "<b>रीवा अल्ट्रा मेगा सोलर पार्क (गुढ़ तहसील, रीवा — 750 MW)</b> एशिया के सबसे बड़े सिंगल-साइट सोलर पार्कों में से एक है, जिससे दिल्ली मेट्रो को भी बिजली मिलती है।",
        "<b>ओंकारेश्वर फ्लोटिंग सोलर प्लांट (खंडवा)</b> नर्मदा नदी के ओंकारेश्वर बाँध पर बना भारत के सबसे बड़े तैरते सौर ऊर्जा संयंत्रों में से एक है।",
        "MP का पहला ताप विद्युत गृह <b>चाँदनी ताप विद्युत गृह (नेपानगर, बुरहानपुर — 1953)</b> था (नेपानगर अख़बारी कागज़ मिल के लिए)।"
      ],
      "table": {
        "headers": [
          "MPPGCL पावर प्लांट",
          "स्थान व जिला",
          "जल स्रोत / नदी",
          "प्रकार"
        ],
        "rows": [
          [
            "श्री सिंगाजी (SSTPP)",
            "दोंगलिया, खंडवा",
            "इंदिरा सागर (नर्मदा)",
            "Thermal (Supercritical)"
          ],
          [
            "सतपुड़ा (STPS)",
            "सारनी, बैतूल",
            "तवा / सतपुड़ा जलाशय",
            "Thermal"
          ],
          [
            "संजय गांधी (SGTPS)",
            "बिरसिंहपुर, उमरिया",
            "जोहिला नदी",
            "Thermal"
          ],
          [
            "अमरकंटक (ATPS)",
            "चचाई, अनूपपुर",
            "सोन नदी",
            "Thermal"
          ],
          [
            "गांधी सागर व बाणसागर",
            "मंदसौर / रीवा-शहडोल",
            "चंबल / सोन नदी",
            "Hydroelectric"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "MPPGCL (मध्य प्रदेश पावर जनरेटिंग कंपनी लिमिटेड) का मुख्यालय कहाँ स्थित है?",
          "opts": [
            "भोपाल",
            "इंदौर",
            "जबलपुर (शक्ति भवन)",
            "सिंगरौली"
          ],
          "ans": 2,
          "exp": "MPPGCL का मुख्यालय शक्ति भवन, रामपुर, जबलपुर में स्थित है।"
        },
        {
          "q": "श्री सिंगाजी ताप विद्युत परियोजना (SSTPP) मध्य प्रदेश के किस जिले में स्थित है?",
          "opts": [
            "बैतूल",
            "उमरिया",
            "खंडवा",
            "अनूपपुर"
          ],
          "ans": 2,
          "exp": "श्री सिंगाजी थर्मल पावर प्लांट दोंगलिया (मूँदी), जिला खंडवा में स्थित है।"
        },
        {
          "q": "मध्य प्रदेश की 'ऊर्जा राजधानी' (Energy Capital of MP) किसे कहा जाता है?",
          "opts": [
            "जबलपुर",
            "सिंगरौली",
            "खंडवा",
            "भोपाल"
          ],
          "ans": 1,
          "exp": "कोयला भंडार और विशाल बिजली संयंत्रों के कारण सिंगरौली (बैढ़न) को MP की ऊर्जा राजधानी कहते हैं।"
        }
      ]
    },
    {
      "id": "gk_mp_general",
      "title": "Madhya Pradesh Geography, Rivers, National Parks & Facts (MP सामान्य ज्ञान)",
      "subtitle": "State Symbols • Major Rivers • Tiger Reserves • UNESCO Sites",
      "diagram": "mp_power_map",
      "def": "मध्य प्रदेश (स्थापना: <b>1 नवंबर 1956</b>, पुनर्गठन: 1 नवंबर 2000) भारत का क्षेत्रफल की दृष्टि से <b>दूसरा सबसे बड़ा राज्य</b> (3,08,252 वर्ग किमी) है। इसे 'हृदय प्रदेश', 'टाइगर स्टेट' और 'नदियों का मायका' कहा जाता है।",
      "points": [
        "<b>राजकीय प्रतीक:</b> पशु = <b>बारहसिंगा (ब्रेडरी प्रजाति)</b>, पक्षी = <b>दूधराज (शाहबुलबुल)</b>, वृक्ष = <b>बरगद</b>, पुष्प = <b>सफ़ेद लिली</b>, खेल = <b>मलखंब</b>, मछली = <b>महाशीर</b>, नृत्य = <b>राई</b>।",
        "<b>प्रमुख नदियाँ:</b> <b>नर्मदा</b> (अमरकंटक से खंभात की खाड़ी, कुल 1312 km, MP में 1077 km — पश्चिम की ओर बहने वाली), <b>चंबल</b> (जानापाव पहाड़ी, इंदौर), <b>सोन</b> (अमरकंटक), <b>बेतवा</b> (कुमरा गाँव, रायसेन — 'MP की गंगा'), <b>ताप्ती</b> (मुलताई, बैतूल)।",
        "<b>प्रमुख राष्ट्रीय उद्यान:</b> <b>कान्हा किसली</b> (मंडला — MP का पहला व सबसे बड़ा), <b>बांधवगढ़</b> (उमरिया — सर्वाधिक बाघ घनत्व), <b>पन्ना</b> (पन्ना/छतरपुर — हीरा व केन नदी), <b>कूनो</b> (श्योपुर — चीता प्रोजेक्ट), <b>पेंच, सतपुड़ा, माधव, संजय</b>।",
        "<b>3 UNESCO विश्व धरोहर स्थल:</b> 1) <b>खजुराहो के मंदिर</b> (छतरपुर, 1986), 2) <b>साँची का स्तूप</b> (रायसेन, 1989), 3) <b>भीमबेटका की गुफाएँ</b> (रायसेन, 2003)।",
        "<b>सर्वोच्च चोटी:</b> <b>धूपगढ़ (1350 m)</b> — महादेव पहाड़ी, पचमढ़ी (नर्मदापुरम)।"
      ],
      "examples": [
        "<b>रीवा</b> को 'सफ़ेद शेरों की भूमि' कहा जाता है और <b>चचाई जलप्रपात (बीहड़ नदी)</b> व <b>बहुती जलप्रपात</b> रीवा/मऊगंज क्षेत्र के प्रसिद्ध जलप्रपात हैं।"
      ],
      "formulas": [
        "MP विधानसभा सीटें: 230  |  लोकसभा: 29  |  राज्यसभा: 11",
        "कर्क रेखा (Tropic of Cancer): MP के 14 जिलों से गुज़रती है",
        "MP का सबसे बड़ा जलप्रपात: बहुती (सेलर नदी) / चचाई (बीहड़ नदी)"
      ],
      "trick": "<b>MP के 3 UNESCO स्थलों की ट्रिक — 'ख-साँ-भी (86-89-03)':</b> <b>ख</b>जुराहो (1986) → <b>साँ</b>ची (1989) → <b>भी</b>मबेटका (2003)! <br/><b>पश्चिम बहने वाली नदियाँ — 'नमस्ते (न-म-त)':</b> <b>न</b>र्मदा, <b>म</b>ाही, <b>त</b>ाप्ती (तीनों अरब सागर में गिरती हैं)!",
      "examFacts": [
        "<b>माही नदी</b> कर्क रेखा (Tropic of Cancer) को दो बार काटती है।",
        "<b>पन्ना</b> भारत का एकमात्र प्रमुख हीरा (Diamond) उत्पादक जिला है, और <b>मलाजखंड (बालाघाट)</b> ताँबे (Copper) के लिए प्रसिद्ध है।",
        "MP का उच्च न्यायालय (High Court) <b>जबलपुर</b> में है (खंडपीठ: इंदौर और ग्वालियर)।"
      ],
      "table": {
        "headers": [
          "तथ्य (MP GK)",
          "सही उत्तर"
        ],
        "rows": [
          [
            "MP की सबसे ऊँची चोटी",
            "धूपगढ़ (1350 मीटर, पचमढ़ी)"
          ],
          [
            "सर्वाधिक बाघ घनत्व वाला पार्क",
            "बांधवगढ़ राष्ट्रीय उद्यान (उमरिया)"
          ],
          [
            "धुआँधार जलप्रपात",
            "भेड़ाघाट, जबलपुर (नर्मदा नदी)"
          ],
          [
            "पहला राष्ट्रीय उद्यान",
            "कान्हा किसली (1955, मंडला)"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "मध्य प्रदेश की सबसे ऊँची चोटी 'धूपगढ़' कहाँ स्थित है?",
          "opts": [
            "विंध्याचल श्रेणी",
            "महादेव पहाड़ी (सतपुड़ा, पचमढ़ी)",
            "अमरकंटक",
            "मालवा पठार"
          ],
          "ans": 1,
          "exp": "धूपगढ़ (1350 मीटर) सतपुड़ा पर्वतमाला की महादेव श्रेणी (पचमढ़ी, नर्मदापुरम) में स्थित है।"
        },
        {
          "q": "निम्न में से कौन-सी नदी कर्क रेखा (Tropic of Cancer) को दो बार काटती है?",
          "opts": [
            "नर्मदा",
            "चंबल",
            "माही",
            "बेतवा"
          ],
          "ans": 2,
          "exp": "धार जिले से निकलने वाली माही नदी कर्क रेखा को दो बार काटती है।"
        }
      ]
    },
    {
      "id": "gk_indian_power",
      "title": "Indian Power Sector, Renewable Energy & Basic Science (ऊर्जा व विज्ञान)",
      "subtitle": "NTPC, BHEL, PGCIL • SI Units • Indian Electricity Grid Frequency",
      "def": "MPPGCL की Non-Tech परीक्षा में भारतीय ऊर्जा क्षेत्र (Power Sector Institutions), नवीकरणीय ऊर्जा (Solar/Wind) और रोज़मर्रा के सामान्य विज्ञान (Physics/Chemistry Units) से 3–5 सीधे प्रश्न आते हैं।",
      "points": [
        "<b>भारतीय बिजली ग्रिड की मानक आवृत्ति (Frequency):</b> <b>50 Hz</b> (USA में 60 Hz)।",
        "<b>प्रमुख महारत्न ऊर्जा कंपनियाँ:</b> <b>NTPC</b> (सबसे बड़ी थर्मल उत्पादक, 1975), <b>PGCIL</b> (Power Grid — नेशनल ट्रांसमिशन), <b>BHEL</b> (भोपाल में बड़ा प्लांट — टरबाइन/जनरेटर निर्माण), <b>NHPC</b> (हाइड्रो), <b>NPCIL</b> (परमाणु)।",
        "<b>भारत में बिजली उत्पादन का सबसे बड़ा स्रोत:</b> कोयला आधारित <b>Thermal Power (~50%+)</b>, उसके बाद तेजी से बढ़ती Solar व Wind (Renewable) ऊर्जा।",
        "<b>Electricity Act 2003:</b> इसी अधिनियम के तहत राज्य बिजली बोर्डों को Generation (MPPGCL), Transmission (MPPTCL) और Distribution (DISCOMs) में बाँटा गया।"
      ],
      "examples": [
        "हमारे घरों में आने वाली सिंगल-फ़ेज़ बिजली <b>230 V, 50 Hz AC</b> होती है, और बिजली बिल की <b>1 Unit = 1 kWh = 3.6 × 10⁶ Joules</b> होती है!"
      ],
      "formulas": [
        "1 Unit of Electricity = 1 kWh = 3.6 MJ = 3.6 × 10⁶ Joules",
        "1 Horsepower (Metric HP) = 735.5 Watts  |  1 British HP = 746 Watts",
        "Ohm's Law: V = I · R  |  Electrical Power: P = V · I = I²R = V²/R"
      ],
      "trick": "<b>बिजली इकाइयों की ट्रिक:</b> <b>1 kWh = 3.6 MJ</b> | <b>1 Metric HP = 735.5 W</b> (Mechanical में ज़्यादा पूछते हैं!) | <b>Indian Grid = 50 Hz</b>!",
      "examFacts": [
        "<b>BHEL (भारत हेवी इलेक्ट्रिकल्स लिमिटेड)</b> की भोपाल इकाई की स्थापना ब्रिटेन के सहयोग से हुई थी।",
        "<b>CERC</b> (केंद्रीय विद्युत नियामक आयोग) और <b>MPERC</b> (मध्य प्रदेश विद्युत नियामक आयोग) बिजली की दरें (Tariff) तय करते हैं।",
        "<b>Solar Cell (Photovoltaic)</b> में मुख्यतः <b>Silicon (सिलिकॉन)</b> अर्धचालक का उपयोग होता है।"
      ],
      "table": {
        "headers": [
          "भौतिक राशि (Quantity)",
          "SI इकाई (SI Unit)",
          "मापन यंत्र (Instrument)"
        ],
        "rows": [
          [
            "Pressure (दाब)",
            "Pascal (N/m²)",
            "Manometer / Bourdon Gauge"
          ],
          [
            "Power (शक्ति)",
            "Watt (J/s)",
            "Wattmeter / Dynamometer"
          ],
          [
            "Viscosity (श्यानता)",
            "Pa·s (N·s/m²)",
            "Viscometer (Redwood/Saybolt)"
          ],
          [
            "High Temperature (>1000°C)",
            "Kelvin (K)",
            "Optical / Radiation Pyrometer"
          ]
        ]
      },
      "mcqs": [
        {
          "q": "1 यूनिट बिजली (1 kWh) कितने जूल (Joules) ऊर्जा के बराबर होती है?",
          "opts": [
            "3.6 × 10³ J",
            "3.6 × 10⁵ J",
            "3.6 × 10⁶ J",
            "1000 J"
          ],
          "ans": 2,
          "exp": "1 kWh = 1000 W × 3600 s = 3,600,000 J = 3.6 × 10⁶ J (3.6 MJ)।"
        },
        {
          "q": "भट्ठी (Furnace) का अत्यंत उच्च तापमान (> 1000°C) मापने के लिए किस यंत्र का उपयोग होता है?",
          "opts": [
            "Mercury Thermometer",
            "Pyrometer",
            "Barometer",
            "Hygrometer"
          ],
          "ans": 1,
          "exp": "अत्यधिक उच्च तापमान (जहाँ थर्मामीटर पिघल जाए) बिना संपर्क के Radiation/Optical Pyrometer से मापा जाता है।"
        }
      ]
    }
  ]
},
{
  "id": "reasoning_aptitude",
  "name": "Reasoning & Aptitude (तर्कशक्ति एवं अंकगणित — Non-Tech)",
  "icon": "🧠",
  "category": "nontech",
  "weight": "High Non-Tech (13–15 Marks)",
  "topics": [
    {
      "id": "ra_reasoning_core",
      "title": "Number Series, Coding-Decoding, Blood Relation & Direction",
      "subtitle": "EJOTY Trick • Opposite Letters • Pythagoras Direction Shortcut",
      "def": "MPPGCL JE के 25 अंक के Non-Tech भाग में <b>Reasoning</b> सबसे अधिक स्कोरिंग (लगभग 100% सटीक हल होने वाला) सेक्शन है। सही ट्रिक्स से ये प्रश्न 20–30 सेकंड में हल हो जाते हैं।",
      "points": [
        "<b>Number Series के 5 मुख्य पैटर्न:</b> 1) Difference / Double Difference, 2) Square/Cube (±1, ±n), 3) Prime Numbers (2,3,5,7,11,13,17,19,23), 4) Multiply + Add (×2+1, ×3−2), 5) Alternate Series।",
        "<b>Coding-Decoding (EJOTY नियम):</b> E=5, J=10, O=15, T=20, Y=25। किसी भी अक्षर का उल्टा (Opposite) निकालने के लिए <b>27 में से घटाएँ</b> (जैसे A=1 ⇒ 27−1 = 26 = Z)।",
        "<b>Direction Sense (दिशा ज्ञान):</b> ऊपर North, नीचे South, दाएँ East, बाएँ West। <b>1 Right Turn = +90° Clockwise</b>, <b>1 Left Turn = −90° Anti-clockwise</b>। एक Left और एक Right आपस में कट जाते हैं!",
        "<b>Blood Relations:</b> पीढ़ी का पेड़ (Family Tree) बनाएँ: Male (+), Female (−), विवाहित जोड़ा (⇔), भाई-बहन (—)।"
      ],
      "examples": [
        "यदि कोई व्यक्ति North की ओर मुँह करके पहले 1 बार Right और फिर 1 बार Left मुड़ता है, तो दोनों कट जाएँगे और उसका मुँह अभी भी <b>North</b> की ओर ही रहेगा!"
      ],
      "formulas": [
        "Opposite Letter Position = 27 − Original Position",
        "Shortest Distance (Pythagoras): d = √(x² + y²)  [Triplets रट लो: (3,4,5), (5,12,13), (6,8,10), (8,15,17)]",
        "1 से 25 तक के वर्ग (Squares) और 1 से 12 तक के घन (Cubes) हमेशा याद रखें"
      ],
      "trick": "<b>Opposite Letters की मज़ेदार ट्रिक:</b> <b>A-Z</b> (Aaj), <b>B-Y</b> (Boy), <b>C-X</b> (Six), <b>D-W</b> (Doodh-Wala), <b>E-V</b> (Evening), <b>F-U</b> (Full), <b>G-T</b> (GT Road), <b>H-S</b> (High School), <b>I-R</b> (Indian Railway), <b>J-Q</b> (Jungle Queen), <b>K-P</b> (Kanpur), <b>L-O</b> (Love), <b>M-N</b> (Man)!",
      "examFacts": [
        "Number Series में जब संख्याएँ अचानक बहुत तेज़ी से बढ़ें, तो हमेशा <b>गुणा (×) या वर्ग/घन</b> का पैटर्न जाँचें।",
        "यदि संख्याएँ धीरे-धीरे बढ़ें या घटें, तो सबसे पहले <b>अंतर (Difference)</b> निकालें।"
      ],
      "numericals": [
        {
          "q": "श्रृंखला में अगली संख्या ज्ञात करें: 2, 6, 12, 20, 30, ?",
          "given": "Series: 2, 6, 12, 20, 30, ?",
          "formula": "अंतर (Difference) या n² + n पैटर्न जाँचें",
          "sol": "अंतर: +4, +6, +8, +10 ⇒ अगला अंतर = +12.  इसलिए 30 + 12 = 42  (या 6² + 6 = 42)",
          "ans": "42"
        },
        {
          "q": "रवि अपने घर से 6 km उत्तर (North) जाता है, फिर दाएँ मुड़कर 8 km पूर्व (East) जाता है। वह घर से कितनी न्यूनतम दूरी पर है?",
          "given": "North = 6 km, East = 8 km (कोण = 90°)",
          "formula": "d = √(x² + y²)",
          "sol": "d = √(6² + 8²) = √(36 + 64) = √100 = 10 km (Triplet: 6, 8, 10)",
          "ans": "10 km (North-East दिशा)"
        }
      ],
      "mcqs": [
        {
          "q": "यदि किसी कोड में CAT को 24 लिखा जाता है, तो DOG को क्या लिखा जाएगा?",
          "opts": [
            "24",
            "26",
            "28",
            "30"
          ],
          "ans": 1,
          "exp": "C(3)+A(1)+T(20) = 24। इसी प्रकार D(4)+O(15)+G(7) = 26।"
        },
        {
          "q": "श्रृंखला पूरी करें: 3, 7, 15, 31, 63, ?",
          "opts": [
            "95",
            "125",
            "127",
            "129"
          ],
          "ans": 2,
          "exp": "पैटर्न है (×2 + 1): 63 × 2 + 1 = 126 + 1 = 127।"
        }
      ]
    },
    {
      "id": "ra_syllogism_clock",
      "title": "Syllogism, Ranking, Clock & Calendar (न्याय निगमन, घड़ी व कैलेंडर)",
      "subtitle": "Venn Diagram Rules • Clock Angle Formula • Odd Days Calendar Trick",
      "def": "<b>Syllogism (कथन-निष्कर्ष)</b> को Venn Diagram बनाकर बिना किसी अंदाज़े के 100% सही हल किया जाता है। घड़ी, रैंकिंग और कैलेंडर के प्रश्नों के लिए सीधे शॉर्टकट फ़ॉर्मूले लगते हैं।",
      "points": [
        "<b>Syllogism नियम:</b> केवल कथन (Statements) को ही 100% सत्य मानें। यदि कोई निष्कर्ष सभी संभावित Venn Diagrams में सही हो, तभी वह <b>Follows (सत्य)</b> होता है।",
        "<b>Ranking Formula:</b> यदि किसी व्यक्ति का स्थान बाएँ से L और दाएँ से R है, तो कुल व्यक्ति <b>Total = L + R − 1</b>।",
        "<b>Clock (घड़ी):</b> घंटे और मिनट की सुई के बीच का कोण <b>θ = |30H − 5.5M|</b>। 12 घंटे में दोनों सुइयाँ <b>11 बार 0° (मिलती हैं)</b>, <b>11 बार 180°</b> और <b>22 बार 90°</b> बनाती हैं।",
        "<b>Calendar (कैलेंडर):</b> सामान्य वर्ष (365 दिन) में <b>1 Odd Day</b> और लीप वर्ष (366 दिन, 4 से विभाज्य) में <b>2 Odd Days</b> होते हैं। शताब्दी वर्ष (1900, 2100) केवल <b>400 से विभाज्य</b> होने पर ही लीप वर्ष होते हैं।"
      ],
      "examples": [
        "यदि 1 जनवरी 2026 को गुरुवार है, तो सामान्य वर्ष होने के कारण 1 जनवरी 2027 को ठीक +1 दिन यानी <b>शुक्रवार</b> होगा!"
      ],
      "formulas": [
        "Ranking: Total = Left + Right − 1",
        "Clock Angle: θ = | 30·H − (11/2)·M |  (यदि θ > 180° आए, तो Reflex Angle घटाकर 360° − θ लें)",
        "Mirror Image of Clock: 11:60 (या 23:60) में से दिया समय घटाएँ",
        "Water Image of Clock: 18:30 (या 17:90) में से दिया समय घटाएँ"
      ],
      "trick": "<b>घड़ी के दर्पण प्रतिबिंब (Mirror Image) की 2-सेकंड ट्रिक:</b> दिए गए समय को सीधे <b>11:60</b> से घटा दो! (जैसे 3:20 का Mirror Image = 11:60 − 3:20 = <b>8:40</b>!)",
      "examFacts": [
        "24 घंटे (1 दिन) में घड़ी की दोनों सुइयाँ <b>22 बार</b> एक सीध में (0°) और <b>44 बार</b> समकोण (90°) बनाती हैं।",
        "100 वर्षों में <b>5 Odd Days</b>, 200 में <b>3</b>, 300 में <b>1</b>, और 400 वर्षों में <b>0 Odd Days</b> होते हैं।"
      ],
      "numericals": [
        {
          "q": "घड़ी में 4 बजकर 20 मिनट (4:20) पर घंटे और मिनट की सुई के बीच का कोण (Angle) ज्ञात करें।",
          "given": "H = 4, M = 20",
          "formula": "θ = | 30·H − 5.5·M |",
          "sol": "θ = | 30×4 − 5.5×20 | = | 120 − 110 | = 10°",
          "ans": "10°"
        },
        {
          "q": "एक पंक्ति में अमित बाएँ से 12वें और दाएँ से 19वें स्थान पर है। पंक्ति में कुल कितने छात्र हैं?",
          "given": "L = 12, R = 19",
          "formula": "Total = L + R − 1",
          "sol": "Total = 12 + 19 − 1 = 30 छात्र",
          "ans": "30 छात्र"
        }
      ],
      "mcqs": [
        {
          "q": "यदि घड़ी में 3:40 बजे हैं, तो दर्पण प्रतिबिंब (Mirror Image) में क्या समय दिखेगा?",
          "opts": [
            "8:20",
            "8:40",
            "9:20",
            "7:20"
          ],
          "ans": 0,
          "exp": "ट्रिक: 11:60 − 3:40 = 8:20।"
        },
        {
          "q": "निम्न में से कौन-सा वर्ष एक लीप वर्ष (Leap Year) नहीं है?",
          "opts": [
            "2000",
            "2024",
            "1900",
            "2400"
          ],
          "ans": 2,
          "exp": "शताब्दी वर्ष 400 से विभाज्य होना चाहिए; 1900, 400 से विभाज्य नहीं है इसलिए लीप वर्ष नहीं है।"
        }
      ]
    },
    {
      "id": "ra_percentage_ratio",
      "title": "Percentage, Profit-Loss, Ratio & SI/CI (प्रतिशत, लाभ-हानि व ब्याज)",
      "subtitle": "Fraction Table • Successive % Change • Dishonest Shopkeeper • CI-SI Diff",
      "def": "<b>Percentage (प्रतिशत)</b> और <b>Ratio (अनुपात)</b> पूरे अंकगणित की नींव हैं। प्रतिशत को भिन्न (Fraction) में बदलकर कठिन सवाल भी बिना कैलकुलेटर के 15 सेकंड में हल हो जाते हैं।",
      "points": [
        "<b>अति आवश्यक Fraction-Percentage टेबल:</b> 1/2 = 50%, 1/3 = 33.33%, 1/4 = 25%, 1/5 = 20%, 1/6 = 16.67%, 1/8 = 12.5%, 1/9 = 11.11%, 1/10 = 10%, 1/12 = 8.33%।",
        "<b>Profit & Loss:</b> लाभ या हानि की गणना हमेशा <b>Cost Price (CP — क्रय मूल्य)</b> पर, और छूट (Discount) की गणना हमेशा <b>Marked Price (MP — अंकित मूल्य)</b> पर की जाती है।",
        "<b>Successive % Change:</b> यदि किसी मान में पहले x% और फिर y% का परिवर्तन हो, तो कुल परिवर्तन = <b>x + y + (xy / 100)</b>।",
        "<b>Simple vs Compound Interest:</b> SI हर वर्ष बराबर रहता है; CI में ब्याज पर भी ब्याज लगता है।"
      ],
      "examples": [
        "यदि किसी वस्तु का मूल्य पहले 20% बढ़ाया जाए और फिर 20% घटाया जाए, तो कुल बदलाव 0% नहीं बल्कि −(20×20)/100 = <b>4% की हानि</b> होती है!"
      ],
      "formulas": [
        "Profit % = [(SP − CP) / CP] × 100  |  Discount % = [(MP − SP) / MP] × 100",
        "Successive % Change = x + y + (x·y / 100)",
        "Simple Interest: SI = (P · R · T) / 100",
        "Compound Interest Amount: A = P · (1 + R/100)^T",
        "2 वर्षों के CI और SI का अंतर (Shortcut!): CI − SI = P · (R / 100)²"
      ],
      "trick": "<b>खपत स्थिर रखने की ट्रिक:</b> यदि पेट्रोल का भाव <b>+x% (या +1/n)</b> बढ़े, तो खर्च समान रखने के लिए खपत को <b>1/(n+1)</b> घटाना होगा! (जैसे 25% = +1/4 बढ़े ⇒ खपत 1/5 = <b>20%</b> घटाओ!)",
      "examFacts": [
        "जब दो वस्तुएँ समान SP पर बेची जाएँ — एक पर x% लाभ व दूसरी पर x% हानि हो, तो हमेशा <b>कुल हानि = (x² / 100)%</b> होती है।",
        "2 साल के लिए CI − SI = P(R/100)² फ़ॉर्मूला हर एग्ज़ाम में समय बचाता है।"
      ],
      "numericals": [
        {
          "q": "₹5000 पर 10% वार्षिक दर से 2 वर्षों के चक्रवृद्धि ब्याज (CI) और साधारण ब्याज (SI) का अंतर निकालें।",
          "given": "P = ₹5000, R = 10%, T = 2 वर्ष",
          "formula": "CI − SI (2 वर्ष) = P × (R / 100)²",
          "sol": "अंतर = 5000 × (10 / 100)² = 5000 × (1/100) = ₹50",
          "ans": "₹50"
        },
        {
          "q": "एक दुकानदार ₹800 की वस्तु को ₹1000 में बेचता है। उसका लाभ प्रतिशत ज्ञात करें।",
          "given": "CP = ₹800, SP = ₹1000 ⇒ लाभ = ₹200",
          "formula": "Profit % = (Profit / CP) × 100",
          "sol": "Profit % = (200 / 800) × 100 = (1/4) × 100 = 25%",
          "ans": "25%"
        }
      ],
      "mcqs": [
        {
          "q": "यदि चीनी के मूल्य में 25% की वृद्धि हो जाए, तो गृहिणी को खपत कितने प्रतिशत कम करनी चाहिए ताकि खर्च न बढ़े?",
          "opts": [
            "25%",
            "20%",
            "16.67%",
            "15%"
          ],
          "ans": 1,
          "exp": "25% = +1/4 वृद्धि ⇒ कमी = 1/(4+1) = 1/5 = 20%।"
        },
        {
          "q": "₹10,000 पर 10% दर से 2 साल के CI और SI का अंतर कितना होगा?",
          "opts": [
            "₹50",
            "₹100",
            "₹200",
            "₹10"
          ],
          "ans": 1,
          "exp": "CI − SI = P(R/100)² = 10000 × (10/100)² = 10000 × 0.01 = ₹100।"
        }
      ]
    },
    {
      "id": "ra_time_work_speed",
      "title": "Time & Work, Pipes & Cisterns, Speed-Distance & Average",
      "subtitle": "LCM Efficiency Method • MDH Formula • Train Crossing • Average Speed",
      "def": "<b>Time & Work</b> और <b>Time-Speed-Distance</b> के सवाल MPPGCL के Non-Tech भाग में लगभग हर शिफ़्ट में पूछे जाते हैं। <b>LCM विधि</b> से कार्य-समय के कठिन सवाल बिना भिन्न के हल हो जाते हैं।",
      "points": [
        "<b>LCM Method (सबसे तेज़):</b> कुल कार्य (Total Work) = दिनों का LCM मानें। दक्षता (Efficiency) = Total Work ÷ दिन। समय = Total Work ÷ कुल दक्षता।",
        "<b>MDH Formula:</b> <b>(M₁ · D₁ · H₁) / W₁ = (M₂ · D₂ · H₂) / W₂</b> (जहाँ M=आदमी, D=दिन, H=घंटे, W=कार्य)।",
        "<b>Pipes & Cisterns:</b> भरने वाले नल की दक्षता <b>धनात्मक (+)</b> और खाली करने वाले नल/छेद की दक्षता <b>ऋणात्मक (−)</b> लेते हैं।",
        "<b>Unit Conversion (रट लो!):</b> <b>km/h से m/s</b> बनाने के लिए <b>× 5/18</b>, और <b>m/s से km/h</b> के लिए <b>× 18/5</b> करें।",
        "<b>Relative Speed:</b> विपरीत दिशा (Opposite) में चालें <b>जुड़ती हैं (S₁ + S₂)</b>; एक ही दिशा (Same) में चालें <b>घटती हैं (S₁ − S₂)</b>।"
      ],
      "examples": [
        "जब एक ट्रेन किसी खंभे या आदमी को पार करती है तो अपनी खुद की लंबाई (L) चलती है, और जब किसी पुल/प्लेटफ़ॉर्म को पार करती है तो <b>(L_train + L_platform)</b> चलती है!"
      ],
      "formulas": [
        "A और B मिलकर पूरा कार्य करेंगे = (A × B) / (A + B) दिन में",
        "Speed = Distance / Time  |  1 m/s = 18/5 km/h  |  1 km/h = 5/18 m/s",
        "समान दूरी के लिए Average Speed = (2 · x · y) / (x + y)",
        "Boat & Stream: Downstream = B + S  |  Upstream = B − S"
      ],
      "trick": "<b>5/18 vs 18/5 कभी नहीं भूलोगे:</b> छोटी इकाई (<b>m/s</b>) चाहिए तो <b>छोटा अंक 5 ऊपर (×5/18)</b>! बड़ी इकाई (<b>km/h</b>) चाहिए तो <b>बड़ा अंक 18 ऊपर (×18/5)</b>!",
      "examFacts": [
        "यदि दो समान दूरियाँ अलग-अलग चाल x और y से तय की जाएँ, तो औसत चाल (x+y)/2 <b>नहीं</b>, बल्कि <b>2xy/(x+y)</b> होती है!",
        "<b>Average (औसत)</b> = सभी प्रेक्षणों का योग ÷ कुल संख्या। क्रमागत संख्याओं (AP) का औसत हमेशा <b>(पहली + आखिरी) / 2</b> होता है।"
      ],
      "numericals": [
        {
          "q": "A किसी काम को 10 दिन में और B उसी काम को 15 दिन में कर सकता है। दोनों मिलकर वह काम कितने दिन में पूरा करेंगे?",
          "given": "A = 10 दिन, B = 15 दिन",
          "formula": "LCM Method: Total Work = LCM(10, 15) = 30 यूनिट",
          "sol": "A की दक्षता = 30/10 = 3/दिन, B की दक्षता = 30/15 = 2/दिन. कुल दक्षता = 3 + 2 = 5/दिन. समय = 30 / 5 = 6 दिन",
          "ans": "6 दिन"
        },
        {
          "q": "180 मीटर लंबी एक ट्रेन 72 km/h की चाल से चल रही है। यह एक बिजली के खंभे को कितने सेकंड में पार करेगी?",
          "given": "Distance = 180 m, Speed = 72 km/h = 72 × (5/18) = 20 m/s",
          "formula": "Time = Distance / Speed",
          "sol": "Time = 180 / 20 = 9 सेकंड",
          "ans": "9 सेकंड"
        }
      ],
      "mcqs": [
        {
          "q": "एक कार A से B तक 40 km/h से जाती है और B से A तक 60 km/h से लौटती है। पूरी यात्रा की औसत चाल (Average Speed) क्या है?",
          "opts": [
            "50 km/h",
            "48 km/h",
            "45 km/h",
            "52 km/h"
          ],
          "ans": 1,
          "exp": "समान दूरी के लिए Average Speed = 2xy/(x+y) = (2×40×60)/(40+60) = 4800/100 = 48 km/h।"
        },
        {
          "q": "एक नल टंकी को 6 घंटे में भरता है और दूसरा नल उसे 12 घंटे में खाली करता है। दोनों नल एक साथ खोलने पर टंकी कितने घंटे में भरेगी?",
          "opts": [
            "4 घंटे",
            "8 घंटे",
            "12 घंटे",
            "18 घंटे"
          ],
          "ans": 2,
          "exp": "LCM = 12 यूनिट। भरने की दक्षता = +2, खाली की = −1। नेट = +1/घंटा ⇒ समय = 12/1 = 12 घंटे।"
        }
      ]
    }
  ]
}
);
