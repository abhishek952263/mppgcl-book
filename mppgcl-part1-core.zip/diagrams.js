(function () {
  'use strict';

  const WRAP = (title, body) => `
    <div class="svg-diagram-box">
      <div class="svg-diagram-cap">📐 ${title}</div>
      <svg viewBox="0 0 360 195" xmlns="http://www.w3.org/2000/svg" class="eng-svg">
        <defs>
          <marker id="arr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1 L 10 5 L 0 9 z" fill="currentColor" />
          </marker>
        </defs>
        ${body}
      </svg>
    </div>`;

  const DIAGRAMS = {
    rankine: () => WRAP('Rankine Cycle: Schematic & T-s Diagram', `
      <!-- Left: 4-Component Loop -->
      <rect x="14" y="24" width="66" height="34" rx="6" fill="#fef3c7" stroke="#d97706" stroke-width="2"/>
      <text x="47" y="45" text-anchor="middle" font-size="11" font-weight="bold" fill="#92400e">BOILER</text>
      <polygon points="118,22 162,14 162,64 118,56" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <text x="140" y="43" text-anchor="middle" font-size="10" font-weight="bold" fill="#1e40af">TURBINE</text>
      <rect x="104" y="132" width="70" height="32" rx="6" fill="#e0f2fe" stroke="#0284c7" stroke-width="2"/>
      <text x="139" y="152" text-anchor="middle" font-size="10" font-weight="bold" fill="#075985">CONDENSER</text>
      <circle cx="47" cy="148" r="18" fill="#dcfce7" stroke="#16a34a" stroke-width="2"/>
      <text x="47" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#166534">PUMP</text>
      <g stroke="#334155" stroke-width="2" fill="none" marker-end="url(#arr)">
        <path d="M 80 40 L 114 40"/>
        <path d="M 140 62 L 140 128"/>
        <path d="M 104 148 L 69 148"/>
        <path d="M 47 130 L 47 62"/>
      </g>
      <text x="97" y="34" font-size="9" font-weight="bold" fill="#dc2626">1 (Steam)</text>
      <text x="146" y="98" font-size="9" font-weight="bold" fill="#2563eb">2 (Wt)</text>
      <text x="84" y="168" font-size="9" font-weight="bold" fill="#0284c7">3</text>
      <text x="20" y="98" font-size="9" font-weight="bold" fill="#16a34a">4 (Wp)</text>
      <!-- Right: T-s Diagram -->
      <line x1="205" y1="168" x2="345" y2="168" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <line x1="205" y1="168" x2="205" y2="20" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <text x="196" y="26" font-size="11" font-weight="bold" fill="currentColor">T</text>
      <text x="342" y="182" font-size="11" font-weight="bold" fill="currentColor">s</text>
      <path d="M 222 156 Q 272 28 326 156" fill="none" stroke="#94a3b8" stroke-width="1.5" stroke-dasharray="4 3"/>
      <path d="M 232 142 L 232 126 L 252 68 L 296 68 L 314 38 L 314 142 Z" fill="rgba(37,99,235,0.14)" stroke="#2563eb" stroke-width="2.2"/>
      <text x="318" y="38" font-size="10" font-weight="bold" fill="#dc2626">1</text>
      <text x="318" y="148" font-size="10" font-weight="bold" fill="#2563eb">2</text>
      <text x="220" y="148" font-size="10" font-weight="bold" fill="#16a34a">3</text>
      <text x="220" y="124" font-size="10" font-weight="bold" fill="#16a34a">4</text>
      <text x="274" y="114" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e40af">Wnet</text>
    `),

    boiler: () => WRAP('Fire-Tube vs Water-Tube Boiler (फ़ायर-ट्यूब बनाम वॉटर-ट्यूब)', `
      <!-- Fire Tube -->
      <rect x="16" y="24" width="148" height="140" rx="10" fill="#e0f2fe" stroke="#0284c7" stroke-width="2"/>
      <text x="90" y="42" text-anchor="middle" font-size="11" font-weight="bold" fill="#0369a1">FIRE-TUBE (Cochran)</text>
      <rect x="30" y="64" width="120" height="14" rx="4" fill="#fca5a5" stroke="#dc2626" stroke-width="1.5"/>
      <rect x="30" y="92" width="120" height="14" rx="4" fill="#fca5a5" stroke="#dc2626" stroke-width="1.5"/>
      <text x="90" y="74" text-anchor="middle" font-size="9" font-weight="bold" fill="#7f1d1d">Hot Flue Gas Inside →</text>
      <text x="90" y="102" text-anchor="middle" font-size="9" font-weight="bold" fill="#7f1d1d">Hot Flue Gas Inside →</text>
      <text x="90" y="132" text-anchor="middle" font-size="10" font-weight="bold" fill="#0c4a6e">Water Outside (Low P)</text>
      <text x="90" y="150" text-anchor="middle" font-size="9" fill="#475569">P &lt; 25 bar • Simple</text>
      <!-- Water Tube -->
      <rect x="196" y="24" width="148" height="140" rx="10" fill="#fee2e2" stroke="#dc2626" stroke-width="2"/>
      <text x="270" y="42" text-anchor="middle" font-size="11" font-weight="bold" fill="#991b1b">WATER-TUBE (Babcock)</text>
      <rect x="210" y="64" width="120" height="14" rx="4" fill="#93c5fd" stroke="#1d4ed8" stroke-width="1.5"/>
      <rect x="210" y="92" width="120" height="14" rx="4" fill="#93c5fd" stroke="#1d4ed8" stroke-width="1.5"/>
      <text x="270" y="74" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e3a8a">Water Inside Tubes →</text>
      <text x="270" y="102" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e3a8a">Water Inside Tubes →</text>
      <text x="270" y="132" text-anchor="middle" font-size="10" font-weight="bold" fill="#7f1d1d">Hot Gas Outside (High P)</text>
      <text x="270" y="150" text-anchor="middle" font-size="9" fill="#475569">P &gt; 100 bar • Power Plants</text>
    `),

    thermal_plant: () => WRAP('Thermal Power Plant — 4 Main Circuits (थर्मल पावर प्लांट)', `
      <rect x="14" y="20" width="76" height="36" rx="6" fill="#334155"/>
      <text x="52" y="36" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#fff">Coal Handling</text>
      <text x="52" y="49" text-anchor="middle" font-size="8.5" fill="#cbd5e1">Pulverizer</text>
      <rect x="116" y="18" width="90" height="44" rx="6" fill="#fef3c7" stroke="#d97706" stroke-width="2"/>
      <text x="161" y="36" text-anchor="middle" font-size="10" font-weight="bold" fill="#92400e">BOILER +</text>
      <text x="161" y="50" text-anchor="middle" font-size="9" font-weight="bold" fill="#b45309">Superheater</text>
      <rect x="234" y="20" width="54" height="40" rx="6" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <text x="261" y="43" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1e40af">Turbine</text>
      <circle cx="326" cy="40" r="20" fill="#dcfce7" stroke="#16a34a" stroke-width="2"/>
      <text x="326" y="44" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#166534">GEN</text>
      <rect x="218" y="114" width="84" height="34" rx="6" fill="#e0f2fe" stroke="#0284c7" stroke-width="2"/>
      <text x="260" y="135" text-anchor="middle" font-size="10" font-weight="bold" fill="#075985">Condenser</text>
      <rect x="112" y="114" width="78" height="34" rx="6" fill="#ede9fe" stroke="#7c3aed" stroke-width="2"/>
      <text x="151" y="135" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#5b21b6">Economizer</text>
      <rect x="14" y="114" width="74" height="34" rx="6" fill="#fee2e2" stroke="#dc2626" stroke-width="2"/>
      <text x="51" y="129" text-anchor="middle" font-size="9" font-weight="bold" fill="#991b1b">ESP +</text>
      <text x="51" y="141" text-anchor="middle" font-size="9" font-weight="bold" fill="#991b1b">Chimney</text>
      <g stroke="currentColor" stroke-width="1.8" fill="none" marker-end="url(#arr)">
        <path d="M 90 38 L 113 38"/>
        <path d="M 206 38 L 231 38"/>
        <path d="M 288 40 L 303 40"/>
        <path d="M 260 60 L 260 110"/>
        <path d="M 218 131 L 194 131"/>
        <path d="M 151 114 L 151 65"/>
        <path d="M 116 55 L 70 111"/>
      </g>
      <text x="180" y="176" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#0f766e">Flow: Boiler → Superheater → Turbine → Condenser → Pump → Economizer</text>
    `),

    turbine_impulse_reaction: () => WRAP('Impulse vs Reaction Turbine (Pressure & Velocity Curves)', `
      <!-- Impulse -->
      <text x="90" y="20" text-anchor="middle" font-size="11" font-weight="bold" fill="#1d4ed8">IMPULSE (De-Laval)</text>
      <rect x="34" y="30" width="38" height="44" fill="#fde68a" stroke="#d97706" stroke-width="1.6"/>
      <text x="53" y="55" text-anchor="middle" font-size="9" font-weight="bold" fill="#92400e">Nozzle</text>
      <rect x="86" y="30" width="42" height="44" fill="#bfdbfe" stroke="#2563eb" stroke-width="1.6"/>
      <text x="107" y="55" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e3a8a">Moving</text>
      <line x1="20" y1="168" x2="165" y2="168" stroke="currentColor" stroke-width="1.5"/>
      <path d="M 26 98 L 72 152 L 145 152" fill="none" stroke="#dc2626" stroke-width="2.2"/>
      <path d="M 26 152 L 72 95 L 136 146" fill="none" stroke="#2563eb" stroke-width="2.2" stroke-dasharray="4 2"/>
      <text x="148" y="155" font-size="9" font-weight="bold" fill="#dc2626">P=Const</text>
      <text x="76" y="92" font-size="9" font-weight="bold" fill="#2563eb">Vel↑</text>
      <!-- Reaction -->
      <text x="268" y="20" text-anchor="middle" font-size="11" font-weight="bold" fill="#059669">REACTION (Parsons R=0.5)</text>
      <rect x="210" y="30" width="38" height="44" fill="#d1fae5" stroke="#059669" stroke-width="1.6"/>
      <text x="229" y="55" text-anchor="middle" font-size="9" font-weight="bold" fill="#065f46">Fixed</text>
      <rect x="262" y="30" width="42" height="44" fill="#bfdbfe" stroke="#2563eb" stroke-width="1.6"/>
      <text x="283" y="55" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e3a8a">Moving</text>
      <line x1="196" y1="168" x2="345" y2="168" stroke="currentColor" stroke-width="1.5"/>
      <path d="M 202 96 L 252 126 L 325 158" fill="none" stroke="#dc2626" stroke-width="2.2"/>
      <path d="M 202 148 L 248 106 L 315 144" fill="none" stroke="#2563eb" stroke-width="2.2" stroke-dasharray="4 2"/>
      <text x="318" y="164" font-size="9" font-weight="bold" fill="#dc2626">P drops in both</text>
    `),

    condenser: () => WRAP('Surface Condenser & Cooling Tower Loop', `
      <rect x="26" y="36" width="136" height="96" rx="12" fill="#e0f2fe" stroke="#0284c7" stroke-width="2"/>
      <text x="94" y="56" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#0369a1">SURFACE CONDENSER</text>
      <line x1="36" y1="74" x2="152" y2="74" stroke="#1d4ed8" stroke-width="3"/>
      <line x1="36" y1="92" x2="152" y2="92" stroke="#1d4ed8" stroke-width="3"/>
      <line x1="36" y1="110" x2="152" y2="110" stroke="#1d4ed8" stroke-width="3"/>
      <text x="94" y="126" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#075985">Steam &amp; Water DO NOT MIX</text>
      <path d="M 94 12 L 94 33" stroke="#dc2626" stroke-width="2" marker-end="url(#arr)"/>
      <text x="102" y="24" font-size="9" font-weight="bold" fill="#dc2626">Exhaust Steam</text>
      <path d="M 94 132 L 94 166" stroke="#0284c7" stroke-width="2" marker-end="url(#arr)"/>
      <text x="102" y="158" font-size="9" font-weight="bold" fill="#0284c7">Pure Condensate → Boiler</text>
      <!-- Hyperbolic Cooling Tower -->
      <path d="M 244 150 Q 262 95 252 38 L 312 38 Q 302 95 320 150 Z" fill="#f1f5f9" stroke="#475569" stroke-width="2"/>
      <text x="282" y="96" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1e293b">COOLING</text>
      <text x="282" y="110" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1e293b">TOWER</text>
      <path d="M 162 74 L 248 74" stroke="#ef4444" stroke-width="2" marker-end="url(#arr)"/>
      <path d="M 248 110 L 165 110" stroke="#0284c7" stroke-width="2" marker-end="url(#arr)"/>
      <text x="204" y="68" text-anchor="middle" font-size="8.5" fill="#dc2626">Hot Water</text>
      <text x="204" y="123" text-anchor="middle" font-size="8.5" fill="#0284c7">Cold Water</text>
    `),

    thermo_laws: () => WRAP('Heat Engine, Refrigerator & Heat Pump (2nd Law)', `
      <!-- Heat Engine -->
      <rect x="20" y="16" width="84" height="24" rx="4" fill="#fee2e2" stroke="#dc2626"/>
      <text x="62" y="32" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#991b1b">Source (T1)</text>
      <circle cx="62" cy="86" r="22" fill="#fef3c7" stroke="#d97706" stroke-width="2"/>
      <text x="62" y="90" text-anchor="middle" font-size="10" font-weight="bold" fill="#92400e">HE</text>
      <rect x="20" y="136" width="84" height="24" rx="4" fill="#dbeafe" stroke="#2563eb"/>
      <text x="62" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1e40af">Sink (T2)</text>
      <g stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)">
        <line x1="62" y1="40" x2="62" y2="62"/>
        <line x1="62" y1="108" x2="62" y2="133"/>
        <line x1="84" y1="86" x2="118" y2="86"/>
      </g>
      <text x="104" y="80" font-size="9" font-weight="bold" fill="#16a34a">W</text>
      <text x="62" y="178" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1d4ed8">η = 1 - T2/T1</text>

      <!-- Refrigerator & Heat Pump -->
      <rect x="202" y="16" width="110" height="24" rx="4" fill="#fee2e2" stroke="#dc2626"/>
      <text x="257" y="32" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#991b1b">Hot Space (T1)</text>
      <circle cx="257" cy="86" r="24" fill="#dcfce7" stroke="#16a34a" stroke-width="2"/>
      <text x="257" y="89" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#166534">R / HP</text>
      <rect x="202" y="136" width="110" height="24" rx="4" fill="#dbeafe" stroke="#2563eb"/>
      <text x="257" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1e40af">Cold Space (T2)</text>
      <g stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)">
        <line x1="257" y1="136" x2="257" y2="113"/>
        <line x1="257" y1="62" x2="257" y2="43"/>
        <line x1="196" y1="86" x2="230" y2="86"/>
      </g>
      <text x="198" y="78" font-size="9" font-weight="bold" fill="#dc2626">W in</text>
      <text x="257" y="178" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#059669">(COP)HP = (COP)Ref + 1</text>
    `),

    carnot_otto_diesel: () => WRAP('P-V Diagrams: Otto (V=C) & Diesel (P=C) Cycles', `
      <!-- Otto Cycle -->
      <line x1="24" y1="158" x2="162" y2="158" stroke="currentColor" stroke-width="1.6" marker-end="url(#arr)"/>
      <line x1="24" y1="158" x2="24" y2="24" stroke="currentColor" stroke-width="1.6" marker-end="url(#arr)"/>
      <text x="15" y="30" font-size="10" font-weight="bold" fill="currentColor">P</text>
      <text x="158" y="172" font-size="10" font-weight="bold" fill="currentColor">V</text>
      <path d="M 52 95 L 52 40 Q 94 78 140 112 L 140 144 Q 90 132 52 95 Z" fill="rgba(37,99,235,0.16)" stroke="#2563eb" stroke-width="2"/>
      <text x="42" y="42" font-size="9.5" font-weight="bold" fill="#dc2626">3</text>
      <text x="42" y="98" font-size="9.5" font-weight="bold" fill="#2563eb">2</text>
      <text x="144" y="114" font-size="9.5" font-weight="bold" fill="#2563eb">4</text>
      <text x="144" y="148" font-size="9.5" font-weight="bold" fill="#2563eb">1</text>
      <text x="95" y="182" text-anchor="middle" font-size="10" font-weight="bold" fill="#1d4ed8">OTTO (Petrol • V=C)</text>

      <!-- Diesel Cycle -->
      <line x1="200" y1="158" x2="342" y2="158" stroke="currentColor" stroke-width="1.6" marker-end="url(#arr)"/>
      <line x1="200" y1="158" x2="200" y2="24" stroke="currentColor" stroke-width="1.6" marker-end="url(#arr)"/>
      <text x="191" y="30" font-size="10" font-weight="bold" fill="currentColor">P</text>
      <text x="338" y="172" font-size="10" font-weight="bold" fill="currentColor">V</text>
      <path d="M 228 54 L 268 54 Q 296 92 322 114 L 322 144 Q 268 130 228 54 Z" fill="rgba(16,185,129,0.16)" stroke="#059669" stroke-width="2"/>
      <text x="219" y="56" font-size="9.5" font-weight="bold" fill="#dc2626">2</text>
      <text x="272" y="52" font-size="9.5" font-weight="bold" fill="#dc2626">3 (P=C)</text>
      <text x="326" y="115" font-size="9.5" font-weight="bold" fill="#059669">4</text>
      <text x="326" y="148" font-size="9.5" font-weight="bold" fill="#059669">1</text>
      <text x="272" y="182" text-anchor="middle" font-size="10" font-weight="bold" fill="#059669">DIESEL (P=C Heat Add)</text>
    `),

    fluid_types: () => WRAP('Newtonian & Non-Newtonian Fluids (Rheology Curve)', `
      <line x1="48" y1="164" x2="334" y2="164" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <line x1="48" y1="164" x2="48" y2="18" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <text x="28" y="26" font-size="11" font-weight="bold" fill="currentColor">τ</text>
      <text x="308" y="180" font-size="10" font-weight="bold" fill="currentColor">du/dy</text>
      <!-- Bingham Plastic -->
      <line x1="48" y1="112" x2="210" y2="30" stroke="#7c3aed" stroke-width="2"/>
      <text x="214" y="33" font-size="9.5" font-weight="bold" fill="#7c3aed">Bingham (Toothpaste)</text>
      <!-- Pseudoplastic (n<1) -->
      <path d="M 48 164 Q 110 80 250 56" fill="none" stroke="#059669" stroke-width="2"/>
      <text x="254" y="60" font-size="9.5" font-weight="bold" fill="#059669">Pseudoplastic (Blood, n&lt;1)</text>
      <!-- Newtonian (n=1) -->
      <line x1="48" y1="164" x2="255" y2="86" stroke="#2563eb" stroke-width="2.4"/>
      <text x="258" y="90" font-size="9.5" font-weight="bold" fill="#2563eb">Newtonian (Water/Air)</text>
      <!-- Dilatant (n>1) -->
      <path d="M 48 164 Q 175 154 252 114" fill="none" stroke="#dc2626" stroke-width="2"/>
      <text x="256" y="118" font-size="9.5" font-weight="bold" fill="#dc2626">Dilatant (Quicksand, n&gt;1)</text>
      <text x="115" y="178" font-size="9" font-weight="bold" fill="#64748b">Ideal Fluid (μ = 0 on X-axis)</text>
    `),

    bernoulli: () => WRAP('Venturimeter & Bernoulli Energy Conservation', `
      <path d="M 24 44 L 100 44 L 154 74 L 194 74 L 274 44 L 336 44" fill="none" stroke="#1e293b" stroke-width="2.5"/>
      <path d="M 24 134 L 100 134 L 154 104 L 194 104 L 274 134 L 336 134" fill="none" stroke="#1e293b" stroke-width="2.5"/>
      <path d="M 24 46 L 100 46 L 154 76 L 194 76 L 274 46 L 336 46 L 336 132 L 274 132 L 194 102 L 154 102 L 100 132 L 24 132 Z" fill="rgba(14,165,233,0.18)"/>
      <!-- Piezometers -->
      <rect x="64" y="14" width="10" height="32" fill="#bae6fd" stroke="#0284c7" stroke-width="1.5"/>
      <rect x="168" y="34" width="10" height="42" fill="#bae6fd" stroke="#0284c7" stroke-width="1.5"/>
      <text x="69" y="11" text-anchor="middle" font-size="9" font-weight="bold" fill="#0369a1">P1 High</text>
      <text x="173" y="30" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">P2 Low, V2 Max</text>
      <text x="174" y="93" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#0c4a6e">THROAT</text>
      <text x="122" y="152" text-anchor="middle" font-size="9" fill="#475569">Converging (21°)</text>
      <text x="242" y="152" text-anchor="middle" font-size="9" fill="#475569">Diverging (5°-7°)</text>
      <text x="180" y="178" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#1d4ed8">P/ρg + V²/2g + Z = Constant (Energy Conservation)</text>
    `),

    pumps: () => WRAP('Centrifugal Pump (Volute Casing & Impeller)', `
      <circle cx="145" cy="96" r="56" fill="#e0f2fe" stroke="#0284c7" stroke-width="2.5"/>
      <circle cx="145" cy="96" r="36" fill="#bfdbfe" stroke="#1d4ed8" stroke-width="2"/>
      <circle cx="145" cy="96" r="11" fill="#1e3a8a"/>
      <!-- Curved Backward Vanes -->
      <path d="M 145 85 Q 162 72 175 84" fill="none" stroke="#1e3a8a" stroke-width="2.2"/>
      <path d="M 156 96 Q 168 112 156 126" fill="none" stroke="#1e3a8a" stroke-width="2.2"/>
      <path d="M 145 107 Q 128 120 115 108" fill="none" stroke="#1e3a8a" stroke-width="2.2"/>
      <path d="M 134 96 Q 122 80 134 66" fill="none" stroke="#1e3a8a" stroke-width="2.2"/>
      <!-- Delivery Pipe -->
      <rect x="188" y="20" width="22" height="62" fill="#bae6fd" stroke="#0284c7" stroke-width="2"/>
      <path d="M 199 66 L 199 26" stroke="#dc2626" stroke-width="2" marker-end="url(#arr)"/>
      <text x="266" y="42" font-size="10" font-weight="bold" fill="#dc2626">Delivery Pipe (High P)</text>
      <text x="266" y="72" font-size="9.5" font-weight="bold" fill="#1e40af">• Volute Casing: KE → PE</text>
      <text x="266" y="92" font-size="9.5" font-weight="bold" fill="#059669">• Priming Required!</text>
      <text x="266" y="112" font-size="9.5" font-weight="bold" fill="#b45309">• Cavitation at Suction</text>
      <text x="266" y="132" font-size="9.5" font-weight="bold" fill="#7c3aed">• NPSH &gt; NPSH(req)</text>
      <text x="72" y="174" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#0369a1">Eye (Suction Side)</text>
    `),

    hydro_turbines: () => WRAP('Hydraulic Turbines: Pelton, Francis & Kaplan', `
      <rect x="12" y="22" width="104" height="148" rx="8" fill="#fef3c7" stroke="#d97706" stroke-width="1.8"/>
      <text x="64" y="40" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#92400e">PELTON</text>
      <circle cx="64" cy="80" r="22" fill="#fde68a" stroke="#b45309" stroke-width="2"/>
      <line x1="20" y1="102" x2="62" y2="102" stroke="#0284c7" stroke-width="3" marker-end="url(#arr)"/>
      <text x="64" y="124" text-anchor="middle" font-size="9" font-weight="bold" fill="#78350f">Impulse • Tangential</text>
      <text x="64" y="139" text-anchor="middle" font-size="9" fill="#92400e">High Head (&gt;250m)</text>
      <text x="64" y="155" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">Ns: 10 – 60</text>

      <rect x="128" y="22" width="104" height="148" rx="8" fill="#dbeafe" stroke="#2563eb" stroke-width="1.8"/>
      <text x="180" y="40" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#1e40af">FRANCIS</text>
      <circle cx="180" cy="80" r="22" fill="#93c5fd" stroke="#1d4ed8" stroke-width="2"/>
      <circle cx="180" cy="80" r="10" fill="#fff" stroke="#1d4ed8"/>
      <text x="180" y="124" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e3a8a">Reaction • Mixed Flow</text>
      <text x="180" y="139" text-anchor="middle" font-size="9" fill="#1e40af">Medium Head (60-250m)</text>
      <text x="180" y="155" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">Ns: 60 – 300</text>

      <rect x="244" y="22" width="104" height="148" rx="8" fill="#dcfce7" stroke="#16a34a" stroke-width="1.8"/>
      <text x="296" y="40" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#166534">KAPLAN</text>
      <line x1="296" y1="54" x2="296" y2="104" stroke="#166534" stroke-width="4"/>
      <ellipse cx="280" cy="84" rx="14" ry="5" fill="#4ade80" stroke="#15803d"/>
      <ellipse cx="312" cy="84" rx="14" ry="5" fill="#4ade80" stroke="#15803d"/>
      <text x="296" y="124" text-anchor="middle" font-size="9" font-weight="bold" fill="#14532d">Reaction • Axial Flow</text>
      <text x="296" y="139" text-anchor="middle" font-size="9" fill="#166534">Low Head (&lt;60m)</text>
      <text x="296" y="155" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">Ns: 300 – 1000</text>
    `),

    stress_strain: () => WRAP('Mild Steel Stress-Strain Curve (माइल्ड स्टील वक्र)', `
      <line x1="40" y1="166" x2="338" y2="166" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <line x1="40" y1="166" x2="40" y2="18" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <text x="20" y="28" font-size="11" font-weight="bold" fill="currentColor">σ</text>
      <text x="322" y="182" font-size="11" font-weight="bold" fill="currentColor">ε</text>
      <path d="M 40 166 L 86 92 L 95 78 L 106 88 L 136 88 Q 198 30 242 40 Q 276 48 302 82" fill="none" stroke="#2563eb" stroke-width="2.6"/>
      <circle cx="86" cy="92" r="3.5" fill="#dc2626"/><text x="64" y="92" font-size="9" font-weight="bold" fill="#dc2626">A (Prop)</text>
      <circle cx="95" cy="78" r="3.5" fill="#d97706"/><text x="72" y="68" font-size="9" font-weight="bold" fill="#d97706">B/C (Yield)</text>
      <circle cx="136" cy="88" r="3.5" fill="#16a34a"/><text x="132" y="106" font-size="9" font-weight="bold" fill="#16a34a">D</text>
      <circle cx="242" cy="40" r="4" fill="#dc2626"/><text x="236" y="28" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#dc2626">E (Ultimate σu)</text>
      <circle cx="302" cy="82" r="4" fill="#7c3aed"/><text x="304" y="72" font-size="9" font-weight="bold" fill="#7c3aed">F (Fracture)</text>
      <text x="275" y="128" font-size="9" font-weight="bold" fill="#b45309">Necking Zone (E→F)</text>
      <text x="115" y="148" font-size="9" font-weight="bold" fill="#1d4ed8">Hooke's Law: O→A</text>
    `),

    sfd_bmd: () => WRAP('Simply Supported Beam (Point Load W at Center)', `
      <!-- Beam -->
      <line x1="44" y1="42" x2="316" y2="42" stroke="#1e293b" stroke-width="4"/>
      <polygon points="44,44 34,58 54,58" fill="#64748b"/>
      <polygon points="316,44 306,58 326,58" fill="#64748b"/>
      <line x1="180" y1="10" x2="180" y2="38" stroke="#dc2626" stroke-width="2.5" marker-end="url(#arr)"/>
      <text x="190" y="24" font-size="10.5" font-weight="bold" fill="#dc2626">W (Center)</text>
      <!-- SFD -->
      <text x="16" y="96" font-size="9.5" font-weight="bold" fill="#0284c7">SFD</text>
      <line x1="44" y1="95" x2="316" y2="95" stroke="#94a3b8" stroke-width="1.2"/>
      <rect x="44" y="72" width="136" height="23" fill="rgba(2,132,199,0.22)" stroke="#0284c7" stroke-width="1.8"/>
      <rect x="180" y="95" width="136" height="23" fill="rgba(220,38,38,0.2)" stroke="#dc2626" stroke-width="1.8"/>
      <text x="112" y="87" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#0369a1">+W/2</text>
      <text x="248" y="111" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#b91c1c">-W/2</text>
      <!-- BMD -->
      <text x="14" y="162" font-size="9.5" font-weight="bold" fill="#059669">BMD</text>
      <polygon points="44,174 180,132 316,174" fill="rgba(16,185,129,0.22)" stroke="#059669" stroke-width="2"/>
      <text x="180" y="164" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#065f46">Max BM = WL / 4</text>
    `),

    mohr_circle: () => WRAP("Mohr's Circle (Principal Stresses & Max Shear)", `
      <line x1="36" y1="110" x2="334" y2="110" stroke="currentColor" stroke-width="1.6" marker-end="url(#arr)"/>
      <line x1="76" y1="176" x2="76" y2="20" stroke="currentColor" stroke-width="1.6" marker-end="url(#arr)"/>
      <text x="326" y="126" font-size="10.5" font-weight="bold" fill="currentColor">σ</text>
      <text x="64" y="28" font-size="10.5" font-weight="bold" fill="currentColor">τ</text>
      <circle cx="196" cy="110" r="62" fill="rgba(37,99,235,0.12)" stroke="#2563eb" stroke-width="2.4"/>
      <circle cx="196" cy="110" r="3.5" fill="#1e293b"/>
      <line x1="196" y1="110" x2="196" y2="48" stroke="#dc2626" stroke-width="2" stroke-dasharray="4 2"/>
      <circle cx="134" cy="110" r="4" fill="#059669"/><text x="122" y="128" font-size="10" font-weight="bold" fill="#059669">σ2</text>
      <circle cx="258" cy="110" r="4" fill="#dc2626"/><text x="262" y="128" font-size="10" font-weight="bold" fill="#dc2626">σ1</text>
      <text x="202" y="76" font-size="10" font-weight="bold" fill="#dc2626">R = τmax = (σ1-σ2)/2</text>
      <text x="196" y="186" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1d4ed8">Center C = ((σx+σy)/2, 0) • Pure Shear: Center at Origin</text>
    `),

    columns: () => WRAP("Euler's Column End Conditions (Effective Length Le)", `
      <!-- 1. Both Hinged -->
      <line x1="54" y1="36" x2="54" y2="132" stroke="#2563eb" stroke-width="3.5"/>
      <circle cx="54" cy="36" r="5" fill="#fff" stroke="#2563eb" stroke-width="2"/>
      <circle cx="54" cy="132" r="5" fill="#fff" stroke="#2563eb" stroke-width="2"/>
      <text x="54" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="currentColor">Both Hinged</text>
      <text x="54" y="166" text-anchor="middle" font-size="10" font-weight="bold" fill="#1d4ed8">Le = L</text>
      <!-- 2. Fixed-Free -->
      <path d="M 138 132 Q 138 80 154 36" fill="none" stroke="#dc2626" stroke-width="3.5"/>
      <rect x="122" y="132" width="32" height="7" fill="#475569"/>
      <text x="138" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="currentColor">Fixed-Free</text>
      <text x="138" y="166" text-anchor="middle" font-size="10" font-weight="bold" fill="#dc2626">Le = 2L</text>
      <!-- 3. Fixed-Hinged -->
      <path d="M 222 132 Q 222 92 232 64 Q 228 45 222 36" fill="none" stroke="#d97706" stroke-width="3.5"/>
      <rect x="206" y="132" width="32" height="7" fill="#475569"/>
      <circle cx="222" cy="36" r="5" fill="#fff" stroke="#d97706" stroke-width="2"/>
      <text x="222" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="currentColor">Fixed-Hinged</text>
      <text x="222" y="166" text-anchor="middle" font-size="10" font-weight="bold" fill="#b45309">Le = L/√2</text>
      <!-- 4. Both Fixed -->
      <path d="M 306 132 C 306 100 318 100 318 84 C 318 68 306 68 306 36" fill="none" stroke="#059669" stroke-width="3.5"/>
      <rect x="290" y="132" width="32" height="7" fill="#475569"/>
      <rect x="290" y="29" width="32" height="7" fill="#475569"/>
      <text x="306" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="currentColor">Both Fixed</text>
      <text x="306" y="166" text-anchor="middle" font-size="10" font-weight="bold" fill="#059669">Le = L/2 (4×Strong)</text>
    `),

    grashof: () => WRAP("Four-Bar Linkage & Grashof's Law (s + l ≤ p + q)", `
      <!-- Fixed Frame -->
      <line x1="66" y1="142" x2="294" y2="142" stroke="#475569" stroke-width="5"/>
      <!-- Crank (shortest s) -->
      <line x1="80" y1="142" x2="112" y2="74" stroke="#dc2626" stroke-width="4.5"/>
      <!-- Coupler -->
      <line x1="112" y1="74" x2="246" y2="48" stroke="#2563eb" stroke-width="4.5"/>
      <!-- Rocker -->
      <line x1="246" y1="48" x2="280" y2="142" stroke="#059669" stroke-width="4.5"/>
      <!-- Joints -->
      <circle cx="80" cy="142" r="6" fill="#fff" stroke="#1e293b" stroke-width="2.5"/>
      <circle cx="112" cy="74" r="6" fill="#fff" stroke="#1e293b" stroke-width="2.5"/>
      <circle cx="246" cy="48" r="6" fill="#fff" stroke="#1e293b" stroke-width="2.5"/>
      <circle cx="280" cy="142" r="6" fill="#fff" stroke="#1e293b" stroke-width="2.5"/>
      <text x="72" y="102" font-size="10.5" font-weight="bold" fill="#dc2626">s (Crank)</text>
      <text x="176" y="48" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#2563eb">p (Coupler)</text>
      <text x="294" y="96" font-size="10.5" font-weight="bold" fill="#059669">q (Rocker)</text>
      <text x="180" y="164" text-anchor="middle" font-size="10.5" font-weight="bold" fill="#334155">l (Fixed Frame • 4 Links, 4 Turning Pairs)</text>
      <text x="180" y="182" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#b45309">s Fixed → Double Crank | Adjacent Fixed → Crank-Rocker | Opp Fixed → Double Rocker</text>
    `),

    flywheel_governor: () => WRAP('Flywheel (Turning Moment) vs Watt Governor', `
      <!-- Left: Flywheel T-theta -->
      <line x1="18" y1="145" x2="174" y2="145" stroke="currentColor" stroke-width="1.5"/>
      <line x1="18" y1="145" x2="18" y2="26" stroke="currentColor" stroke-width="1.5"/>
      <line x1="18" y1="88" x2="170" y2="88" stroke="#dc2626" stroke-width="1.5" stroke-dasharray="4 3"/>
      <path d="M 18 118 Q 56 34 94 88 T 168 88" fill="none" stroke="#2563eb" stroke-width="2.4"/>
      <text x="60" y="76" font-size="9.5" font-weight="bold" fill="#059669">+ΔE</text>
      <text x="128" y="114" font-size="9.5" font-weight="bold" fill="#dc2626">-ΔE</text>
      <text x="94" y="168" text-anchor="middle" font-size="10" font-weight="bold" fill="#1d4ed8">FLYWHEEL (In-Cycle)</text>
      <text x="94" y="182" text-anchor="middle" font-size="9" fill="#475569">ΔE = I ω² Cs</text>

      <!-- Right: Governor -->
      <line x1="274" y1="24" x2="274" y2="150" stroke="#334155" stroke-width="3.5"/>
      <line x1="274" y1="36" x2="232" y2="84" stroke="#2563eb" stroke-width="2.5"/>
      <line x1="274" y1="36" x2="316" y2="84" stroke="#2563eb" stroke-width="2.5"/>
      <line x1="232" y1="84" x2="274" y2="124" stroke="#059669" stroke-width="2"/>
      <line x1="316" y1="84" x2="274" y2="124" stroke="#059669" stroke-width="2"/>
      <circle cx="232" cy="84" r="10" fill="#f59e0b" stroke="#92400e" stroke-width="1.8"/>
      <circle cx="316" cy="84" r="10" fill="#f59e0b" stroke="#92400e" stroke-width="1.8"/>
      <rect x="262" y="116" width="24" height="16" rx="3" fill="#94a3b8" stroke="#1e293b"/>
      <text x="274" y="168" text-anchor="middle" font-size="10" font-weight="bold" fill="#059669">GOVERNOR (Load Control)</text>
      <text x="274" y="182" text-anchor="middle" font-size="9" fill="#475569">Watt: h = 895 / N² (m)</text>
    `),

    gears: () => WRAP('Spur Gear Tooth Nomenclature (गियर शब्दावली)', `
      <!-- Gear Tooth Profile -->
      <path d="M 32 146 L 96 146 L 112 52 Q 145 40 178 52 L 194 146 L 260 146" fill="rgba(37,99,235,0.14)" stroke="#1e293b" stroke-width="2.6"/>
      <!-- Pitch Circle Line -->
      <line x1="20" y1="92" x2="276" y2="92" stroke="#dc2626" stroke-width="1.8" stroke-dasharray="6 4"/>
      <!-- Addendum & Dedendum Lines -->
      <line x1="178" y1="47" x2="276" y2="47" stroke="#059669" stroke-width="1.4" stroke-dasharray="3 3"/>
      <line x1="194" y1="146" x2="276" y2="146" stroke="#7c3aed" stroke-width="1.4" stroke-dasharray="3 3"/>
      <text x="280" y="51" font-size="9.5" font-weight="bold" fill="#059669">Addendum (1m)</text>
      <text x="280" y="96" font-size="9.5" font-weight="bold" fill="#dc2626">Pitch Circle</text>
      <text x="280" y="150" font-size="9.5" font-weight="bold" fill="#7c3aed">Dedendum (1.25m)</text>
      <text x="145" y="76" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1d4ed8">Face</text>
      <text x="145" y="122" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#475569">Flank</text>
      <text x="180" y="178" text-anchor="middle" font-size="10" font-weight="bold" fill="#1e40af">Module m = D / T  |  Circular Pitch pc = π · m</text>
    `),

    belt_clutch: () => WRAP('Open Belt Drive (Tight/Slack Side) & Single Plate Clutch', `
      <!-- Belt Drive -->
      <circle cx="52" cy="86" r="24" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <circle cx="154" cy="86" r="36" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <line x1="52" y1="62" x2="154" y2="50" stroke="#475569" stroke-width="2.5"/>
      <line x1="52" y1="110" x2="154" y2="122" stroke="#dc2626" stroke-width="3"/>
      <text x="102" y="48" text-anchor="middle" font-size="9" font-weight="bold" fill="#475569">Slack Side (T2)</text>
      <text x="102" y="136" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">Tight Side (T1)</text>
      <text x="102" y="164" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1d4ed8">T1/T2 = e^(μθ)</text>
      <text x="102" y="178" text-anchor="middle" font-size="8.5" fill="#475569">Max Power: Tc = Tmax / 3</text>

      <!-- Clutch -->
      <rect x="228" y="42" width="14" height="90" fill="#64748b"/>
      <rect x="246" y="48" width="12" height="78" fill="#f59e0b" stroke="#92400e"/>
      <rect x="262" y="42" width="14" height="90" fill="#3b82f6"/>
      <line x1="204" y1="87" x2="228" y2="87" stroke="#1e293b" stroke-width="5"/>
      <line x1="276" y1="87" x2="316" y2="87" stroke="#1e293b" stroke-width="5"/>
      <text x="272" y="152" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#059669">Single Plate Clutch (n=2)</text>
      <text x="272" y="168" text-anchor="middle" font-size="9" fill="#475569">New → Uniform Pressure</text>
      <text x="272" y="182" text-anchor="middle" font-size="9" fill="#475569">Old → Uniform Wear</text>
    `),

    joints_springs: () => WRAP('Riveted Joint & Helical Compression Spring', `
      <!-- Lap Joint -->
      <rect x="20" y="54" width="110" height="22" fill="#cbd5e1" stroke="#334155" stroke-width="1.6"/>
      <rect x="66" y="76" width="110" height="22" fill="#e2e8f0" stroke="#334155" stroke-width="1.6"/>
      <rect x="92" y="48" width="14" height="56" rx="4" fill="#dc2626"/>
      <line x1="10" y1="65" x2="36" y2="65" stroke="#1d4ed8" stroke-width="2" marker-start="url(#arr)"/>
      <line x1="164" y1="87" x2="188" y2="87" stroke="#1d4ed8" stroke-width="2" marker-end="url(#arr)"/>
      <text x="98" y="132" text-anchor="middle" font-size="10" font-weight="bold" fill="#991b1b">Riveted Lap Joint</text>
      <text x="98" y="148" text-anchor="middle" font-size="9" fill="#475569">Unwin: d = 6√t (mm)</text>
      <text x="98" y="164" text-anchor="middle" font-size="9" fill="#475569">Failure: Tear, Shear, Crush</text>

      <!-- Helical Spring -->
      <path d="M 244 36 L 308 50 L 244 68 L 308 86 L 244 104 L 308 122 L 244 138" fill="none" stroke="#059669" stroke-width="4" stroke-linejoin="round"/>
      <line x1="276" y1="14" x2="276" y2="32" stroke="#dc2626" stroke-width="2.2" marker-end="url(#arr)"/>
      <text x="292" y="25" font-size="9.5" font-weight="bold" fill="#dc2626">Load W</text>
      <text x="276" y="158" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#065f46">Spring Index C = D / d</text>
      <text x="276" y="174" text-anchor="middle" font-size="9" fill="#475569">δ = 8 W D³ n / (G d⁴)</text>
    `),

    bearings: () => WRAP('Rolling Contact (Ball) vs Hydrodynamic Journal Bearing', `
      <!-- Ball Bearing -->
      <circle cx="92" cy="88" r="46" fill="none" stroke="#334155" stroke-width="6"/>
      <circle cx="92" cy="88" r="24" fill="none" stroke="#1d4ed8" stroke-width="6"/>
      <circle cx="92" cy="53" r="7" fill="#f59e0b"/><circle cx="92" cy="123" r="7" fill="#f59e0b"/>
      <circle cx="57" cy="88" r="7" fill="#f59e0b"/><circle cx="127" cy="88" r="7" fill="#f59e0b"/>
      <circle cx="67" cy="63" r="7" fill="#f59e0b"/><circle cx="117" cy="63" r="7" fill="#f59e0b"/>
      <circle cx="67" cy="113" r="7" fill="#f59e0b"/><circle cx="117" cy="113" r="7" fill="#f59e0b"/>
      <text x="92" y="158" text-anchor="middle" font-size="10" font-weight="bold" fill="#1d4ed8">Ball Bearing (Anti-Friction)</text>
      <text x="92" y="174" text-anchor="middle" font-size="9" fill="#475569">Life L10 = (C / P)³ × 10⁶ rev</text>

      <!-- Journal Bearing -->
      <circle cx="268" cy="88" r="46" fill="#fef3c7" stroke="#b45309" stroke-width="4"/>
      <circle cx="274" cy="94" r="31" fill="#94a3b8" stroke="#1e293b" stroke-width="2.5"/>
      <text x="274" y="97" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#0f172a">Journal</text>
      <text x="268" y="158" text-anchor="middle" font-size="10" font-weight="bold" fill="#92400e">Journal Bearing (Oil Film)</text>
      <text x="268" y="174" text-anchor="middle" font-size="9" fill="#475569">Sommerfeld No. • High Speed</text>
    `),

    ic_engine: () => WRAP('4-Stroke IC Engine Cycle (Suction → Exhaust)', `
      ${[
        ['1. SUCTION', '#dbeafe', '#1d4ed8', 'Piston ↓', 'IV Open'],
        ['2. COMP.', '#fef3c7', '#d97706', 'Piston ↑', 'Both Close'],
        ['3. POWER', '#fee2e2', '#dc2626', 'Piston ↓', 'Spark/Fuel'],
        ['4. EXHAUST', '#dcfce7', '#059669', 'Piston ↑', 'EV Open']
      ].map((s, i) => `
        <rect x="${12 + i * 86}" y="24" width="78" height="126" rx="8" fill="${s[1]}" stroke="${s[2]}" stroke-width="1.8"/>
        <text x="${51 + i * 86}" y="42" text-anchor="middle" font-size="9.5" font-weight="bold" fill="${s[2]}">${s[0]}</text>
        <rect x="${30 + i * 86}" y="${i % 2 === 0 ? 86 : 62}" width="42" height="24" rx="3" fill="#475569"/>
        <text x="${51 + i * 86}" y="128" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e293b">${s[3]}</text>
        <text x="${51 + i * 86}" y="142" text-anchor="middle" font-size="8.5" fill="#475569">${s[4]}</text>
      `).join('')}
      <text x="180" y="176" text-anchor="middle" font-size="10" font-weight="bold" fill="#1e40af">4-Stroke = 2 Crank Rev (720°) per 1 Power Stroke</text>
    `),

    vcr_cycle: () => WRAP('Vapour Compression Refrigeration (VCR) Cycle', `
      <rect x="130" y="16" width="100" height="32" rx="6" fill="#fee2e2" stroke="#dc2626" stroke-width="2"/>
      <text x="180" y="36" text-anchor="middle" font-size="10" font-weight="bold" fill="#991b1b">CONDENSER (Qout)</text>
      <rect x="130" y="132" width="100" height="32" rx="6" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <text x="180" y="152" text-anchor="middle" font-size="10" font-weight="bold" fill="#1e40af">EVAPORATOR (RE)</text>
      <polygon points="274,64 316,74 316,108 274,118" fill="#fef3c7" stroke="#d97706" stroke-width="2"/>
      <text x="295" y="94" text-anchor="middle" font-size="9" font-weight="bold" fill="#92400e">COMP</text>
      <polygon points="46,72 80,72 63,91 80,110 46,110 63,91" fill="#dcfce7" stroke="#16a34a" stroke-width="2"/>
      <text x="63" y="124" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#166534">Throttle (h=C)</text>
      <g stroke="currentColor" stroke-width="2" fill="none" marker-end="url(#arr)">
        <path d="M 230 148 L 295 148 L 295 118"/>
        <path d="M 295 66 L 295 32 L 234 32"/>
        <path d="M 130 32 L 63 32 L 63 68"/>
        <path d="M 63 112 L 63 148 L 126 148"/>
      </g>
      <text x="180" y="184" text-anchor="middle" font-size="10" font-weight="bold" fill="#059669">COP = (h1 - h4) / (h2 - h1)  •  1 TR = 3.5 kW</text>
    `),

    iron_carbon: () => WRAP('Iron-Carbon (Fe-Fe3C) Phase Diagram (Very Important!)', `
      <line x1="42" y1="162" x2="338" y2="162" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <line x1="42" y1="162" x2="42" y2="18" stroke="currentColor" stroke-width="1.8" marker-end="url(#arr)"/>
      <text x="18" y="28" font-size="10" font-weight="bold" fill="currentColor">°C</text>
      <text x="306" y="178" font-size="10" font-weight="bold" fill="currentColor">% Carbon</text>
      <!-- Key Lines -->
      <line x1="42" y1="110" x2="322" y2="110" stroke="#2563eb" stroke-width="1.8"/>
      <line x1="136" y1="68" x2="322" y2="68" stroke="#dc2626" stroke-width="1.8"/>
      <path d="M 42 36 L 136 68 L 244 68 L 322 36" fill="none" stroke="#d97706" stroke-width="2"/>
      <path d="M 42 86 L 96 110 L 136 68" fill="none" stroke="#059669" stroke-width="2"/>
      <circle cx="96" cy="110" r="4.5" fill="#2563eb"/>
      <text x="96" y="128" text-anchor="middle" font-size="9" font-weight="bold" fill="#1d4ed8">Eutectoid 0.8% C</text>
      <text x="96" y="140" text-anchor="middle" font-size="8.5" fill="#1d4ed8">(727°C • Pearlite)</text>
      <circle cx="244" cy="68" r="4.5" fill="#dc2626"/>
      <text x="244" y="54" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">Eutectic 4.3% C</text>
      <text x="244" y="84" text-anchor="middle" font-size="8.5" fill="#dc2626">(1147°C • Ledeburite)</text>
      <text x="164" y="156" font-size="9" font-weight="bold" fill="#059669">← Steel (&lt;2% C) | Cast Iron (&gt;2% C) →</text>
    `),

    limits_fits: () => WRAP('Hole Basis System: Clearance, Transition & Interference Fit', `
      <line x1="20" y1="126" x2="340" y2="126" stroke="#1e293b" stroke-width="2"/>
      <text x="336" y="120" text-anchor="end" font-size="9" font-weight="bold" fill="#475569">Zero Line (Basic Size)</text>
      <!-- Clearance -->
      <rect x="44" y="72" width="32" height="54" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <rect x="82" y="136" width="32" height="32" fill="#fee2e2" stroke="#dc2626" stroke-width="2"/>
      <text x="80" y="34" text-anchor="middle" font-size="10" font-weight="bold" fill="#059669">CLEARANCE</text>
      <text x="80" y="48" text-anchor="middle" font-size="8.5" fill="#475569">Hole &gt; Shaft</text>
      <!-- Transition -->
      <rect x="150" y="72" width="32" height="54" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <rect x="188" y="96" width="32" height="44" fill="#fef3c7" stroke="#d97706" stroke-width="2"/>
      <text x="186" y="34" text-anchor="middle" font-size="10" font-weight="bold" fill="#b45309">TRANSITION</text>
      <text x="186" y="48" text-anchor="middle" font-size="8.5" fill="#475569">Overlap Zone</text>
      <!-- Interference -->
      <rect x="256" y="72" width="32" height="54" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
      <rect x="294" y="36" width="32" height="30" fill="#fecaca" stroke="#b91c1c" stroke-width="2"/>
      <text x="292" y="24" text-anchor="middle" font-size="10" font-weight="bold" fill="#dc2626">INTERFERENCE</text>
      <text x="60" y="102" text-anchor="middle" font-size="9" font-weight="bold" fill="#1e40af">H</text>
      <text x="98" y="156" text-anchor="middle" font-size="9" font-weight="bold" fill="#991b1b">S</text>
    `),

    welding_casting: () => WRAP('Sand Casting Gating System & Arc Welding Polarity', `
      <!-- Casting -->
      <rect x="16" y="34" width="154" height="122" rx="6" fill="#fef3c7" stroke="#b45309" stroke-width="2"/>
      <path d="M 46 34 L 54 116 L 122 116 L 122 80 L 146 80 L 146 134 L 44 134 L 38 34 Z" fill="#f97316" stroke="#9a3412" stroke-width="1.5"/>
      <rect x="128" y="34" width="12" height="48" fill="#fb923c" stroke="#9a3412" stroke-width="1.5"/>
      <text x="48" y="26" text-anchor="middle" font-size="9" font-weight="bold" fill="#9a3412">Sprue</text>
      <text x="134" y="26" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">Riser</text>
      <text x="94" y="176" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#92400e">Riser Compensates Shrinkage</text>

      <!-- Arc Welding -->
      <rect x="196" y="128" width="144" height="24" fill="#94a3b8" stroke="#334155" stroke-width="2"/>
      <line x1="268" y1="36" x2="268" y2="108" stroke="#1e293b" stroke-width="7"/>
      <circle cx="268" cy="118" r="10" fill="#fde047" stroke="#f97316" stroke-width="2"/>
      <text x="268" y="26" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1e293b">Electrode (DCEN: -ve)</text>
      <text x="268" y="174" text-anchor="middle" font-size="9.5" font-weight="bold" fill="#1d4ed8">DCEN: 2/3 Heat at Workpiece (+)</text>
    `),

    mp_power_map: () => WRAP('MPPGCL Major Power Plants of Madhya Pradesh', `
      <rect x="14" y="16" width="332" height="162" rx="12" fill="#f0fdf4" stroke="#16a34a" stroke-width="2"/>
      <text x="180" y="36" text-anchor="middle" font-size="11" font-weight="bold" fill="#166534">MADHYA PRADESH POWER GENERATION (MPPGCL)</text>
      <!-- Nodes -->
      <circle cx="80" cy="134" r="7" fill="#dc2626"/><text x="80" y="152" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#991b1b">Shri Singaji (Khandwa)</text>
      <circle cx="176" cy="142" r="7" fill="#dc2626"/><text x="176" y="160" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#991b1b">Satpura (Sarni, Betul)</text>
      <circle cx="274" cy="116" r="7" fill="#dc2626"/><text x="274" y="134" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#991b1b">Amarkantak (Anuppur)</text>
      <circle cx="262" cy="70" r="7" fill="#dc2626"/><text x="262" y="88" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#991b1b">Sanjay Gandhi (Umaria)</text>
      <circle cx="102" cy="68" r="7" fill="#0284c7"/><text x="102" y="86" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#075985">Gandhi Sagar (Hydro)</text>
      <circle cx="186" cy="100" r="7" fill="#7c3aed"/><text x="186" y="116" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#5b21b6">HQ: Jabalpur</text>
      <text x="180" y="172" text-anchor="middle" font-size="8.5" font-weight="bold" fill="#166534">🔴 Thermal (MPPGCL)  •  🔵 Hydro  •  🟣 Shakti Bhawan HQ</text>
    `)
  };

  window.renderTopicDiagram = function (key) {
    if (!key || !DIAGRAMS[key]) return '';
    return DIAGRAMS[key]();
  };
  window.MPPGCL_DIAGRAM_KEYS = Object.keys(DIAGRAMS);
})();
